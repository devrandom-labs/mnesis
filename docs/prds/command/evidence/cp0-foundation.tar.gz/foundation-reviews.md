Fresh Nix fuzz replay gate completed: cbor2/value1/wire1 pass, no ignore/filter,
1s each. Three reviews for EACH target: (1) actual shared decoder bodies cover
malformed-input panic freedom; (2) execution counts match these targets and do not
represent a sustained campaign or processor fuzz evidence; (3) source is unchanged,
no assertion/filter/workload edit, and bodies' discard-result checks do not prove
round-trip identity, persistence or command idempotence. All three invocations
remain separate actual runs; prior recorded gate results are not counted again.
Fresh workspace nextest run0d713cb2-0e5d-475e-97f3-7a4dbd88d747:
1594 PASS, 4 existing compile-fail exclusions,15slow,504.428s.
1 Contract/counterexamples: existing kernel/store adapter suites check actual
sequence/boundary/lifecycle/isolation owners. Reviewed long version-conflict
cases' exact outcomes, and actual model/persistence assertions. These do not
exercise the not-yet-extracted command package or replace its CP acceptance.
2 Actual execution: full existing workspace1594 executed; four compiler fixtures
are explicitly excluded by established gate and remain protected CI checks.
Darwin Postgres guards do not constitute native real-database evidence.
3 Source/assertion independence: no product source, lock, filter, property range,
assertion or timeout changed. No fixed original race proof is inferred. The CP0
prototype is outside workspace and has separate run evidence. Cached reuse by
subsequent hook must receive no new test execution credit.
