# CP0 disposable public-interface proof

Existing Mnesis Nix shell, Rust1.99.0, registry Mnesis/store/inmemory0.5.3.
Actual lock is authoritative; this isolated probe resolves some compatible
transitives newer than the destination workspace. No workspace dependency changed.

Commands from /Users/joel/orca/workspaces/nexus/command-prd:

nix develop path:. --no-update-lock-file --command cargo test --manifest-path /tmp/mnesis-command-cp0.VB6Wh6/Cargo.toml --all-features --lib
nix develop path:. --no-update-lock-file --command cargo test --locked --manifest-path /tmp/mnesis-command-cp0.VB6Wh6/Cargo.toml --test reader
nix develop path:. --no-update-lock-file --command cargo tree --locked --manifest-path /tmp/mnesis-command-cp0.VB6Wh6/Cargo.toml --all-features -e normal

12 lib tests and 1 external-reader test passed. Three distinct reviews follow
each actual run in reviews.md. Reader/accessor was added after the lib run;
focused reader selection avoids claiming a repeat of earlier runtime results.
Original engine unchanged. Original model differs only by a private parts accessor.
Public helper is a disposable shape/ownership experiment, not the final API or
production runtime. It conservatively reports queued stop as Unknown; final code
must retain known-unstarted status and original request identity. Native join
retains typed panic payload. Typed adapter-error case is a manufactured type-flow
witness, not a real adapter failure. No Postgres/projection/performance claim.
