CP0 first run: 12 PASS, no ignored/filtered, 0.01s, Rust1.99 Nix shell.
1 Contract/counterexample: gated active/queued calls retain [1,2,3] after dropping
unpolled replies; capacity is one shared queue; ready reservations do not prevent
stop; worker exit and abort-before-first-poll reject a later call. Original panic
73 survives through the owned JoinHandle; the reply conservatively reports unknown.
2 Actual selection: six original model cases plus six new lifecycle/interface
cases. Typed adapter cause is manufactured to prove generic/channel propagation;
it is not a real adapter-fault test. No Postgres, performance or new service claim.
3 Source/assertion review: original model/engine retained unchanged for this run.
Native current-thread tests establish abort-before-first-poll without scheduling
luck; explicit first-call gates force cancellation overlap. Clone shares queue
but not permit. Mutex protects check-and-enqueue against receiver drop. Limit:
prototype stop drains queued work as Unknown rather than the final typed known-
unstarted rejection; product must preserve Closed for queued work and command ID
for admitted unknown. Native JoinHandle preserves panic payload, which is separate
from retaining typed adapter/domain errors; no adapter error downcast is used.
Next experiment: public reader only, then focused reader run; do not rerun unrelated
lifecycle tests solely to gain another green report.
CP0 reader run: 1 PASS, no ignored/filtered, 0.01s.
1 Contract/counterexample: external integration consumer decodes a v2 envelope
through the original Codec validation, reads exact original receipt and ordered
[3,4] facts, and rejects schema1. Removing validation breaks the negative case.
2 Execution: only --test reader selected; lifecycle/model cases not rerun. Public
crate boundary compiled on registry Mnesis0.5.3. No projection/checkpoint or
old/new writer interchangeability claim beyond this decoding seam.
3 Source/assertions: engine unchanged; model differs only by a private read-only
parts accessor. Reader delegates to Codec, so no duplicated private JSON parser.
Typed request/id/events borrow existing record data. Fixture is generated from
the source v2 unit-test shape, not a discovered production database.
