use serde::de::DeserializeOwned;
use mnesis_store::{Decode, PersistedEnvelope};
use crate::{Request,Receipt,model::{Codec,Record}};

pub struct Acceptance<C,I,E>(Record<C,I,E>);
impl<C,I,E> Acceptance<C,I,E> {
    pub fn request(&self)->&Request<C,I> { self.0.parts().0 }
    pub fn receipt(&self)->&Receipt<I> { self.0.parts().1 }
    pub fn facts(&self)->&[E] { self.0.parts().2 }
}
pub struct AcceptanceCodec;
impl<C:DeserializeOwned+Eq,I:DeserializeOwned+Eq,E:DeserializeOwned> Decode<Acceptance<C,I,E>> for AcceptanceCodec {
    type Output<'a> = Acceptance<C,I,E>;
    type Error = serde_json::Error;
    fn decode(&self, envelope:&PersistedEnvelope)->Result<Acceptance<C,I,E>,Self::Error> {
        Codec.decode(envelope).map(Acceptance)
    }
}
