// CP0 disposable interface proof, not a proposed replacement runtime/framework.
#[allow(dead_code, reason = "unchanged archived engine used by reader fixture")]
mod engine;
#[allow(dead_code, reason = "unchanged archived model plus a read-only projection")]
mod model;
pub use model::{Error, Receipt, Request};
mod acceptance;
pub use acceptance::{Acceptance, AcceptanceCodec};

use std::future::Future;
use std::sync::{Arc, Mutex};
use std::task::{Context, Poll};
use tokio::sync::{Notify, mpsc, oneshot};
use tokio::task::JoinHandle;
use tokio_util::sync::PollSender;
use tower::Service;

#[derive(Clone, Copy)]
enum Phase { Running, Stopped }
struct Shared { phase: Mutex<Phase>, stop: Notify }
#[derive(Debug, thiserror::Error)]
pub enum Failure<E> {
    #[error("not admitted")]
    Closed,
    #[error("admitted work has no observed outcome")]
    Unknown,
    #[error("operation failed: {0}")]
    Operation(#[source] E),
}
struct Call<R,T,E> { request: R, reply: oneshot::Sender<Result<T,E>> }
pub struct Host<R,T,E> { sender: PollSender<Call<R,T,E>>, shared: Arc<Shared> }
impl<R,T,E> Clone for Host<R,T,E> {
    fn clone(&self) -> Self { Self { sender: self.sender.clone(), shared: self.shared.clone() } }
}
impl<R,T,E> Host<R,T,E> {
    pub fn stop(&self) {
        *self.shared.phase.lock().unwrap() = Phase::Stopped;
        self.shared.stop.notify_one();
    }
}
struct Worker<R,T,E> { receiver: mpsc::Receiver<Call<R,T,E>>, shared: Arc<Shared> }
impl<R,T,E> Drop for Worker<R,T,E> {
    fn drop(&mut self) {
        // Executed before receiver fields drop, including abort-before-first-poll.
        *self.shared.phase.lock().unwrap() = Phase::Stopped;
    }
}
pub fn start<R,T,E,F,U>(capacity: usize, mut operation: F) -> (Host<R,T,E>, JoinHandle<()>)
where R: Send+'static, T: Send+'static, E: Send+'static,
    F: FnMut(R)->U + Send+'static, U: Future<Output=Result<T,E>>+Send,
{
    let (sender, receiver) = mpsc::channel(capacity);
    let shared = Arc::new(Shared { phase: Mutex::new(Phase::Running), stop: Notify::new() });
    let mut worker = Worker { receiver, shared: shared.clone() };
    let task = tokio::spawn(async move {
        loop {
            if matches!(*worker.shared.phase.lock().unwrap(), Phase::Stopped) { break; }
            let message = tokio::select! {
                biased;
                _ = worker.shared.stop.notified() => break,
                message = worker.receiver.recv() => message,
            };
            let Some(message) = message else { break; };
            let result = operation(message.request).await;
            let _ = message.reply.send(result);
        }
        *worker.shared.phase.lock().unwrap() = Phase::Stopped;
        worker.receiver.close();
        // Do not await recv(None): outstanding readiness permits may outlive shutdown.
        while let Ok(message) = worker.receiver.try_recv() { drop(message); }
    });
    (Host { sender: PollSender::new(sender), shared }, task)
}
impl<R,T,E> Service<R> for Host<R,T,E>
where R: Send+'static, T: Send+'static, E: Send+'static,
{
    type Response = T;
    type Error = Failure<E>;
    type Future = std::pin::Pin<Box<dyn Future<Output=Result<T,Self::Error>>+Send>>;
    fn poll_ready(&mut self, cx: &mut Context<'_>) -> Poll<Result<(),Self::Error>> {
        if matches!(*self.shared.phase.lock().unwrap(), Phase::Stopped) {
            self.sender.close();
            return Poll::Ready(Err(Failure::Closed));
        }
        self.sender.poll_reserve(cx).map_err(|_| Failure::Closed)
    }
    fn call(&mut self, request: R) -> Self::Future {
        let phase = self.shared.phase.lock().unwrap();
        if matches!(*phase, Phase::Stopped) {
            self.sender.close();
            return Box::pin(async { Err(Failure::Closed) });
        }
        let (reply, response) = oneshot::channel();
        if self.sender.send_item(Call { request, reply }).is_err() {
            return Box::pin(async { Err(Failure::Closed) });
        }
        Box::pin(async move {
            response.await.map_err(|_| Failure::Unknown)?.map_err(Failure::Operation)
        })
    }
}

#[cfg(test)]
mod tests {
    use std::convert::Infallible;
    use std::future::Future;
    use std::sync::{Arc, Mutex};
    use std::task::{Context, Poll};
    use std::time::Duration;
    use futures::task::noop_waker_ref;
    use mnesis_inmemory::InMemoryStoreError;
    use mnesis_store::StoreError;
    use tokio::sync::oneshot;
    use tower::{Service, ServiceExt};
    use super::{Failure, start};
    async fn bounded<F: Future>(f:F)->F::Output {
        tokio::time::timeout(Duration::from_secs(3), f).await.unwrap()
    }

    #[tokio::test]
    async fn reserved_readiness_rejects_after_observed_worker_exit() {
        let (mut service, task) = start(1, |n:u32| async move { Ok::<_,Infallible>(n) });
        bounded(service.ready()).await.unwrap();
        service.stop();
        bounded(task).await.unwrap();
        assert!(matches!(bounded(service.call(7)).await, Err(Failure::Closed)));
    }
    #[tokio::test]
    async fn terminal_panic_cause_is_preserved_by_owned_join() {
        let (mut service, task) = start(1, |_:u32| async move {
            std::panic::panic_any(73u32);
            #[allow(unreachable_code, reason="type witness after deliberate worker panic")]
            Ok::<u32,Infallible>(0)
        });
        let response = bounded(service.ready()).await.unwrap().call(7);
        assert!(matches!(bounded(response).await, Err(Failure::Unknown)));
        let cause = bounded(task).await.unwrap_err();
        assert!(cause.is_panic());
        assert_eq!(*cause.into_panic().downcast::<u32>().unwrap(), 73);
    }
    #[tokio::test]
    async fn typed_adapter_error_survives_response_without_downcast() {
        // A typed channel/error-shape witness, not an adapter failure injection.
        let (mut service, task) = start(1, |_:()| async move {
            Err::<(),_>(StoreError::<_,Infallible,Infallible>::Adapter(InMemoryStoreError::VersionOverflow))
        });
        let response = bounded(service.ready()).await.unwrap().call(());
        assert!(matches!(bounded(response).await,
            Err(Failure::Operation(StoreError::Adapter(InMemoryStoreError::VersionOverflow)))));
        service.stop();
        bounded(task).await.unwrap();
    }
    #[tokio::test]
    async fn dropping_unpolled_responses_keeps_serial_admitted_work() {
        let records=Arc::new(Mutex::new(Vec::new()));
        let output=records.clone();
        let (entered_tx, entered_rx)=oneshot::channel();
        let (release_tx, release_rx)=oneshot::channel();
        let mut first=Some((entered_tx,release_rx));
        let (mut service, task)=start(1, move |n:u32| {
            let gates=first.take();
            let records=output.clone();
            async move {
                if let Some((entered,release))=gates { entered.send(()).unwrap(); release.await.unwrap(); }
                records.lock().unwrap().push(n);
                Ok::<_,Infallible>(n)
            }
        });
        let first=bounded(service.ready()).await.unwrap().call(1);
        bounded(entered_rx).await.unwrap();
        let mut other=service.clone();
        let second=bounded(other.ready()).await.unwrap().call(2);
        drop(first); drop(second);
        assert_eq!(*records.lock().unwrap(), Vec::<u32>::new());
        release_tx.send(()).unwrap();
        let third=bounded(service.ready()).await.unwrap().call(3);
        assert_eq!(bounded(third).await.unwrap(),3);
        assert_eq!(*records.lock().unwrap(),vec![1,2,3]);
        service.stop(); bounded(task).await.unwrap(); drop(other);
    }
    #[tokio::test]
    async fn cloned_ready_handles_do_not_duplicate_permits_or_block_stop() {
        let (mut service, task)=start(1, |n:u32| async move { Ok::<_,Infallible>(n) });
        bounded(service.ready()).await.unwrap();
        let mut other=service.clone();
        let mut cx=Context::from_waker(noop_waker_ref());
        assert!(matches!(other.poll_ready(&mut cx),Poll::Pending));
        drop(service);
        bounded(other.ready()).await.unwrap();
        other.stop();
        bounded(task).await.unwrap();
        assert!(matches!(bounded(other.call(1)).await,Err(Failure::Closed)));
    }
    #[tokio::test]
    async fn abort_before_initial_poll_closes_reserved_admission() {
        let (mut service, task)=start(1, |n:u32| async move { Ok::<_,Infallible>(n) });
        bounded(service.ready()).await.unwrap();
        task.abort();
        assert!(bounded(task).await.unwrap_err().is_cancelled());
        assert!(matches!(bounded(service.call(1)).await,Err(Failure::Closed)));
    }
}
