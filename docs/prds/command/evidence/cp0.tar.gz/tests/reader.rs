use std::num::NonZeroU64;
use mnesis::Version;
use mnesis_store::{Decode,PersistedEnvelope,SchemaVersion};
use mnesis_command_cp0::{Acceptance,AcceptanceCodec};

fn envelope(payload:&[u8])->PersistedEnvelope {
    let mut bytes=b"controller.accepted.v2".to_vec();
    let split=u32::try_from(bytes.len()).unwrap();
    bytes.extend_from_slice(payload);
    let end=u32::try_from(bytes.len()).unwrap();
    PersistedEnvelope::try_new(Version::INITIAL,bytes.into(),SchemaVersion::INITIAL,0..split,split..end,None).unwrap()
}
#[test]
fn public_reader_uses_original_validation_and_borrows_ordered_facts() {
    let payload=br#"{"schema":2,"request":{"id":1,"expected":null,"command":7},"receipt":{"id":1,"version":1,"events":2},"facts":[3,4]}"#;
    let acceptance:Acceptance<u8,NonZeroU64,u8>=AcceptanceCodec.decode(&envelope(payload)).unwrap();
    assert_eq!(acceptance.request().command,7);
    assert_eq!(acceptance.receipt().id,NonZeroU64::new(1).unwrap());
    assert_eq!(acceptance.receipt().version,Version::INITIAL);
    assert_eq!(acceptance.facts(),&[3,4]);
    let invalid=payload.windows(2).position(|s|s==b":2").unwrap();
    let mut corrupt=payload.to_vec();
    corrupt[invalid+1]=b'1';
    let result:Result<Acceptance<u8,NonZeroU64,u8>,_>=AcceptanceCodec.decode(&envelope(&corrupt));
    assert!(result.is_err());
}
