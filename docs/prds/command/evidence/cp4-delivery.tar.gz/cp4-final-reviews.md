# CP4 exact-head CI review, 2026-10-21

Reviewed signed head 786dce713004cf90e8e3c943c0f7ee6eb3d38425 against
main 98abf662278c40a730b88fdbe6814481f1db108e. Head, GitHub virtual merge
c2ef0d12c98a22957ea248435407a9e2541ed35f and locally computed merge all have
tree 24680399552aca8b52f383bcc3c79862669401b3. No outstanding review threads,
42 successful checks and one scheduled-only mutation sweep skip. Original
local failures remain in cp4-gates; none are reclassified as passing.

## Every CI test invocation: three reviews

The push39668184945 and PR39668192982 raw logs and their ordered counts files
identify every invocation. Each has75 printed result lines,74 actual runs;
the unprefixed264 summary is an echoed result-postgres/run.log, not a new run.
Apply the following distinct reviews to EACH corresponding result line, retaining
its exact observed count/duration rather than inventing an aggregate test count.

1. Contract/counterexample: each workspace run includes all39 command laws,
   original v2 writer bytes and rollback readability, actual public acceptance
   decoder/projection physical checkpoint restart, no-op/multifact/evolution,
   independent corrupt/duplicate/cumulative cases and prior typed-outcome/race
   laws. Each compile fixture pins the intended rejection. Each library run
   exercises that package's existing unit contracts in default/no-default/all
   modes. Each native profile exercises the adapter's unchanged owning laws;
   each one-law selection asserts the required feature actually executes.
   Replay invocations exercise existing2/1/1 stable fuzz owners. These native
   adapter runs do NOT qualify the unimplemented command-native CP6 matrix.
2. Execution/selection/service: each workflow really ran one1633/1633 workspace
   invocation across143 binaries, five existing exclusions; push147.037s/four
   slow, PR107.975s/three slow. Each has three compile harnesses2/1/1,27 unit
   harness invocations (including zero-test harnesses, credited ONLY as build
   coverage), three replay invocations2/1/1, and40 native invocations. The native
   runs use TWO independent Nix disposable Postgres services per workflow,
   require a successful SELECT1 before nextest, and enforce --no-tests=fail.
   Each service has seven complete profiles264/149/168/176/173/174/150, zero
   skips, plus13 actually passing one-law selectors with intentional filter
   exclusions recorded in raw counts. No service-free green or cached native
   execution is claimed. No echoed summary is double-counted.
3. Assertions/source/false positives: inspected exact workflow and Nix owners,
   actual start/summary pairs, explicit feature membership, native startup and
   required-law selectors. Workspace/feature checks share the reviewed tree;
   PR virtual merge matches it exactly. Zero-test libs and core no_std/wasm
   compilation prove no command-native behavior. Original independent golden
   writer, exact facts/receipts/state/counts/checkpoint and corruption oracles
   remain; no filters, workloads, deadlines, assertions or gates weakened.
   The ten invalid mutations below are not ten runtime catches.

## Mutation campaign39668192890 / artifact12379275422

All11 outcomes and all first diagnostics independently inspected. Baseline:
39PASS, one original ignored, five binaries, actual nextest5.270s (outer process
5.71465827s), build42.605767915s. Its three reviews: (1) all original command
laws and reader compatibility law run; (2) actual complete selected command
package, no database claimed; (3) same reviewed source, no new filter, original
compile-fail exclusion irrelevant to this package, exact value assertions intact.

Each of the TWO viable mutants replaces Acceptance's DomainEvent name with
either empty or xyzzy. For EACH: (1) the old-format compatibility law must reject
the wrong persisted type; (2) build succeeds, actual fail-fast8/39 executed,
7PASS/1FAIL/one ignored,31 not run; durations0.049s and0.047s respectively;
(3) first failure is the intended EXACT left empty/xyzzy versus
controller.accepted.v2 assertion in original_writer_records_replay_and_new_writes_preserve_rollback_bytes,
unit/model.rs:131, not fixture poisoning, timeout or an incidental compiler error.

Each of the EIGHT unviable mutants: (1) no behavioral rejection claimed;
(2) build101 before tests; request Default absent, Receipt new absent (two
variants), Receipt from_iter absent, Receipt Default absent, Vec::leak nonconst,
fact E Default absent, Acceptance Default absent respectively; (3) inspected
each first compiler diagnostic and exact mutation, no runtime assertion credited.
Totals10mutants:2caught/8unviable/0missed/0timeout. This narrow diff campaign
supplements earlier independent facts/name negative controls; it does not prove
all corruption or recovery cases by itself.

## Every fuzz campaign39668192938: three reviews

For EACH libFuzzer invocation (wire8272245/header1824297/chunk1283091/value5775575),
(1) unchanged decoder/body invariants and shared seed corpora exercised;
(2) actual61s engine execution with nonzero counts and successful terminal verdict,
no service needed; (3) exact reviewed source, bounded campaign only, no command
history/native coverage inferred and no weakened crash oracle.

For EACH AFL invocation (wire/header/chunk/value), (1) same owning decoder/body
invariants with CMPLOG input exploration; (2) actual60s time limit, CMPLOG engaged,
zero saved crashes/timeouts; new corpus0/1/11/0, coverage34.33/47.61/43.39/8.31%;
(3) unchanged saved-crash gate checked independently of engine exit status,
uploaded artifacts retained, bounded search not exhaustive proof or command fuzz
qualification. All eight paths and actual terminal summaries inspected.

Final publication, CP5 telemetry and CP6–CP9 remain open. Package publish=false.
