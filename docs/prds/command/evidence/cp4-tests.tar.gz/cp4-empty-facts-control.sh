set -eu
task_model=/Users/joel/orca/workspaces/nexus/command-prd/crates/command/src/model.rs
task_backup=/tmp/mnesis-command-start-20261021/cp4-model-before-empty-facts.rs
cp "$task_model" "$task_backup"
trap 'cp "$task_backup" "$task_model"' EXIT
test "$(rg -c -F 'self.0.facts.as_slice()' "$task_backup")" = 1
sed 's/self\.0\.facts\.as_slice()/\&[]/' "$task_backup" > "$task_model"
cargo nextest run --locked -p mnesis-command --test reader </dev/null
