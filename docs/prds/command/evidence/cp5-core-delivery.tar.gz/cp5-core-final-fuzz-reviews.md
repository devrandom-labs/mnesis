# Core CP5 fuzz run39676299874 — each actual campaign reviewed

Exact reviewed core head1539509ae5c60977a6fb77469f5ae894e06e3e98. These are
foundation decoder campaigns, not command-native/command-history qualification.
No changed bodies/corpora/workloads/crash verdicts or extra runtime introduced.

For EACH libFuzzer campaign — wire12522466/header3163063/chunk1281005/value7713892:
1. Contract/counterexample: unchanged owning wire/CBOR/value decoder invariants
   and shared seed corpus; command admission/lifecycle laws are not inferred.
2. Execution/selection/service: actual61s bounded run, nonzero stated executions,
   terminal successful verdict and no database dependency.
3. Assertion/source/false positives: exact reviewed source, original oracle and
   crash handling, no weakened limits or unexecuted coverage; finite exploration
   is not exhaustive proof. Actual terminal summary for each inspected.

For EACH AFL campaign — wire/header/chunk/value:
1. Contract/counterexample: same decoder body and seeds with CMPLOG exploration;
   no new command fuzz coverage inferred.
2. Execution/selection/service: actual60s time limit, CMPLOG engaged for each,
   zero saved crashes/timeouts. New items0/1/12/0; coverage34.33/47.61/43.39/8.31%.
3. Assertion/source/false positives: inspected each terminal summary and CMPLOG
   confirmation; unchanged independent saved-crash gate rejects crashes even if
   the engine exits zero. Original artifacts retained. No service-free green or
   missing command-native requirement credited as passing.
