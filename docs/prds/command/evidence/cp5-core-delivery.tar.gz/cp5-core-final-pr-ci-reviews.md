# CP5 exact-head pr CI 39676300194: three reviews per actual invocation

Reviewed head1539509ae5c60977a6fb77469f5ae894e06e3e98. PR uses virtual merge d34deff into8fc56283; verify tree before protected merge. Raw cp5-core-final-pr-ci.log. 74 actual invocations; plain echoed Postgres run.log summary has no fresh execution credit. All summaries and native one-case names inspected. Feature unit triples remain separate invocations. No command-native CP6 or telemetry credit.

Invocation 1: Nix Flake Check	Flake Check	2026-10-21T21:15:16.5563507Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing corpus replay group with 2 law(s), preserving decode rejection and bounded replay invariants. This is replay, not a new fuzz campaign.
2. Execution/selection/services: Actual existing replay test executable reports 2 passed, zero failed/ignored/filtered; no external database needed.
3. Source/assertion/false-positive review: Signed source and existing corpus/oracles unchanged; finite replay cannot establish arbitrary-input completeness or native adapter durability.

Invocation 2: Nix Flake Check	Flake Check	2026-10-21T21:15:17.5585367Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing corpus replay group with 1 law(s), preserving decode rejection and bounded replay invariants. This is replay, not a new fuzz campaign.
2. Execution/selection/services: Actual existing replay test executable reports 1 passed, zero failed/ignored/filtered; no external database needed.
3. Source/assertion/false-positive review: Signed source and existing corpus/oracles unchanged; finite replay cannot establish arbitrary-input completeness or native adapter durability.

Invocation 3: Nix Flake Check	Flake Check	2026-10-21T21:15:18.5608264Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing corpus replay group with 1 law(s), preserving decode rejection and bounded replay invariants. This is replay, not a new fuzz campaign.
2. Execution/selection/services: Actual existing replay test executable reports 1 passed, zero failed/ignored/filtered; no external database needed.
3. Source/assertion/false-positive review: Signed source and existing corpus/oracles unchanged; finite replay cannot establish arbitrary-input completeness or native adapter durability.

Invocation 4: Nix Flake Check	Flake Check	2026-10-21T21:28:47.7790607Z mnesis-nextest>      Summary [ 147.192s] 1639 tests run: 1639 passed (4 slow), 5 skipped
1. Contract/counterexample: Whole workspace including all45 command laws: retained exact identity/retry, late commit, native cause/custody, resource boundaries and forced-race workloads. Metrics/tracing and CP6 command-native composition are not present.
2. Execution/selection/services: 1639 PASS across143 binaries, five existing exclusions, actual workspace invocation. Adapter cases without the native service do not gain database credit here.
3. Source/assertion/false-positive review: No selection/assertion/deadline changes. Independent lifecycle failure controls and current mutation catches remain recorded. Both timer-disabled and reentrant-readiness bounded children appear as PASS; child-specific reviews follow.

Invocation 5: Nix Flake Check	Flake Check	2026-10-21T21:37:35.1687812Z mnesis-postgres-integration>      Summary [   0.089s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 6: Nix Flake Check	Flake Check	2026-10-21T21:37:39.8853997Z mnesis-postgres-integration>      Summary [   0.432s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 7: Nix Flake Check	Flake Check	2026-10-21T21:37:45.9961438Z mnesis-postgres-integration>      Summary [   1.858s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 8: Nix Flake Check	Flake Check	2026-10-21T21:37:50.9648137Z mnesis-postgres-integration>      Summary [   0.708s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 9: Nix Flake Check	Flake Check	2026-10-21T21:37:56.8205050Z mnesis-postgres-integration>      Summary [   1.594s] 1 test run: 1 passed, 10 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 10: Nix Flake Check	Flake Check	2026-10-21T21:38:03.6697445Z mnesis-postgres-integration>      Summary [   2.017s] 1 test run: 1 passed, 4 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 11: Nix Flake Check	Flake Check	2026-10-21T21:38:07.9728353Z mnesis-postgres-integration>      Summary [   0.048s] 1 test run: 1 passed, 9 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 12: Nix Flake Check	Flake Check	2026-10-21T21:39:19.1438212Z mnesis-postgres-integration>      Summary [  66.849s] 264 tests run: 264 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 264 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 264 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 13: Nix Flake Check	Flake Check	2026-10-21T21:39:22.1317887Z mnesis-postgres-integration>      Summary [   0.058s] 1 test run: 1 passed, 39 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 14: Nix Flake Check	Flake Check	2026-10-21T21:40:04.9867329Z mnesis-postgres-integration>      Summary [  39.963s] 149 tests run: 149 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 149 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 149 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 15: Nix Flake Check	Flake Check	2026-10-21T21:40:08.4275334Z mnesis-postgres-integration>      Summary [   0.372s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 16: Nix Flake Check	Flake Check	2026-10-21T21:40:56.1609765Z mnesis-postgres-integration>      Summary [  44.516s] 168 tests run: 168 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 168 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 168 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 17: Nix Flake Check	Flake Check	2026-10-21T21:40:59.2218306Z mnesis-postgres-integration>      Summary [   0.071s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 18: Nix Flake Check	Flake Check	2026-10-21T21:41:47.5219193Z mnesis-postgres-integration>      Summary [  45.216s] 176 tests run: 176 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 176 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 176 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 19: Nix Flake Check	Flake Check	2026-10-21T21:41:50.8059099Z mnesis-postgres-integration>      Summary [   0.159s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 20: Nix Flake Check	Flake Check	2026-10-21T21:42:35.2567548Z mnesis-postgres-integration>      Summary [  41.227s] 173 tests run: 173 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 173 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 173 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 21: Nix Flake Check	Flake Check	2026-10-21T21:42:38.2892103Z mnesis-postgres-integration>      Summary [   0.074s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 22: Nix Flake Check	Flake Check	2026-10-21T21:43:21.5665679Z mnesis-postgres-integration>      Summary [  40.236s] 174 tests run: 174 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 174 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 174 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 23: Nix Flake Check	Flake Check	2026-10-21T21:43:25.6030014Z mnesis-postgres-integration>      Summary [   1.065s] 1 test run: 1 passed, 0 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 24: Nix Flake Check	Flake Check	2026-10-21T21:44:08.7657428Z mnesis-postgres-integration>      Summary [  40.067s] 150 tests run: 150 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 150 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 150 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 25: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T21:19:16.1924569Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.53s
1. Contract/counterexample: Existing isolated Features (mnesis-fjall) unit harness: 131 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 131 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 26: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T21:19:18.8625504Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.50s
1. Contract/counterexample: Existing isolated Features (mnesis-fjall) unit harness: 131 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 131 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 27: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T21:19:21.5404730Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.50s
1. Contract/counterexample: Existing isolated Features (mnesis-fjall) unit harness: 131 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 131 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 28: Postgres Integration	Postgres integration	2026-10-21T21:28:32.1449941Z mnesis-postgres-integration>      Summary [   0.447s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 29: Postgres Integration	Postgres integration	2026-10-21T21:28:37.0364181Z mnesis-postgres-integration>      Summary [   0.656s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 30: Postgres Integration	Postgres integration	2026-10-21T21:28:43.0500089Z mnesis-postgres-integration>      Summary [   1.816s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 31: Postgres Integration	Postgres integration	2026-10-21T21:28:48.0217781Z mnesis-postgres-integration>      Summary [   0.776s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 32: Postgres Integration	Postgres integration	2026-10-21T21:28:54.0416950Z mnesis-postgres-integration>      Summary [   1.823s] 1 test run: 1 passed, 10 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 33: Postgres Integration	Postgres integration	2026-10-21T21:29:00.3997135Z mnesis-postgres-integration>      Summary [   1.743s] 1 test run: 1 passed, 4 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 34: Postgres Integration	Postgres integration	2026-10-21T21:29:04.5797898Z mnesis-postgres-integration>      Summary [   0.050s] 1 test run: 1 passed, 9 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 35: Postgres Integration	Postgres integration	2026-10-21T21:30:15.8748324Z mnesis-postgres-integration>      Summary [  66.681s] 264 tests run: 264 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 264 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 264 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 36: Postgres Integration	Postgres integration	2026-10-21T21:30:18.8008109Z mnesis-postgres-integration>      Summary [   0.058s] 1 test run: 1 passed, 39 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 37: Postgres Integration	Postgres integration	2026-10-21T21:31:01.3770721Z mnesis-postgres-integration>      Summary [  39.707s] 149 tests run: 149 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 149 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 149 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 38: Postgres Integration	Postgres integration	2026-10-21T21:31:04.7319482Z mnesis-postgres-integration>      Summary [   0.311s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 39: Postgres Integration	Postgres integration	2026-10-21T21:31:51.9574104Z mnesis-postgres-integration>      Summary [  44.088s] 168 tests run: 168 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 168 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 168 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 40: Postgres Integration	Postgres integration	2026-10-21T21:31:54.9871241Z mnesis-postgres-integration>      Summary [   0.069s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 41: Postgres Integration	Postgres integration	2026-10-21T21:32:42.5433744Z mnesis-postgres-integration>      Summary [  44.526s] 176 tests run: 176 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 176 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 176 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 42: Postgres Integration	Postgres integration	2026-10-21T21:32:45.8716069Z mnesis-postgres-integration>      Summary [   0.226s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 43: Postgres Integration	Postgres integration	2026-10-21T21:33:30.9483738Z mnesis-postgres-integration>      Summary [  41.860s] 173 tests run: 173 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 173 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 173 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 44: Postgres Integration	Postgres integration	2026-10-21T21:33:33.9564418Z mnesis-postgres-integration>      Summary [   0.079s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 45: Postgres Integration	Postgres integration	2026-10-21T21:34:17.4880502Z mnesis-postgres-integration>      Summary [  40.521s] 174 tests run: 174 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 174 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 174 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 46: Postgres Integration	Postgres integration	2026-10-21T21:34:21.5045226Z mnesis-postgres-integration>      Summary [   1.062s] 1 test run: 1 passed, 0 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 47: Postgres Integration	Postgres integration	2026-10-21T21:35:03.8417220Z mnesis-postgres-integration>      Summary [  39.287s] 150 tests run: 150 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 150 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 150 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 48: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T21:17:53.6662881Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s
1. Contract/counterexample: Existing isolated Features (mnesis-inmemory) unit harness: 25 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 25 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 49: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T21:17:53.8618967Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s
1. Contract/counterexample: Existing isolated Features (mnesis-inmemory) unit harness: 25 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 25 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 50: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T21:17:56.3568727Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s
1. Contract/counterexample: Existing isolated Features (mnesis-inmemory) unit harness: 30 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 30 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 51: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T21:20:38.1352338Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 52: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T21:20:38.2417499Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 53: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T21:20:38.3468414Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 54: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T21:20:38.6732270Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 55: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T21:20:38.7760109Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 56: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T21:20:38.8812458Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 57: Compile-fail tests	Kernel compile-fail tests	2026-10-21T21:21:47.7200976Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 130.97s
1. Contract/counterexample: Compile-fail tests: existing public misuse/diagnostic compiler fixtures; 2 harness case(s), not ordinary command runtime laws.
2. Execution/selection/services: Actual checkout compiler harness 2 PASS, zero failed/ignored/filtered; separate from Nix's five workspace exclusions. No database involved.
3. Source/assertion/false-positive review: Existing expected diagnostics and positive/negative fixture assertions unchanged. Compiler acceptance is credited only to the actual completed fixture checks; no runtime/durability inference.

Invocation 58: Compile-fail tests	Macro compile-fail tests	2026-10-21T21:22:23.9341162Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 16.42s
1. Contract/counterexample: Compile-fail tests: existing public misuse/diagnostic compiler fixtures; 1 harness case(s), not ordinary command runtime laws.
2. Execution/selection/services: Actual checkout compiler harness 1 PASS, zero failed/ignored/filtered; separate from Nix's five workspace exclusions. No database involved.
3. Source/assertion/false-positive review: Existing expected diagnostics and positive/negative fixture assertions unchanged. Compiler acceptance is credited only to the actual completed fixture checks; no runtime/durability inference.

Invocation 59: Compile-fail tests	Store compile-fail tests	2026-10-21T21:22:52.3139858Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 19.88s
1. Contract/counterexample: Compile-fail tests: existing public misuse/diagnostic compiler fixtures; 1 harness case(s), not ordinary command runtime laws.
2. Execution/selection/services: Actual checkout compiler harness 1 PASS, zero failed/ignored/filtered; separate from Nix's five workspace exclusions. No database involved.
3. Source/assertion/false-positive review: Existing expected diagnostics and positive/negative fixture assertions unchanged. Compiler acceptance is credited only to the actual completed fixture checks; no runtime/durability inference.

Invocation 60: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T21:22:31.3159056Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.75s
1. Contract/counterexample: Existing isolated Features (mnesis-store) unit harness: 217 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 217 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 61: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T21:22:32.9876058Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.56s
1. Contract/counterexample: Existing isolated Features (mnesis-store) unit harness: 217 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 217 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 62: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T21:22:38.5708690Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.63s
1. Contract/counterexample: Existing isolated Features (mnesis-store) unit harness: 217 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 217 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 63: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T21:18:05.5604105Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Existing isolated Features (mnesis-wake) unit harness: 17 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 17 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 64: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T21:18:05.8244301Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Existing isolated Features (mnesis-wake) unit harness: 17 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 17 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 65: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T21:18:06.0918095Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Existing isolated Features (mnesis-wake) unit harness: 17 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 17 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 66: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T21:20:52.6634651Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-macros) unit harness: 1 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 1 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 67: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T21:20:52.7759310Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-macros) unit harness: 1 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 1 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 68: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T21:20:52.8892916Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-macros) unit harness: 1 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 1 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 69: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T21:21:59.2051418Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis) unit harness: 15 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 15 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 70: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T21:21:59.3100920Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis) unit harness: 15 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 15 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 71: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T21:21:59.7381004Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis) unit harness: 15 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 15 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 72: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T21:22:15.7244112Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-postgres) unit harness: 11 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 11 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 73: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T21:22:15.8639875Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-postgres) unit harness: 11 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 11 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 74: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T21:22:18.4886431Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-postgres) unit harness: 11 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 11 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Child timer_disabled_runtime_retains_the_native_failure (inside workspace):
1. Contract: unsupported timer configuration retains exact native Tokio panic, exact uncertain caller ID, empty rows and closed admission.
2. Execution: parent PASS plus helper's child-status and exact one-PASS summary checks; two-second bound, exact-name child invocation.
3. Strength/source: original panic text and payload assertions retained; zero-selection, process failure and hung runtime all fail the parent.

Child readiness_release_allows_a_reentrant_stop_callback (inside workspace):
1. Contract: releasing pending readiness may synchronously reenter stop; observed worker completion retains no uncertainty.
2. Execution: parent PASS plus helper's child-status and exact one-PASS summary checks; two-second bound, exact-name child invocation.
3. Strength/source: actual native permit/waker path and observed shutdown; omission/mutation witnesses retained; a deadlock or zero selected test cannot pass.
