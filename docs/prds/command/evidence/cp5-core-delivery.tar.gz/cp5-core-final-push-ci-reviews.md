# CP5 exact-head push CI 39676293555: three reviews per actual invocation

Reviewed head1539509ae5c60977a6fb77469f5ae894e06e3e98. PR uses virtual merge d34deff into8fc56283; verify tree before protected merge. Raw cp5-core-final-push-ci.log. 54 actual invocations; plain echoed Postgres run.log summary has no fresh execution credit. All summaries and native one-case names inspected. Feature unit triples remain separate invocations. No command-native CP6 or telemetry credit.

Invocation 1: Compile-fail tests	Kernel compile-fail tests	2026-10-21T21:23:28.1849684Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 120.49s
1. Contract/counterexample: Compile-fail tests: existing public misuse/diagnostic compiler fixtures; 2 harness case(s), not ordinary command runtime laws.
2. Execution/selection/services: Actual checkout compiler harness 2 PASS, zero failed/ignored/filtered; separate from Nix's five workspace exclusions. No database involved.
3. Source/assertion/false-positive review: Existing expected diagnostics and positive/negative fixture assertions unchanged. Compiler acceptance is credited only to the actual completed fixture checks; no runtime/durability inference.

Invocation 2: Compile-fail tests	Macro compile-fail tests	2026-10-21T21:24:02.1374457Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 15.82s
1. Contract/counterexample: Compile-fail tests: existing public misuse/diagnostic compiler fixtures; 1 harness case(s), not ordinary command runtime laws.
2. Execution/selection/services: Actual checkout compiler harness 1 PASS, zero failed/ignored/filtered; separate from Nix's five workspace exclusions. No database involved.
3. Source/assertion/false-positive review: Existing expected diagnostics and positive/negative fixture assertions unchanged. Compiler acceptance is credited only to the actual completed fixture checks; no runtime/durability inference.

Invocation 3: Compile-fail tests	Store compile-fail tests	2026-10-21T21:24:28.3899112Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 18.49s
1. Contract/counterexample: Compile-fail tests: existing public misuse/diagnostic compiler fixtures; 1 harness case(s), not ordinary command runtime laws.
2. Execution/selection/services: Actual checkout compiler harness 1 PASS, zero failed/ignored/filtered; separate from Nix's five workspace exclusions. No database involved.
3. Source/assertion/false-positive review: Existing expected diagnostics and positive/negative fixture assertions unchanged. Compiler acceptance is credited only to the actual completed fixture checks; no runtime/durability inference.

Invocation 4: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T21:19:22.5875847Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-postgres) unit harness: 11 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 11 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 5: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T21:19:22.7240022Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-postgres) unit harness: 11 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 11 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 6: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T21:19:25.3749121Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-postgres) unit harness: 11 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 11 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 7: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T21:15:22.6258998Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Existing isolated Features (mnesis-wake) unit harness: 17 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 17 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 8: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T21:15:22.9155013Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Existing isolated Features (mnesis-wake) unit harness: 17 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 17 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 9: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T21:15:23.1989965Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Existing isolated Features (mnesis-wake) unit harness: 17 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 17 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 10: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T21:23:04.3689678Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis) unit harness: 15 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 15 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 11: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T21:23:04.5154648Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis) unit harness: 15 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 15 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 12: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T21:23:05.0625556Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis) unit harness: 15 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 15 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 13: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T21:22:11.9755841Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 14: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T21:22:12.1002843Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 15: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T21:22:12.2240206Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 16: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T21:23:11.8092167Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.50s
1. Contract/counterexample: Existing isolated Features (mnesis-fjall) unit harness: 131 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 131 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 17: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T21:23:14.4595404Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.50s
1. Contract/counterexample: Existing isolated Features (mnesis-fjall) unit harness: 131 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 131 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 18: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T21:23:17.0963984Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.48s
1. Contract/counterexample: Existing isolated Features (mnesis-fjall) unit harness: 131 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 131 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 19: Nix Flake Check	Flake Check	2026-10-21T21:25:12.9675875Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing corpus replay group with 2 law(s), preserving decode rejection and bounded replay invariants. This is replay, not a new fuzz campaign.
2. Execution/selection/services: Actual existing replay test executable reports 2 passed, zero failed/ignored/filtered; no external database needed.
3. Source/assertion/false-positive review: Signed source and existing corpus/oracles unchanged; finite replay cannot establish arbitrary-input completeness or native adapter durability.

Invocation 20: Nix Flake Check	Flake Check	2026-10-21T21:25:13.9698897Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing corpus replay group with 1 law(s), preserving decode rejection and bounded replay invariants. This is replay, not a new fuzz campaign.
2. Execution/selection/services: Actual existing replay test executable reports 1 passed, zero failed/ignored/filtered; no external database needed.
3. Source/assertion/false-positive review: Signed source and existing corpus/oracles unchanged; finite replay cannot establish arbitrary-input completeness or native adapter durability.

Invocation 21: Nix Flake Check	Flake Check	2026-10-21T21:25:14.9720407Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing corpus replay group with 1 law(s), preserving decode rejection and bounded replay invariants. This is replay, not a new fuzz campaign.
2. Execution/selection/services: Actual existing replay test executable reports 1 passed, zero failed/ignored/filtered; no external database needed.
3. Source/assertion/false-positive review: Signed source and existing corpus/oracles unchanged; finite replay cannot establish arbitrary-input completeness or native adapter durability.

Invocation 22: Nix Flake Check	Flake Check	2026-10-21T21:38:46.2019189Z mnesis-nextest>      Summary [ 152.027s] 1639 tests run: 1639 passed (4 slow), 5 skipped
1. Contract/counterexample: Whole workspace including all45 command laws: retained exact identity/retry, late commit, native cause/custody, resource boundaries and forced-race workloads. Metrics/tracing and CP6 command-native composition are not present.
2. Execution/selection/services: 1639 PASS across143 binaries, five existing exclusions, actual workspace invocation. Adapter cases without the native service do not gain database credit here.
3. Source/assertion/false-positive review: No selection/assertion/deadline changes. Independent lifecycle failure controls and current mutation catches remain recorded. Both timer-disabled and reentrant-readiness bounded children appear as PASS; child-specific reviews follow.

Invocation 23: Nix Flake Check	Flake Check	2026-10-21T21:47:35.4876744Z mnesis-postgres-integration>      Summary [   0.093s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 24: Nix Flake Check	Flake Check	2026-10-21T21:47:40.4307193Z mnesis-postgres-integration>      Summary [   0.645s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 25: Nix Flake Check	Flake Check	2026-10-21T21:47:46.5356869Z mnesis-postgres-integration>      Summary [   1.883s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 26: Nix Flake Check	Flake Check	2026-10-21T21:47:51.3540238Z mnesis-postgres-integration>      Summary [   0.570s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 27: Nix Flake Check	Flake Check	2026-10-21T21:47:57.0732086Z mnesis-postgres-integration>      Summary [   1.463s] 1 test run: 1 passed, 10 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 28: Nix Flake Check	Flake Check	2026-10-21T21:48:04.0451663Z mnesis-postgres-integration>      Summary [   1.990s] 1 test run: 1 passed, 4 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 29: Nix Flake Check	Flake Check	2026-10-21T21:48:08.3507572Z mnesis-postgres-integration>      Summary [   0.047s] 1 test run: 1 passed, 9 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 30: Nix Flake Check	Flake Check	2026-10-21T21:49:21.4506287Z mnesis-postgres-integration>      Summary [  68.194s] 264 tests run: 264 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 264 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 264 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 31: Nix Flake Check	Flake Check	2026-10-21T21:49:24.4750405Z mnesis-postgres-integration>      Summary [   0.065s] 1 test run: 1 passed, 39 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 32: Nix Flake Check	Flake Check	2026-10-21T21:50:09.5366262Z mnesis-postgres-integration>      Summary [  42.123s] 149 tests run: 149 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 149 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 149 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 33: Nix Flake Check	Flake Check	2026-10-21T21:50:13.1346835Z mnesis-postgres-integration>      Summary [   0.352s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 34: Nix Flake Check	Flake Check	2026-10-21T21:51:02.1680635Z mnesis-postgres-integration>      Summary [  45.760s] 168 tests run: 168 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 168 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 168 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 35: Nix Flake Check	Flake Check	2026-10-21T21:51:05.2791281Z mnesis-postgres-integration>      Summary [   0.078s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 36: Nix Flake Check	Flake Check	2026-10-21T21:51:53.8043977Z mnesis-postgres-integration>      Summary [  45.470s] 176 tests run: 176 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 176 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 176 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 37: Nix Flake Check	Flake Check	2026-10-21T21:51:57.1030365Z mnesis-postgres-integration>      Summary [   0.162s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 38: Nix Flake Check	Flake Check	2026-10-21T21:52:43.7373773Z mnesis-postgres-integration>      Summary [  43.364s] 173 tests run: 173 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 173 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 173 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 39: Nix Flake Check	Flake Check	2026-10-21T21:52:46.7920770Z mnesis-postgres-integration>      Summary [   0.082s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 40: Nix Flake Check	Flake Check	2026-10-21T21:53:32.5925744Z mnesis-postgres-integration>      Summary [  42.763s] 174 tests run: 174 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 174 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 174 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 41: Nix Flake Check	Flake Check	2026-10-21T21:53:36.6870443Z mnesis-postgres-integration>      Summary [   1.071s] 1 test run: 1 passed, 0 skipped
1. Contract/counterexample: Required selected adapter law mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields; this pins its selected capability rather than merely compiling that feature.
2. Execution/selection/services: Actual derivation-prefixed native run, 1 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Other cases filtered by the explicit required-law selection.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Named PASS excludes a zero-selected green result. Missing-service green skipping cannot substitute for this required runner.

Invocation 42: Nix Flake Check	Flake Check	2026-10-21T21:54:21.4343426Z mnesis-postgres-integration>      Summary [  41.617s] 150 tests run: 150 passed, 0 skipped
1. Contract/counterexample: Full selected adapter profile: 150 laws. Existing atomicity, read/checkpoint, restart, failure and cleanup contracts remain; this is adapter evidence, not command-composition evidence.
2. Execution/selection/services: Actual derivation-prefixed native run, 150 PASS; live disposable Postgres startup/SELECT 1 and fail-on-no-tests runner verified in source/log. Full profile has zero skipped.
3. Source/assertion/false-positive review: Exact signed source/virtual tree; original native persistence/SQL/cleanup assertions stay with their existing owners. Enumerated PASS workload agrees with final count. Missing-service green skipping cannot substitute for this required runner.

Invocation 43: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T21:23:09.1493337Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s
1. Contract/counterexample: Existing isolated Features (mnesis-inmemory) unit harness: 25 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 25 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 44: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T21:23:09.3260042Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s
1. Contract/counterexample: Existing isolated Features (mnesis-inmemory) unit harness: 25 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 25 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 45: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T21:23:11.9433511Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s
1. Contract/counterexample: Existing isolated Features (mnesis-inmemory) unit harness: 30 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 30 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 46: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T21:24:12.5446732Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.85s
1. Contract/counterexample: Existing isolated Features (mnesis-store) unit harness: 217 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 217 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 47: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T21:24:15.5199966Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.82s
1. Contract/counterexample: Existing isolated Features (mnesis-store) unit harness: 217 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 217 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 48: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T21:24:23.1039772Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.81s
1. Contract/counterexample: Existing isolated Features (mnesis-store) unit harness: 217 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 217 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 49: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T21:23:29.1043500Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 50: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T21:23:29.2344529Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 51: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T21:23:29.3587667Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This isolated feature harness contains no unit cases; it checks build/feature availability only. No runtime contract credit.
2. Execution/selection/services: Actual distinct feature invocation, 0 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: Zero is retained explicitly rather than inflated into tested behavior. Existing supported feature compilation remains meaningful; no assertion strength claimed.

Invocation 52: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T21:23:09.9152093Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-macros) unit harness: 1 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 1 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 53: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T21:23:10.0486457Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-macros) unit harness: 1 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 1 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Invocation 54: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T21:23:10.1789543Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Existing isolated Features (mnesis-macros) unit harness: 1 laws. Public integration/concurrency/native coverage is supplied separately.
2. Execution/selection/services: Actual distinct feature invocation, 1 passed and zero failed/ignored/filtered. Database absence does not become native evidence.
3. Source/assertion/false-positive review: No product/test source changes in this harness; real exact-value/assertion laws remain unchanged. Passing this isolated harness alone cannot prove lifecycle or publication.

Child timer_disabled_runtime_retains_the_native_failure (inside workspace):
1. Contract: unsupported timer configuration retains exact native Tokio panic, exact uncertain caller ID, empty rows and closed admission.
2. Execution: parent PASS plus helper's child-status and exact one-PASS summary checks; two-second bound, exact-name child invocation.
3. Strength/source: original panic text and payload assertions retained; zero-selection, process failure and hung runtime all fail the parent.

Child readiness_release_allows_a_reentrant_stop_callback (inside workspace):
1. Contract: releasing pending readiness may synchronously reenter stop; observed worker completion retains no uncertainty.
2. Execution: parent PASS plus helper's child-status and exact one-PASS summary checks; two-second bound, exact-name child invocation.
3. Strength/source: actual native permit/waker path and observed shutdown; omission/mutation witnesses retained; a deadlock or zero selected test cannot pass.
