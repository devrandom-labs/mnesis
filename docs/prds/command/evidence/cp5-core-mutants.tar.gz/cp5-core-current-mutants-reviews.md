# CP5 current-head mutation review

Run39676299812, artifact12382418496, reviewed head1539509ae5c60977a6fb77469f5ae894e06e3e98.
20mutants:9caught/11unviable/0missed/0timeout. All21 outcome records and first
diagnostics inspected independently of the workflow verdict. No tracing/metrics
or native-database qualification is inferred from this core-only campaign.

Baseline three reviews: (1) all45 command laws, including192forced races and
256concurrent/256serial histories, original formats, receipts and failure custody;
(2) actual45PASS/one original ignored/five binaries/5.342s, no database;
(3) exact selected core source and unchanged assertions/filters/deadlines, all
bounded child invocations still independently require one passing case with
native-cause or reentrant-stop and bounded kill-and-wait oracles.

Each runtime mutant below receives the three distinct reviews recorded in its
row: threatened contract; actual execution; exact first failure/source strength.
Fail-fast does not imply that all45 laws ran. One original ignored in every row.

| Mutation | 1. Contract | 2. Actual execution | 3. First failure and strength |
| --- | --- | --- | --- |
| Engine Drop omitted | Exact unresolved original survives native completion | 11/45run,10PASS/1FAIL,0.458s | Independent generated history at support/history.rs:209 sees None versus exact Request3/base2/Add5; no fixture or compiler failure. |
| Shutdown cause returns None | Native abort cause remains available | 18/45run,17PASS/1FAIL,3.887s | Actual abrupt-loss law recovery.rs:815 cannot unwrap required cancellation cause; original request/late-write path remains. |
| Shutdown take_cause returns None | Taking cause retains real native cause | 19/45run,18PASS/1FAIL,3.668s | Actual abort/resume law recovery.rs:413 cannot take required cause; no mocked JoinError. |
| Worker abort omitted | Observed cancellation differs from operation timeout | 18/45run,17PASS/1FAIL,5.756s | Abrupt-loss law recovery.rs:815 sees missing native cancellation after natural operation expiry; no global mutation timeout counted as a catch. |
| Convenience send returns Ok without transferring request | Admission cannot fabricate successful transfer | 10/45run,9PASS/1FAIL,0.053s | Public aggregate adaptation.rs:465 sees Uncertain instead of required receipt after reply sender discarded. |
| poll_ready returns Ok without native reserve | Readiness must own bounded capacity | 19/45run,18PASS/1FAIL,3.717s | Actual public call panics in production host.rs:441: send_item called without poll_reserve. This is the exact removed native reservation, not fixture setup. |
| poll_ready lifecycle equality inverted | Running host accepts readiness | 19/45run,18PASS/1FAIL,3.839s | Actual public readiness recovery.rs:392 observes Closed on a running host. |
| Worker run omitted | Spawned worker must execute admitted work | 10/45run,9PASS/1FAIL,0.052s | Public adaptation.rs:465 observes Closed instead of receipt after actual worker exits. |
| run lifecycle equality inverted | Running worker executes requests | 10/45run,9PASS/1FAIL,0.053s | Same public receipt oracle sees Closed on unchanged real store/handler path. |

Each of eleven unviable mutations separately: (1) no runtime contract rejection
credited; (2) build101 before tests; (3) exact first compiler diagnostic inspected.
Two JoinError Default substitutions fail E0277; three Worker::poll substitutions
use absent Poll::new/from_iter (E0599), its fourth needs type inference E0283;
launch Result Default fails E0277; three poll_ready substitutions use absent
Poll::new/from_iter E0599; response dyn Future Default fails E0277. No source,
assertion, case count, workload, deadline or mutation gate weakened to get green.
