# CP5 application exporter protected delivery

PR420 headc4fed5f95f7ee07c4015041518e6312b36af5c00 (local GPG G; GitHub VALID).
Base533c1f5db4c487753d996e548c315013e69f5b1c. Normal ready + squash with exact
head guard, no admin/force/hook bypass. Merged2026-10-22T02:51:04Z as
60e7edb239ed66e7d119c5ecf7a2b8904fbb8998, parent533c1f5d, GitHub signature
verified=true/reason valid. Expected local merge-tree and original head tree
410edb749e0332e0e99cd2bf7db17d94a7b5b4e8 equal GitHub virtual21b4a41 tree and
actual protected commit tree. The virtual tree was read through its exact commit
API after delivery: a two-ref fetch's FETCH_HEAD had named main, so that fetch
line is not virtual-tree proof. No differing product/format was delivered.

44SUCCESS/one scheduled mutants-sweep SKIP/0active/0review threads before merge.
CI push39707698548/PR39707704401 bothSUCCESS. Actual push62/PR82 outcomes,
6zero-case compiler-only each,56/76nonzero. Default workspace1641/147bins/5original
exclusions/4slow,145.981s push/135.794s PR. Each Nix job24fresh (3corpus/1workspace/
20native adapter invocations). PR standalone20fresh native invocations separately;
push standalone264 is only cached result/run.log echo and is excluded. Five
command/example feature runs45/49/46/50/2; default workspace has3command/example
children, feature jobs9children, each separately three-reviewed. Every actual
harness outcome has three distinct reviews in retained records. Zero additional
runtime credit from package archive/log downloads or commit hooks.

Current mutants filter contains only crates/** adapters/** and reports no source
changes;0mutants/baseline runtime, no artifact. Previous69 library mutations
remain previous library evidence. Manual filter-off and empty-main controls are
recorded in the qualified exporter archive, not reclassified as this CI's catches.
Eight existing codec fuzz campaigns executed: four libFuzzer61s counters and four
AFL++60s final0saved crashes/0timeouts plus native crash verdict/CMPLOG checks.
No command-fuzz, database processor composition, uncertain-write failed-SDK,
15min soak, performance overhead, publication or server-consumer claim.

CP5 implementation/telemetry example delivered. Required CP6–CP9 remain active.
Native Fjall PR421's old-parent14Linux jobs now allSUCCESS but auto-rebased base
main has ancestry conflicts after squash; preserve clean feeab8df source and
qualify actual logs, then integrate main through a normal signed change. No
conflict bypass or product test assertion changes required by this observation.
