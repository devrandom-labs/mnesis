# Exporter current-head remaining CI reviews

Exact signed head c4fed5f95f7ee07c4015041518e6312b36af5c00; main533c1f5db4c487753d996e548c315013e69f5b1c. Push39707698548 and PR39707704401 terminal SUCCESS. PR58 earlier completed harness outcomes are reviewed in cp5-exporter-main-pr-completed-reviews.md; this record covers remaining PR24 Nix outcomes and all62 fresh push outcomes. Each workflow has6 zero-case compiler-only outcomes, so push56/PR76 nonzero. Standalone push Postgres output is cached result/run.log (plain264 summary, no native build/service execution), excluded; later plain PR264 echo likewise excluded. No new mutations: supported diff filter finds no crates/** or adapters/** change; no mutants artifact or baseline runs. Manual filter-off/empty-main controls remain the exporter counterexamples, not fresh CI mutation catches. Existing69 library mutations belong to the earlier metrics delivery.

## push 9_Features (mnesis-fjall).txt — outcome1

2026-10-22T02:00:47.0180745Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.43s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 9_Features (mnesis-fjall).txt — outcome2

2026-10-22T02:00:49.5572899Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.38s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 9_Features (mnesis-fjall).txt — outcome3

2026-10-22T02:00:52.0956727Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.38s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 3_Features (mnesis).txt — outcome1

2026-10-22T02:01:49.7370591Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 3_Features (mnesis).txt — outcome2

2026-10-22T02:01:49.8791855Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 3_Features (mnesis).txt — outcome3

2026-10-22T02:01:50.4330932Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 10_Features (mnesis-store).txt — outcome1

2026-10-22T02:00:05.3924962Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.68s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 10_Features (mnesis-store).txt — outcome2

2026-10-22T02:00:08.6960104Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 3.14s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 10_Features (mnesis-store).txt — outcome3

2026-10-22T02:00:16.9782559Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.79s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 6_Features (mnesis-postgres).txt — outcome1

2026-10-22T02:01:32.2326075Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 6_Features (mnesis-postgres).txt — outcome2

2026-10-22T02:01:32.3995420Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 6_Features (mnesis-postgres).txt — outcome3

2026-10-22T02:01:35.2276905Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 5_Features (mnesis-command).txt — outcome1

2026-10-22T02:02:15.3119824Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 5_Features (mnesis-command).txt — outcome2

2026-10-22T02:02:16.2224650Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 5_Features (mnesis-command).txt — outcome3

2026-10-22T02:02:17.6729906Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 5_Features (mnesis-command).txt — outcome4

2026-10-22T02:02:27.3829635Z      Summary [   3.580s] 45 tests run: 45 passed, 1 skipped

1. Contract/counterexamples: Command none feature laws retain request identity, exact retries, typed causes, observed worker completion and enabled instrumentation invariants.
2. Actual execution/selection/services: Actual45/49/46/50 selected cases for none/tracing/metrics/combined respectively; one original ignored measurement only. Real in-memory adapter, no SDK/native database in these binaries.
3. Assertion strength/source/false positives: Exact source/workloads/limits/selectors preserved; feature-only tests execute in their named modes, not inferred from compilation. Native panic payload, pending originals, bounded admission and precise metric labels/counts reject known lifecycle/accounting defects.

Reentrant child review: (1) exact wake/stop/Closed and normal observed completion; (2) actual same-executable exact selector, successful one-case summary and2s parent bound reached; (3) specific callback/result checks reject skipped or stuck child. Disabled-timer child review: (1) exact native timer panic, original uncertain ID, zero persisted rows and Closed; (2) actual same-executable one-case success/2s bound; (3) retained native cause/payload and exact result reject lost cause or fake completion. These are2children, not extra top-level suites.

## push 5_Features (mnesis-command).txt — outcome5

2026-10-22T02:02:39.3316303Z      Summary [   4.045s] 49 tests run: 49 passed, 1 skipped

1. Contract/counterexamples: Command tracing feature laws retain request identity, exact retries, typed causes, observed worker completion and enabled instrumentation invariants.
2. Actual execution/selection/services: Actual45/49/46/50 selected cases for none/tracing/metrics/combined respectively; one original ignored measurement only. Real in-memory adapter, no SDK/native database in these binaries.
3. Assertion strength/source/false positives: Exact source/workloads/limits/selectors preserved; feature-only tests execute in their named modes, not inferred from compilation. Native panic payload, pending originals, bounded admission and precise metric labels/counts reject known lifecycle/accounting defects.

Reentrant child review: (1) exact wake/stop/Closed and normal observed completion; (2) actual same-executable exact selector, successful one-case summary and2s parent bound reached; (3) specific callback/result checks reject skipped or stuck child. Disabled-timer child review: (1) exact native timer panic, original uncertain ID, zero persisted rows and Closed; (2) actual same-executable one-case success/2s bound; (3) retained native cause/payload and exact result reject lost cause or fake completion. These are2children, not extra top-level suites.

## push 5_Features (mnesis-command).txt — outcome6

2026-10-22T02:02:50.9948993Z      Summary [   3.934s] 46 tests run: 46 passed, 1 skipped

1. Contract/counterexamples: Command metrics feature laws retain request identity, exact retries, typed causes, observed worker completion and enabled instrumentation invariants.
2. Actual execution/selection/services: Actual45/49/46/50 selected cases for none/tracing/metrics/combined respectively; one original ignored measurement only. Real in-memory adapter, no SDK/native database in these binaries.
3. Assertion strength/source/false positives: Exact source/workloads/limits/selectors preserved; feature-only tests execute in their named modes, not inferred from compilation. Native panic payload, pending originals, bounded admission and precise metric labels/counts reject known lifecycle/accounting defects.

Reentrant child review: (1) exact wake/stop/Closed and normal observed completion; (2) actual same-executable exact selector, successful one-case summary and2s parent bound reached; (3) specific callback/result checks reject skipped or stuck child. Disabled-timer child review: (1) exact native timer panic, original uncertain ID, zero persisted rows and Closed; (2) actual same-executable one-case success/2s bound; (3) retained native cause/payload and exact result reject lost cause or fake completion. These are2children, not extra top-level suites.

## push 5_Features (mnesis-command).txt — outcome7

2026-10-22T02:03:04.2836758Z      Summary [   4.408s] 50 tests run: 50 passed, 1 skipped

1. Contract/counterexamples: Command combined feature laws retain request identity, exact retries, typed causes, observed worker completion and enabled instrumentation invariants.
2. Actual execution/selection/services: Actual45/49/46/50 selected cases for none/tracing/metrics/combined respectively; one original ignored measurement only. Real in-memory adapter, no SDK/native database in these binaries.
3. Assertion strength/source/false positives: Exact source/workloads/limits/selectors preserved; feature-only tests execute in their named modes, not inferred from compilation. Native panic payload, pending originals, bounded admission and precise metric labels/counts reject known lifecycle/accounting defects.

Reentrant child review: (1) exact wake/stop/Closed and normal observed completion; (2) actual same-executable exact selector, successful one-case summary and2s parent bound reached; (3) specific callback/result checks reject skipped or stuck child. Disabled-timer child review: (1) exact native timer panic, original uncertain ID, zero persisted rows and Closed; (2) actual same-executable one-case success/2s bound; (3) retained native cause/payload and exact result reject lost cause or fake completion. These are2children, not extra top-level suites.

## push 5_Features (mnesis-command).txt — outcome8

2026-10-22T02:03:16.5237865Z      Summary [   0.023s] 2 tests run: 2 passed, 0 skipped

1. Contract/counterexamples: Concrete SDK SpanData trace/parent identities, Prometheus exact bounded metrics, successful real writes during failed exporter flushes, observed native shutdown and actual CLI receipts/state.
2. Actual execution/selection/services: Actual2cases,0skipped at selected telemetry feature. Native CLI child executed and reaped within3s; no database. Includes concrete unavailable SDK exporter, not network outage or uncertain append.
3. Assertion strength/source/false positives: Exact receipts1/2, no-op0, state7→7, two decoded originals/facts,6 context-linked request spans and typed failed force_flush reject omission. Retained filter-off and empty-main controls fail. SDK batch generic callback timeout is not promised.

CLI child review: (1) real executable runs the receipt/duplicate/no-op/read/stop/resume/retry flow and emits native application export; (2) exact binary env path, success status/empty stderr and3s kill_on_drop bound checked by passing parent; (3) exact receipt/state line and exactly1 exported application name reject fake successful exit or disabled instrumentation. Not another top-level suite.

## push 11_Features (mnesis-inmemory).txt — outcome1

2026-10-22T01:55:22.4178697Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 11_Features (mnesis-inmemory).txt — outcome2

2026-10-22T01:55:22.5555360Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 11_Features (mnesis-inmemory).txt — outcome3

2026-10-22T01:55:24.4747432Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 13_Compile-fail tests.txt — outcome1

2026-10-22T01:57:04.6495013Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 91.16s

1. Contract/counterexamples: Actual kernel/macros/store compiler-negative/pass fixtures verify original expected diagnostics.
2. Actual execution/selection/services: Nonzero actual test harness counts/duration above, not cargo-check-only inference.
3. Assertion strength/source/false positives: Expected diagnostic files and exact source unchanged; assertions verify intended compilation outcome rather than arbitrary failure.

## push 13_Compile-fail tests.txt — outcome2

2026-10-22T01:57:31.6717434Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 13.11s

1. Contract/counterexamples: Actual kernel/macros/store compiler-negative/pass fixtures verify original expected diagnostics.
2. Actual execution/selection/services: Nonzero actual test harness counts/duration above, not cargo-check-only inference.
3. Assertion strength/source/false positives: Expected diagnostic files and exact source unchanged; assertions verify intended compilation outcome rather than arbitrary failure.

## push 13_Compile-fail tests.txt — outcome3

2026-10-22T01:57:51.9898145Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 14.17s

1. Contract/counterexamples: Actual kernel/macros/store compiler-negative/pass fixtures verify original expected diagnostics.
2. Actual execution/selection/services: Nonzero actual test harness counts/duration above, not cargo-check-only inference.
3. Assertion strength/source/false positives: Expected diagnostic files and exact source unchanged; assertions verify intended compilation outcome rather than arbitrary failure.

## push 12_Nix Flake Check.txt — outcome1

2026-10-22T01:58:41.9796624Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Original canonical wire/CBOR/event-type corpus laws call the real decode/validation body; malformed input must preserve bounded parsing/round-trip invariants.
2. Actual execution/selection/services: Actual fresh corpus harness, counts and1s runtime shown above; no service or command-fuzz coverage implied.
3. Assertion strength/source/false positives: Production fuzz-common bodies and checked corpus unchanged at reviewed source; successful parser replay is not processor fuzz qualification.

## push 12_Nix Flake Check.txt — outcome2

2026-10-22T01:58:42.9817232Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Original canonical wire/CBOR/event-type corpus laws call the real decode/validation body; malformed input must preserve bounded parsing/round-trip invariants.
2. Actual execution/selection/services: Actual fresh corpus harness, counts and1s runtime shown above; no service or command-fuzz coverage implied.
3. Assertion strength/source/false positives: Production fuzz-common bodies and checked corpus unchanged at reviewed source; successful parser replay is not processor fuzz qualification.

## push 12_Nix Flake Check.txt — outcome3

2026-10-22T01:58:43.9839459Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Original canonical wire/CBOR/event-type corpus laws call the real decode/validation body; malformed input must preserve bounded parsing/round-trip invariants.
2. Actual execution/selection/services: Actual fresh corpus harness, counts and1s runtime shown above; no service or command-fuzz coverage implied.
3. Assertion strength/source/false positives: Production fuzz-common bodies and checked corpus unchanged at reviewed source; successful parser replay is not processor fuzz qualification.

## push 12_Nix Flake Check.txt — outcome4

2026-10-22T02:12:25.2207078Z mnesis-nextest>      Summary [ 145.981s] 1641 tests run: 1641 passed (4 slow), 5 skipped

1. Contract/counterexamples: Whole workspace default feature laws include45command invariants and the actual neutral example; unchanged core/store/adapter tests retain their own protocol/lifecycle/isolation assertions.
2. Actual execution/selection/services: Actual1641PASS/147binaries/5original exclusions/4slow; no missing-service legacy adapter pass credited as native proof. Default example does not install SDK. Native database coverage is separately counted under the hook.
3. Assertion strength/source/false positives: Reviewed source/workload/dependency lock unchanged; exact compiler-negative diagnostics and bounded native child assertions retained. Default feature run cannot certify enabled trace/metrics/SDK or processor/Postgres.

Three child reviews: reentrant (1 exact callback/normal report;2 actual exact child status/one-case/2s;3 rejects deadlock/skipped child), disabled timers (1 native panic/original/empty store;2 actual exact child/2s;3 rejects erased terminal cause), default CLI (1 exact native receipts/state/resume/retry;2 actual executable/3s success/empty stderr;3 exact output rejects empty main). Children are not inflated into suite counts.

## push 12_Nix Flake Check.txt — outcome5

2026-10-22T02:21:11.1974186Z mnesis-postgres-integration>      Summary [   0.101s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome6

2026-10-22T02:21:16.1393503Z mnesis-postgres-integration>      Summary [   0.686s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome7

2026-10-22T02:21:22.0889019Z mnesis-postgres-integration>      Summary [   1.692s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome8

2026-10-22T02:21:26.5636686Z mnesis-postgres-integration>      Summary [   0.113s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome9

2026-10-22T02:21:32.2906140Z mnesis-postgres-integration>      Summary [   1.453s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome10

2026-10-22T02:21:39.6237257Z mnesis-postgres-integration>      Summary [   2.776s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome11

2026-10-22T02:21:43.9022625Z mnesis-postgres-integration>      Summary [   0.048s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome12

2026-10-22T02:22:54.8236619Z mnesis-postgres-integration>      Summary [  66.258s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome13

2026-10-22T02:22:57.7873513Z mnesis-postgres-integration>      Summary [   0.058s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome14

2026-10-22T02:23:39.5602956Z mnesis-postgres-integration>      Summary [  38.890s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome15

2026-10-22T02:23:43.0682083Z mnesis-postgres-integration>      Summary [   0.402s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome16

2026-10-22T02:24:31.4792712Z mnesis-postgres-integration>      Summary [  45.204s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome17

2026-10-22T02:24:34.5603613Z mnesis-postgres-integration>      Summary [   0.068s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome18

2026-10-22T02:25:22.4465228Z mnesis-postgres-integration>      Summary [  44.825s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome19

2026-10-22T02:25:25.7131306Z mnesis-postgres-integration>      Summary [   0.146s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome20

2026-10-22T02:26:09.6762464Z mnesis-postgres-integration>      Summary [  40.707s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome21

2026-10-22T02:26:12.7154349Z mnesis-postgres-integration>      Summary [   0.077s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome22

2026-10-22T02:26:57.1962657Z mnesis-postgres-integration>      Summary [  41.435s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome23

2026-10-22T02:27:01.2143381Z mnesis-postgres-integration>      Summary [   1.065s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 12_Nix Flake Check.txt — outcome24

2026-10-22T02:27:44.1380409Z mnesis-postgres-integration>      Summary [  39.842s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## push 4_Features (mnesis-store-testing).txt — outcome1

2026-10-22T02:01:55.4654324Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Compiler-only unit harness: no executed behavioral cases; feature/dependency isolation is the only evidence.
2. Actual execution/selection/services: Actual zero-case outcome, retained explicitly; no runtime/service/processor acceptance credited.
3. Assertion strength/source/false positives: No assertion executes. A zero-case success cannot satisfy a runtime acceptance requirement.

## push 4_Features (mnesis-store-testing).txt — outcome2

2026-10-22T02:01:55.5632529Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Compiler-only unit harness: no executed behavioral cases; feature/dependency isolation is the only evidence.
2. Actual execution/selection/services: Actual zero-case outcome, retained explicitly; no runtime/service/processor acceptance credited.
3. Assertion strength/source/false positives: No assertion executes. A zero-case success cannot satisfy a runtime acceptance requirement.

## push 4_Features (mnesis-store-testing).txt — outcome3

2026-10-22T02:01:55.6600448Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Compiler-only unit harness: no executed behavioral cases; feature/dependency isolation is the only evidence.
2. Actual execution/selection/services: Actual zero-case outcome, retained explicitly; no runtime/service/processor acceptance credited.
3. Assertion strength/source/false positives: No assertion executes. A zero-case success cannot satisfy a runtime acceptance requirement.

## push 2_Features (mnesis-wake-nostd).txt — outcome1

2026-10-22T02:02:12.4277441Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Compiler-only unit harness: no executed behavioral cases; feature/dependency isolation is the only evidence.
2. Actual execution/selection/services: Actual zero-case outcome, retained explicitly; no runtime/service/processor acceptance credited.
3. Assertion strength/source/false positives: No assertion executes. A zero-case success cannot satisfy a runtime acceptance requirement.

## push 2_Features (mnesis-wake-nostd).txt — outcome2

2026-10-22T02:02:12.5265322Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Compiler-only unit harness: no executed behavioral cases; feature/dependency isolation is the only evidence.
2. Actual execution/selection/services: Actual zero-case outcome, retained explicitly; no runtime/service/processor acceptance credited.
3. Assertion strength/source/false positives: No assertion executes. A zero-case success cannot satisfy a runtime acceptance requirement.

## push 2_Features (mnesis-wake-nostd).txt — outcome3

2026-10-22T02:02:12.6213434Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Compiler-only unit harness: no executed behavioral cases; feature/dependency isolation is the only evidence.
2. Actual execution/selection/services: Actual zero-case outcome, retained explicitly; no runtime/service/processor acceptance credited.
3. Assertion strength/source/false positives: No assertion executes. A zero-case success cannot satisfy a runtime acceptance requirement.

## push 8_Features (mnesis-wake).txt — outcome1

2026-10-22T02:00:35.7854818Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 8_Features (mnesis-wake).txt — outcome2

2026-10-22T02:00:36.0609785Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 8_Features (mnesis-wake).txt — outcome3

2026-10-22T02:00:36.3369573Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 1_Features (mnesis-macros).txt — outcome1

2026-10-22T02:02:20.9872486Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 1_Features (mnesis-macros).txt — outcome2

2026-10-22T02:02:21.0936538Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## push 1_Features (mnesis-macros).txt — outcome3

2026-10-22T02:02:21.2018563Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Actual isolated owner library unit laws execute for the workflow's default/no-default/all-features modes; exact counts/durations above.
2. Actual execution/selection/services: Nonzero real unit harness, no integration/database/native recovery inference. Postgres11unit cases are not database tests.
3. Assertion strength/source/false positives: Exact-head source/assertions and isolated mode commands unchanged. Unit harness feature isolation is separate from downstream clean package qualification; no skipped or compiler-only evidence promoted.

## PR Nix — outcome1

2026-10-22T01:54:40.8594985Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Original canonical wire/CBOR/event-type corpus laws call the real decode/validation body; malformed input must preserve bounded parsing/round-trip invariants.
2. Actual execution/selection/services: Actual fresh corpus harness, counts and1s runtime shown above; no service or command-fuzz coverage implied.
3. Assertion strength/source/false positives: Production fuzz-common bodies and checked corpus unchanged at reviewed source; successful parser replay is not processor fuzz qualification.

## PR Nix — outcome2

2026-10-22T01:54:41.8610707Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Original canonical wire/CBOR/event-type corpus laws call the real decode/validation body; malformed input must preserve bounded parsing/round-trip invariants.
2. Actual execution/selection/services: Actual fresh corpus harness, counts and1s runtime shown above; no service or command-fuzz coverage implied.
3. Assertion strength/source/false positives: Production fuzz-common bodies and checked corpus unchanged at reviewed source; successful parser replay is not processor fuzz qualification.

## PR Nix — outcome3

2026-10-22T01:54:42.8628187Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Original canonical wire/CBOR/event-type corpus laws call the real decode/validation body; malformed input must preserve bounded parsing/round-trip invariants.
2. Actual execution/selection/services: Actual fresh corpus harness, counts and1s runtime shown above; no service or command-fuzz coverage implied.
3. Assertion strength/source/false positives: Production fuzz-common bodies and checked corpus unchanged at reviewed source; successful parser replay is not processor fuzz qualification.

## PR Nix — outcome4

2026-10-22T02:07:32.0550810Z mnesis-nextest>      Summary [ 135.794s] 1641 tests run: 1641 passed (4 slow), 5 skipped

1. Contract/counterexamples: Whole workspace default feature laws include45command invariants and the actual neutral example; unchanged core/store/adapter tests retain their own protocol/lifecycle/isolation assertions.
2. Actual execution/selection/services: Actual1641PASS/147binaries/5original exclusions/4slow; no missing-service legacy adapter pass credited as native proof. Default example does not install SDK. Native database coverage is separately counted under the hook.
3. Assertion strength/source/false positives: Reviewed source/workload/dependency lock unchanged; exact compiler-negative diagnostics and bounded native child assertions retained. Default feature run cannot certify enabled trace/metrics/SDK or processor/Postgres.

Three child reviews: reentrant (1 exact callback/normal report;2 actual exact child status/one-case/2s;3 rejects deadlock/skipped child), disabled timers (1 native panic/original/empty store;2 actual exact child/2s;3 rejects erased terminal cause), default CLI (1 exact native receipts/state/resume/retry;2 actual executable/3s success/empty stderr;3 exact output rejects empty main). Children are not inflated into suite counts.

## PR Nix — outcome5

2026-10-22T02:15:34.3028470Z mnesis-postgres-integration>      Summary [   0.126s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome6

2026-10-22T02:15:38.6821199Z mnesis-postgres-integration>      Summary [   0.343s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome7

2026-10-22T02:15:43.0076778Z mnesis-postgres-integration>      Summary [   0.223s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome8

2026-10-22T02:15:47.5743530Z mnesis-postgres-integration>      Summary [   0.555s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome9

2026-10-22T02:15:53.2321767Z mnesis-postgres-integration>      Summary [   1.626s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome10

2026-10-22T02:15:59.0098149Z mnesis-postgres-integration>      Summary [   1.594s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome11

2026-10-22T02:16:03.1346680Z mnesis-postgres-integration>      Summary [   0.050s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome12

2026-10-22T02:17:13.6712087Z mnesis-postgres-integration>      Summary [  66.377s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome13

2026-10-22T02:17:16.4707276Z mnesis-postgres-integration>      Summary [   0.055s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome14

2026-10-22T02:17:56.4186420Z mnesis-postgres-integration>      Summary [  37.209s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome15

2026-10-22T02:17:59.6277311Z mnesis-postgres-integration>      Summary [   0.267s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome16

2026-10-22T02:18:46.3936416Z mnesis-postgres-integration>      Summary [  43.695s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome17

2026-10-22T02:18:49.3046434Z mnesis-postgres-integration>      Summary [   0.071s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome18

2026-10-22T02:19:35.5567667Z mnesis-postgres-integration>      Summary [  43.328s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome19

2026-10-22T02:19:38.8016845Z mnesis-postgres-integration>      Summary [   0.269s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome20

2026-10-22T02:20:22.1542929Z mnesis-postgres-integration>      Summary [  40.262s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome21

2026-10-22T02:20:25.0534944Z mnesis-postgres-integration>      Summary [   0.075s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome22

2026-10-22T02:21:07.4823697Z mnesis-postgres-integration>      Summary [  39.494s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome23

2026-10-22T02:21:11.3780890Z mnesis-postgres-integration>      Summary [   1.061s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## PR Nix — outcome24

2026-10-22T02:21:53.2026824Z mnesis-postgres-integration>      Summary [  38.899s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Native adapter sequence/isolation/migration/cancellation/durability laws selected by this actual archive. SQL observations must reject partial writes and wrong uncertainty; this is adapter coverage, not processor/Postgres composition.
2. Actual execution/selection/services: Fresh nextest invocation under Nix postgresqlTestHook: actual initialized Unix service and independent SELECT1; actual counts/selection/time above. Seven full feature archives264/149/168/176/173/174/150 and13 single-case mandatory selectors; no env-absent skip accepted.
3. Assertion strength/source/false positives: Exact source/archive selection and no-tests=fail/serial unchanged; full selected counts0skipped, smoke exclusions explicit. Strong inherited transaction/independent-control assertions retained; no processor/SDK native claim.

## Existing codec fuzz campaigns

/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/7_deep-fuzz (wire_decode_frame).txt:2026-10-22T01:50:14.6421877Z HEAD is now at 21b4a41 Merge c4fed5f95f7ee07c4015041518e6312b36af5c00 into 533c1f5db4c487753d996e548c315013e69f5b1c
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/7_deep-fuzz (wire_decode_frame).txt:2026-10-22T01:52:46.9512526Z Done 8773229 runs in 61 second(s)
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/8_deep-fuzz (cbor_decode_header).txt:2026-10-22T01:49:17.9577188Z HEAD is now at 21b4a41 Merge c4fed5f95f7ee07c4015041518e6312b36af5c00 into 533c1f5db4c487753d996e548c315013e69f5b1c
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/8_deep-fuzz (cbor_decode_header).txt:2026-10-22T01:51:33.0460963Z Done 2343353 runs in 61 second(s)
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/2_deep-fuzz (value_event_type).txt:2026-10-22T01:55:28.7201501Z HEAD is now at 21b4a41 Merge c4fed5f95f7ee07c4015041518e6312b36af5c00 into 533c1f5db4c487753d996e548c315013e69f5b1c
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/2_deep-fuzz (value_event_type).txt:2026-10-22T01:58:00.2974947Z Done 5680350 runs in 61 second(s)
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/1_deep-fuzz (cbor_decode_chunk).txt:2026-10-22T01:56:32.2342218Z HEAD is now at 21b4a41 Merge c4fed5f95f7ee07c4015041518e6312b36af5c00 into 533c1f5db4c487753d996e548c315013e69f5b1c
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/1_deep-fuzz (cbor_decode_chunk).txt:2026-10-22T01:58:42.2537448Z Done 1740515 runs in 61 second(s)
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/3_deep-fuzz-afl (cbor_decode_chunk).txt:2026-10-22T01:53:20.8766495Z HEAD is now at 21b4a41 Merge c4fed5f95f7ee07c4015041518e6312b36af5c00 into 533c1f5db4c487753d996e548c315013e69f5b1c
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/3_deep-fuzz-afl (cbor_decode_chunk).txt:2026-10-22T01:56:24.9690280Z +++ Testing aborted programmatically +++
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/3_deep-fuzz-afl (cbor_decode_chunk).txt:2026-10-22T01:56:24.9691111Z [0m[1;93m[!] [0mTime limit was reached
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/3_deep-fuzz-afl (cbor_decode_chunk).txt:2026-10-22T01:56:24.9692965Z [1;94m[*] [0mStatistics: 10 new corpus items found, 43.52% coverage achieved, 0 crashes saved, 0 timeouts saved, total runtime 0 days, 0 hrs, 1 min, 0 sec[0m
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/4_deep-fuzz-afl (value_event_type).txt:2026-10-22T01:52:11.3269640Z HEAD is now at 21b4a41 Merge c4fed5f95f7ee07c4015041518e6312b36af5c00 into 533c1f5db4c487753d996e548c315013e69f5b1c
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/4_deep-fuzz-afl (value_event_type).txt:2026-10-22T01:55:18.5824989Z +++ Testing aborted programmatically +++
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/4_deep-fuzz-afl (value_event_type).txt:2026-10-22T01:55:18.5825659Z [0m[1;93m[!] [0mTime limit was reached
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/4_deep-fuzz-afl (value_event_type).txt:2026-10-22T01:55:18.5826715Z [1;94m[*] [0mStatistics: 0 new corpus items found, 8.31% coverage achieved, 0 crashes saved, 0 timeouts saved, total runtime 0 days, 0 hrs, 1 min, 0 sec[0m
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/6_deep-fuzz-afl (wire_decode_frame).txt:2026-10-22T01:50:13.5837521Z HEAD is now at 21b4a41 Merge c4fed5f95f7ee07c4015041518e6312b36af5c00 into 533c1f5db4c487753d996e548c315013e69f5b1c
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/6_deep-fuzz-afl (wire_decode_frame).txt:2026-10-22T01:53:08.2045478Z +++ Testing aborted programmatically +++
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/6_deep-fuzz-afl (wire_decode_frame).txt:2026-10-22T01:53:08.2045844Z [0m[1;93m[!] [0mTime limit was reached
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/6_deep-fuzz-afl (wire_decode_frame).txt:2026-10-22T01:53:08.2046647Z [1;94m[*] [0mStatistics: 0 new corpus items found, 34.33% coverage achieved, 0 crashes saved, 0 timeouts saved, total runtime 0 days, 0 hrs, 1 min, 0 sec[0m
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/5_deep-fuzz-afl (cbor_decode_header).txt:2026-10-22T01:52:02.1874620Z HEAD is now at 21b4a41 Merge c4fed5f95f7ee07c4015041518e6312b36af5c00 into 533c1f5db4c487753d996e548c315013e69f5b1c
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/5_deep-fuzz-afl (cbor_decode_header).txt:2026-10-22T01:54:40.6869646Z +++ Testing aborted programmatically +++
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/5_deep-fuzz-afl (cbor_decode_header).txt:2026-10-22T01:54:40.6869860Z [0m[1;93m[!] [0mTime limit was reached
/tmp/mnesis-command-start-20261021/cp5-exporter-current-fuzz/5_deep-fuzz-afl (cbor_decode_header).txt:2026-10-22T01:54:40.6870297Z [1;94m[*] [0mStatistics: 2 new corpus items found, 47.61% coverage achieved, 0 crashes saved, 0 timeouts saved, total runtime 0 days, 0 hrs, 1 min, 0 sec[0m


### wire_decode_frame — libFuzzer

1. Contract/counterexamples: Existing fuzz-common real frame parsing and successful decode invariants; no command decoder/history fuzz claim.
2. Actual execution/selection/services: Native engine ran against PR virtual21b4a41 (signed headc4fed/main533c); actual61s nonzero run counter retained above. No database or exporter acceptance implied.
3. Assertions/source/false positives: Shared production parser body and workflow unchanged; successful native engine plus its crash verdict, not mere build, is the evidence. Bounded campaign cannot prove absence of defects; CP7 command fuzz remains open.

### wire_decode_frame — AFL++/CMPLOG

1. Contract/counterexamples: Existing fuzz-common real frame parsing and successful decode invariants; no command decoder/history fuzz claim.
2. Actual execution/selection/services: Native engine ran against PR virtual21b4a41 (signed headc4fed/main533c); actual60s bound, final0saved crashes/0timeouts and successful reject-saved-crashes/CMPLOG job steps. No database or exporter acceptance implied.
3. Assertions/source/false positives: Shared production parser body and workflow unchanged; successful native engine plus its crash verdict, not mere build, is the evidence. Bounded campaign cannot prove absence of defects; CP7 command fuzz remains open.

### cbor_decode_header — libFuzzer

1. Contract/counterexamples: Existing fuzz-common bounded backup header decode and canonical re-encoding; no command decoder/history fuzz claim.
2. Actual execution/selection/services: Native engine ran against PR virtual21b4a41 (signed headc4fed/main533c); actual61s nonzero run counter retained above. No database or exporter acceptance implied.
3. Assertions/source/false positives: Shared production parser body and workflow unchanged; successful native engine plus its crash verdict, not mere build, is the evidence. Bounded campaign cannot prove absence of defects; CP7 command fuzz remains open.

### cbor_decode_header — AFL++/CMPLOG

1. Contract/counterexamples: Existing fuzz-common bounded backup header decode and canonical re-encoding; no command decoder/history fuzz claim.
2. Actual execution/selection/services: Native engine ran against PR virtual21b4a41 (signed headc4fed/main533c); actual60s bound, final0saved crashes/0timeouts and successful reject-saved-crashes/CMPLOG job steps. No database or exporter acceptance implied.
3. Assertions/source/false positives: Shared production parser body and workflow unchanged; successful native engine plus its crash verdict, not mere build, is the evidence. Bounded campaign cannot prove absence of defects; CP7 command fuzz remains open.

### cbor_decode_chunk — libFuzzer

1. Contract/counterexamples: Existing fuzz-common bounded chunk parsing and decoded-record invariants; no command decoder/history fuzz claim.
2. Actual execution/selection/services: Native engine ran against PR virtual21b4a41 (signed headc4fed/main533c); actual61s nonzero run counter retained above. No database or exporter acceptance implied.
3. Assertions/source/false positives: Shared production parser body and workflow unchanged; successful native engine plus its crash verdict, not mere build, is the evidence. Bounded campaign cannot prove absence of defects; CP7 command fuzz remains open.

### cbor_decode_chunk — AFL++/CMPLOG

1. Contract/counterexamples: Existing fuzz-common bounded chunk parsing and decoded-record invariants; no command decoder/history fuzz claim.
2. Actual execution/selection/services: Native engine ran against PR virtual21b4a41 (signed headc4fed/main533c); actual60s bound, final0saved crashes/0timeouts and successful reject-saved-crashes/CMPLOG job steps. No database or exporter acceptance implied.
3. Assertions/source/false positives: Shared production parser body and workflow unchanged; successful native engine plus its crash verdict, not mere build, is the evidence. Bounded campaign cannot prove absence of defects; CP7 command fuzz remains open.

### value_event_type — libFuzzer

1. Contract/counterexamples: Existing fuzz-common UTF-8/event-name validity and length boundaries; no command decoder/history fuzz claim.
2. Actual execution/selection/services: Native engine ran against PR virtual21b4a41 (signed headc4fed/main533c); actual61s nonzero run counter retained above. No database or exporter acceptance implied.
3. Assertions/source/false positives: Shared production parser body and workflow unchanged; successful native engine plus its crash verdict, not mere build, is the evidence. Bounded campaign cannot prove absence of defects; CP7 command fuzz remains open.

### value_event_type — AFL++/CMPLOG

1. Contract/counterexamples: Existing fuzz-common UTF-8/event-name validity and length boundaries; no command decoder/history fuzz claim.
2. Actual execution/selection/services: Native engine ran against PR virtual21b4a41 (signed headc4fed/main533c); actual60s bound, final0saved crashes/0timeouts and successful reject-saved-crashes/CMPLOG job steps. No database or exporter acceptance implied.
3. Assertions/source/false positives: Shared production parser body and workflow unchanged; successful native engine plus its crash verdict, not mere build, is the evidence. Bounded campaign cannot prove absence of defects; CP7 command fuzz remains open.
