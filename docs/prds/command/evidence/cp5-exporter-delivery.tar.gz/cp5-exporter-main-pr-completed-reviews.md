# Exporter exact-head PR completed-job reviews

PR run39707704401 headc4fed5f95f7ee07c4015041518e6312b36af5c00. Terminal completed jobs only; Nix job is still live and not credited here. Raw per-job logs retained. Three compiler,30library,4command-feature,1enabled SDK example and20fresh native adapter harnesses=58outcomes;6zero-case library harnesses compilation-only. The later plain264 native summary is a log echo, not a new run. Separate command and CLI children require actual parent assertions and are not inflated into suite counts. No processor/Postgres/CP6 performance/publication proof.

## Compile-fail tests: compiler harness 0

2026-10-22T01:52:29.3345953Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 118.85s

1. Contract/counterexamples: Original compiler-negative/pass contracts execute and verify expected diagnostics, not inferred from check-only compilation.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518148.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Compile-fail tests: compiler harness 1

2026-10-22T01:53:01.6060568Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 14.43s

1. Contract/counterexamples: Original compiler-negative/pass contracts execute and verify expected diagnostics, not inferred from check-only compilation.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518148.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Compile-fail tests: compiler harness 2

2026-10-22T01:53:27.3052792Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 18.15s

1. Contract/counterexamples: Original compiler-negative/pass contracts execute and verify expected diagnostics, not inferred from check-only compilation.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518148.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-command): default

2026-10-22T01:55:08.7549584Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518435.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-command): no-default

2026-10-22T01:55:09.3281858Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518435.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-command): all-features

2026-10-22T01:55:10.2186806Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518435.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-command): none

2026-10-22T01:55:15.5290490Z      Summary [   1.485s] 45 tests run: 45 passed, 1 skipped

1. Contract/counterexamples: Original45command laws plus selected4tracing and/or seven-profile metric case preserve identity/CAS/uncertainty/native completion and instrumentation accounting.
2. Execution/selection/services: Actual nonzero nextest selection;1original ignored measurement, two original bounded child cases reached. In-memory stores, no SDK exporter in command binaries. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518435.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

Reentrant child separately: (1) exact wake1/stop/Closed/normal join, (2) actual successful parent checks exact-one/status/2s, (3) exact callback/results reject skipped/stuck process. Timer child separately: (1) exact native panic/original uncertain ID/zero rows/Closed/empty report, (2) actual successful parent checks exact-one/status/2s, (3) native cause/result rejects wrong/missing child. Not extra top-level suites.

## Features (mnesis-command): tracing

2026-10-22T01:55:22.2378927Z      Summary [   1.595s] 49 tests run: 49 passed, 1 skipped

1. Contract/counterexamples: Original45command laws plus selected4tracing and/or seven-profile metric case preserve identity/CAS/uncertainty/native completion and instrumentation accounting.
2. Execution/selection/services: Actual nonzero nextest selection;1original ignored measurement, two original bounded child cases reached. In-memory stores, no SDK exporter in command binaries. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518435.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

Reentrant child separately: (1) exact wake1/stop/Closed/normal join, (2) actual successful parent checks exact-one/status/2s, (3) exact callback/results reject skipped/stuck process. Timer child separately: (1) exact native panic/original uncertain ID/zero rows/Closed/empty report, (2) actual successful parent checks exact-one/status/2s, (3) native cause/result rejects wrong/missing child. Not extra top-level suites.

## Features (mnesis-command): metrics

2026-10-22T01:55:28.5589211Z      Summary [   1.541s] 46 tests run: 46 passed, 1 skipped

1. Contract/counterexamples: Original45command laws plus selected4tracing and/or seven-profile metric case preserve identity/CAS/uncertainty/native completion and instrumentation accounting.
2. Execution/selection/services: Actual nonzero nextest selection;1original ignored measurement, two original bounded child cases reached. In-memory stores, no SDK exporter in command binaries. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518435.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

Reentrant child separately: (1) exact wake1/stop/Closed/normal join, (2) actual successful parent checks exact-one/status/2s, (3) exact callback/results reject skipped/stuck process. Timer child separately: (1) exact native panic/original uncertain ID/zero rows/Closed/empty report, (2) actual successful parent checks exact-one/status/2s, (3) native cause/result rejects wrong/missing child. Not extra top-level suites.

## Features (mnesis-command): combined

2026-10-22T01:55:35.9598759Z      Summary [   1.637s] 50 tests run: 50 passed, 1 skipped

1. Contract/counterexamples: Original45command laws plus selected4tracing and/or seven-profile metric case preserve identity/CAS/uncertainty/native completion and instrumentation accounting.
2. Execution/selection/services: Actual nonzero nextest selection;1original ignored measurement, two original bounded child cases reached. In-memory stores, no SDK exporter in command binaries. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518435.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

Reentrant child separately: (1) exact wake1/stop/Closed/normal join, (2) actual successful parent checks exact-one/status/2s, (3) exact callback/results reject skipped/stuck process. Timer child separately: (1) exact native panic/original uncertain ID/zero rows/Closed/empty report, (2) actual successful parent checks exact-one/status/2s, (3) native cause/result rejects wrong/missing child. Not extra top-level suites.

## Features (mnesis-command): enabled exporter example

2026-10-22T01:55:43.7145011Z      Summary [   0.013s] 2 tests run: 2 passed, 0 skipped

1. Contract/counterexamples: Actual SDK context/Prometheus collection, concrete unavailable-exporter flushes, unchanged real command receipts/no-op/state/data and SDK shutdown. Actual CLI binary must emit exact receipt/state and native exported application scope.
2. Execution/selection/services: Actual2cases/0skip/0.013s, including native binary child. Linux test duration is not a performance distribution. No database/network-outage/queue-overflow/uncertain-write SDK claim. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518435.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; filter-off and empty-main controls separately fail, rejecting exporter omission and fake successful exit. Keep limitations visible.

CLI child separately: (1) exact independent receipt/no-op/duplicate/retry/state7→7 summary and exported application span, (2) actual successful bounded3s process/empty stderr/concurrent pipes, (3) exact output and native span field reject empty flow or missing SDK setup. Not a third nextest case.

## Features (mnesis-wake): default

2026-10-22T01:52:34.6784503Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518453.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-wake): no-default

2026-10-22T01:52:34.9230615Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518453.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-wake): all-features

2026-10-22T01:52:35.1966238Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518453.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 0

2026-10-22T02:04:56.1604527Z mnesis-postgres-integration>      Summary [   0.093s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 1

2026-10-22T02:05:00.9220659Z mnesis-postgres-integration>      Summary [   0.717s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 2

2026-10-22T02:05:06.8893542Z mnesis-postgres-integration>      Summary [   1.943s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 3

2026-10-22T02:05:11.4359789Z mnesis-postgres-integration>      Summary [   0.542s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 4

2026-10-22T02:05:17.2296365Z mnesis-postgres-integration>      Summary [   1.755s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 5

2026-10-22T02:05:23.3670954Z mnesis-postgres-integration>      Summary [   2.071s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 6

2026-10-22T02:05:27.4746232Z mnesis-postgres-integration>      Summary [   0.047s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 7

2026-10-22T02:06:37.5650037Z mnesis-postgres-integration>      Summary [  65.552s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 8

2026-10-22T02:06:40.3579507Z mnesis-postgres-integration>      Summary [   0.055s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 9

2026-10-22T02:07:22.5434154Z mnesis-postgres-integration>      Summary [  39.454s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 10

2026-10-22T02:07:25.8270082Z mnesis-postgres-integration>      Summary [   0.324s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 11

2026-10-22T02:08:12.5047119Z mnesis-postgres-integration>      Summary [  43.598s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 12

2026-10-22T02:08:15.4039023Z mnesis-postgres-integration>      Summary [   0.070s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 13

2026-10-22T02:09:02.4850283Z mnesis-postgres-integration>      Summary [  44.164s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 14

2026-10-22T02:09:05.7080181Z mnesis-postgres-integration>      Summary [   0.246s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 15

2026-10-22T02:09:49.3708787Z mnesis-postgres-integration>      Summary [  40.589s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 16

2026-10-22T02:09:52.2844133Z mnesis-postgres-integration>      Summary [   0.076s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 17

2026-10-22T02:10:35.1986999Z mnesis-postgres-integration>      Summary [  39.707s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 18

2026-10-22T02:10:38.8287756Z mnesis-postgres-integration>      Summary [   1.063s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Postgres Integration: native profile 19

2026-10-22T02:11:21.1959136Z mnesis-postgres-integration>      Summary [  39.432s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Original native adapter laws in the selected exact smoke or full feature profile retain ordering/atomicity/checkpoint/recovery/resource assertions. Not processor/backend composition.
2. Execution/selection/services: Actual prefixed fresh invocation above, verified disposable PostgreSQL readiness/migrations; smoke exclusions not executed. No missing-service green credit or counted plain output echo. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518454.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-fjall): default

2026-10-22T02:00:02.8845846Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.52s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518469.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-fjall): no-default

2026-10-22T02:00:05.6304564Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.59s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518469.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-fjall): all-features

2026-10-22T02:00:08.3299680Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.53s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518469.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-postgres): default

2026-10-22T01:56:55.5637672Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518476.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-postgres): no-default

2026-10-22T01:56:55.7249690Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518476.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-postgres): all-features

2026-10-22T01:56:58.7516762Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518476.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-macros): default

2026-10-22T01:57:37.6923062Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518479.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-macros): no-default

2026-10-22T01:57:37.8631028Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518479.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-macros): all-features

2026-10-22T01:57:37.9804974Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518479.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-inmemory): default

2026-10-22T01:56:22.4067230Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518518.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-inmemory): no-default

2026-10-22T01:56:22.5236350Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518518.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-inmemory): all-features

2026-10-22T01:56:24.0515815Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Empty unit harness, compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case result above; no nonzero runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518518.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-wake-nostd): default

2026-10-22T02:00:25.5393759Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Empty unit harness, compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case result above; no nonzero runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518536.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-wake-nostd): no-default

2026-10-22T02:00:25.6674740Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Empty unit harness, compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case result above; no nonzero runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518536.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-wake-nostd): all-features

2026-10-22T02:00:25.7940718Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Empty unit harness, compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case result above; no nonzero runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518536.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-store-testing): default

2026-10-22T01:59:38.7207565Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Empty unit harness, compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case result above; no nonzero runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518574.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-store-testing): no-default

2026-10-22T01:59:38.8330319Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Empty unit harness, compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case result above; no nonzero runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518574.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-store-testing): all-features

2026-10-22T01:59:38.9449151Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Empty unit harness, compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case result above; no nonzero runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518574.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-store): default

2026-10-22T01:59:18.5060921Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.37s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518580.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-store): no-default

2026-10-22T01:59:20.1520299Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.55s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518580.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis-store): all-features

2026-10-22T01:59:24.9112161Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.57s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518580.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis): default

2026-10-22T01:59:22.0924727Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518668.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis): no-default

2026-10-22T01:59:22.2336212Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518668.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.

## Features (mnesis): all-features

2026-10-22T01:59:22.7748629Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Original owner unit invariants execute against actual production source and assertions.
2. Execution/selection/services: Actual counts, ignored/filtered selection and time retained above; Postgres library-only units are not database-backed tests. Raw /tmp/mnesis-command-start-20261021/cp5-exporter-main-pr-job-119591518668.log.
3. Assertions/source/false positives: unchanged exact-head assertions/workloads/markers/deadlines/feature selectors and gates; no disabled-feature or compilation-only pass substituted for runtime behavior. Keep limitations visible.


