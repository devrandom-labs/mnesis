# Exporter full-gate corpus execution reviews

Three actual Rust harnesses in cp5-exporter-full-flake.log. Existing fuzz source/oracles/corpus unchanged; source identity still to be compared with final Nix input. No command fuzz, arbitrary-input campaign, native database, SDK or performance credit.

CBOR: (1) actual saved header/chunk decoder boundaries and existing assertions; (2)2PASS/0FAIL/0ignored/0filtered/1.00s, both named cases actually run; (3) native original harness, not compile-only/zero selection, no assertion or corpus reduction.

Value: (1) native event-type UTF8/length validation body runs; (2)1PASS/0FAIL/0ignored/0filtered/1.00s, no external service needed; (3) unchanged source/oracles and actual result; no claim it qualifies command histories.

Wire: (1) native frame decoding/validation body runs over saved inputs; (2)1PASS/0FAIL/0ignored/0filtered/1.00s, actual one case; (3) original assertions/corpus, no new fuzz budget or command acceptance claim.
