# Exporter full-gate workspace execution reviews

Run649547e1-525f-4160-a2b0-55be3ad739c1:1641PASS/147binaries/5original
exclusions/15slow/484.430s. Full Nix process94697 still completing compile-only
checks at this observation; no all12pass claim yet. Raw cp5-exporter-full-flake.log.

1. Contract/counterexamples: original default workspace laws and45command cases
pass, preserving atomic acceptance, exact identity/retry, conditional ordering,
typed failures, delayed commit barriers, native task cause/custody and admitted
cancellation. Both new default example cases execute the actual Tower driver,
public acceptance decoding, exact receipts/no-op/state, observed stop/resume and
actual binary output. Enabled SDK/metric/trace cases receive no default credit;
they have separate explicitly enabled runs and failed controls.
2. Execution/selection/services:1641actual cases/147binaries, unchanged four
compile-fail and one ignored measurement exclusions. Both command subprocess
parents and one actual example executable parent pass. Postgres absent-service
stubs in default workspace do not qualify native database behavior. Existing
native Fjall laws do not replace processor/Fjall composition. All15slow cases
finish normally; last property not restarted or shortened. No latency/performance
claim from this resource-shared verification run.
3. Assertions/source/false positives:18source/manifest/test owners byte-compare
exactly with actual derivation input /nix/store/ivh6hx8qf9qzsqvivl59phfxywh4bzss-source,
recorded hashes and derivation retained. No core/test bounds, selectors, workloads,
assertions or gates relaxed. Empty successful-main control fails the exact CLI
summary, SDK filter-off control fails actual export count. Disabled feature
harnesses are not claimed as runtime proof; full gate still needs final status.

Reentrant child: (1) actual callback stop, exact wake1, Closed readiness and normal
empty observed join; (2) parentPASS0.019s checks exact one child/status/2s bound;
(3) native notification/result assertions reject missing callbacks or deadlock.
Disabled-timer child: (1) exact native panic, uncertain original ID, zero rows,
Closed and empty report; (2) parentPASS0.045s checks exact one child/status/2s;
(3) native cause/name/result rejects wrong panic, skipped or stuck process.
Example child: (1) actual main must emit independently established first/no-op/
duplicate/retry receipt summary and state7→7; (2) parentPASS0.334s checks successful
child exit, empty stderr and concurrent pipe collection within3s; (3) exact output
rejects skipped flow/empty main; default mode promises no SDK collector.
All three children separately reviewed and not inflated into1641harness cases.
Other owners' existing subprocess assertions are retained; no extra new command
guarantee inferred from them.

