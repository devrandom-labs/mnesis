# Metrics exact-head completed CI jobs: preliminary execution reviews

Signed9c8c95cc, push39702379943 and PR39702385112. This file covers terminal job logs captured so far; Nix and PR Postgres remain live and are not yet credited. Job logs captured through the supported REST job-logs endpoint because gh run view refuses incomplete workflow logs. No new test invocation was launched to obtain these logs.

## Workflow 39702379943

### Compile-fail tests, compiler

2026-10-22T00:56:22.6151797Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 130.54s

1. Contract/counterexamples: Original compiler-negative contracts are checked against expected diagnostics, not inferred from successful compilation.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398763.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual expected compile-fail/pass diagnostics, no edited snapshots or missing-case green.

### Compile-fail tests, compiler

2026-10-22T00:56:58.0333789Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 16.02s

1. Contract/counterexamples: Original compiler-negative contracts are checked against expected diagnostics, not inferred from successful compilation.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398763.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual expected compile-fail/pass diagnostics, no edited snapshots or missing-case green.

### Compile-fail tests, compiler

2026-10-22T00:57:26.3814747Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 19.93s

1. Contract/counterexamples: Original compiler-negative contracts are checked against expected diagnostics, not inferred from successful compilation.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398763.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual expected compile-fail/pass diagnostics, no edited snapshots or missing-case green.

Standalone Postgres job: native nix build reuses the prior output, then cats run.log. The plain264PASS/60.620s is the previously recorded run67bd7909, not a fresh invocation. No additional runtime count or three-test claim. Source-qualified cached output passes the job; native processor/Postgres composition remains CP6.

### Features (mnesis), default

2026-10-22T00:59:15.7377658Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398884.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis), no-default

2026-10-22T00:59:15.8363033Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398884.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis), all-features

2026-10-22T00:59:16.2401894Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398884.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-macros), default

2026-10-22T00:55:41.7895162Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398904.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-macros), no-default

2026-10-22T00:55:41.9097282Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398904.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-macros), all-features

2026-10-22T00:55:42.0261714Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398904.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-command), default

2026-10-22T00:55:49.8772040Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398911.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-command), no-default

2026-10-22T00:55:50.6943326Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398911.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-command), all-features

2026-10-22T00:55:51.9824742Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398911.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-command), none

2026-10-22T00:56:01.3126336Z      Summary [   3.595s] 45 tests run: 45 passed, 1 skipped

1. Contract/counterexamples: Original45 command laws execute; tracing adds4 context/lifecycle laws and metrics adds its seven-profile actual-data/accounting case according to selected mode. Retain identity, exact retries, native completion and uncertainty.
2. Execution/selection/services: Actual nonzero nextest selection with one original ignored benchmark; command cases use in-memory stores. Native reentrant/timer child cases require their own successful bounded-child assertions. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398911.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; default does not certify enabled features; feature-specific cases must be selected. No assertions, gate or deadline changes.

Child reentrant stop callback: (1) exact wake1, closed readiness and normally observed shutdown; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

Child disabled-timer cause: (1) native timer panic, exact uncertain original, zero stored rows and terminal closed outcome; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

### Features (mnesis-command), tracing

2026-10-22T00:56:12.6695788Z      Summary [   3.985s] 49 tests run: 49 passed, 1 skipped

1. Contract/counterexamples: Original45 command laws execute; tracing adds4 context/lifecycle laws and metrics adds its seven-profile actual-data/accounting case according to selected mode. Retain identity, exact retries, native completion and uncertainty.
2. Execution/selection/services: Actual nonzero nextest selection with one original ignored benchmark; command cases use in-memory stores. Native reentrant/timer child cases require their own successful bounded-child assertions. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398911.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; default does not certify enabled features; feature-specific cases must be selected. No assertions, gate or deadline changes.

Child reentrant stop callback: (1) exact wake1, closed readiness and normally observed shutdown; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

Child disabled-timer cause: (1) native timer panic, exact uncertain original, zero stored rows and terminal closed outcome; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

### Features (mnesis-command), metrics

2026-10-22T00:56:23.8868260Z      Summary [   3.987s] 46 tests run: 46 passed, 1 skipped

1. Contract/counterexamples: Original45 command laws execute; tracing adds4 context/lifecycle laws and metrics adds its seven-profile actual-data/accounting case according to selected mode. Retain identity, exact retries, native completion and uncertainty.
2. Execution/selection/services: Actual nonzero nextest selection with one original ignored benchmark; command cases use in-memory stores. Native reentrant/timer child cases require their own successful bounded-child assertions. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398911.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; default does not certify enabled features; feature-specific cases must be selected. No assertions, gate or deadline changes.

Child reentrant stop callback: (1) exact wake1, closed readiness and normally observed shutdown; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

Child disabled-timer cause: (1) native timer panic, exact uncertain original, zero stored rows and terminal closed outcome; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

### Features (mnesis-command), combined

2026-10-22T00:56:36.3448652Z      Summary [   4.230s] 50 tests run: 50 passed, 1 skipped

1. Contract/counterexamples: Original45 command laws execute; tracing adds4 context/lifecycle laws and metrics adds its seven-profile actual-data/accounting case according to selected mode. Retain identity, exact retries, native completion and uncertainty.
2. Execution/selection/services: Actual nonzero nextest selection with one original ignored benchmark; command cases use in-memory stores. Native reentrant/timer child cases require their own successful bounded-child assertions. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574398911.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; default does not certify enabled features; feature-specific cases must be selected. No assertions, gate or deadline changes.

Child reentrant stop callback: (1) exact wake1, closed readiness and normally observed shutdown; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

Child disabled-timer cause: (1) native timer panic, exact uncertain original, zero stored rows and terminal closed outcome; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

### Features (mnesis-store), default

2026-10-22T00:56:35.5583117Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 3.30s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399002.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-store), no-default

2026-10-22T00:56:38.4182159Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.71s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399002.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-store), all-features

2026-10-22T00:56:46.0398743Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.72s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399002.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-wake), default

2026-10-22T00:59:14.7775822Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399051.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-wake), no-default

2026-10-22T00:59:15.0534271Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399051.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-wake), all-features

2026-10-22T00:59:15.3279083Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399051.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-postgres), default

2026-10-22T00:57:33.6710096Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399065.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-postgres), no-default

2026-10-22T00:57:33.8189896Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399065.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-postgres), all-features

2026-10-22T00:57:36.4386222Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399065.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-wake-nostd), default

2026-10-22T01:00:01.6813868Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399092.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-wake-nostd), no-default

2026-10-22T01:00:01.8158654Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399092.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-wake-nostd), all-features

2026-10-22T01:00:01.9529639Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399092.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-store-testing), default

2026-10-22T00:56:01.9353413Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399120.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-store-testing), no-default

2026-10-22T00:56:02.0554245Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399120.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-store-testing), all-features

2026-10-22T00:56:02.1737760Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399120.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-inmemory), default

2026-10-22T01:00:26.6136010Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399218.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-inmemory), no-default

2026-10-22T01:00:26.8195011Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399218.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-inmemory), all-features

2026-10-22T01:00:29.7273865Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399218.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-fjall), default

2026-10-22T00:56:19.3264574Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.71s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399226.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-fjall), no-default

2026-10-22T00:56:23.7799319Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 4.30s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399226.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-fjall), all-features

2026-10-22T00:56:26.5106391Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.58s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702379943-job-119574399226.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

Reviewed actual harness outcomes in these terminal logs: 37. Six zero-case library harnesses per complete feature matrix remain compilation-only. Remaining Nix/native output requires separate classification when terminal.

## Workflow 39702385112

### Features (mnesis), default

2026-10-22T00:58:53.8542273Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414131.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis), no-default

2026-10-22T00:58:53.9957879Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414131.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis), all-features

2026-10-22T00:58:54.5255164Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414131.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-macros), default

2026-10-22T01:02:44.5391042Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414145.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-macros), no-default

2026-10-22T01:02:44.6857148Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414145.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-macros), all-features

2026-10-22T01:02:44.8309772Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414145.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-inmemory), default

2026-10-22T00:58:41.2501833Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414148.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-inmemory), no-default

2026-10-22T00:58:41.4158491Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414148.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-inmemory), all-features

2026-10-22T00:58:43.5676571Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414148.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-postgres), default

2026-10-22T01:00:59.5559487Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414171.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-postgres), no-default

2026-10-22T01:00:59.7072729Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414171.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-postgres), all-features

2026-10-22T01:01:02.3539952Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414171.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-wake-nostd), default

2026-10-22T01:02:45.6775639Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414179.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-wake-nostd), no-default

2026-10-22T01:02:45.7680288Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414179.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-wake-nostd), all-features

2026-10-22T01:02:45.8585335Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414179.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-store-testing), default

2026-10-22T01:01:38.5889088Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414181.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-store-testing), no-default

2026-10-22T01:01:38.7159612Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414181.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-store-testing), all-features

2026-10-22T01:01:38.8400301Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Zero-case unit harness: compilation only; no runtime law certified.
2. Execution/selection/services: Actual zero-case harness, no runtime credit. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414181.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; no inflation of compile-only evidence.

### Features (mnesis-wake), default

2026-10-22T01:00:19.6539398Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414198.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-wake), no-default

2026-10-22T01:00:19.9110488Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414198.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-wake), all-features

2026-10-22T01:00:20.1678597Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414198.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-command), default

2026-10-22T01:03:14.2971636Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414254.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-command), no-default

2026-10-22T01:03:15.1275030Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414254.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-command), all-features

2026-10-22T01:03:16.4385358Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414254.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-command), none

2026-10-22T01:03:24.7690704Z      Summary [   2.860s] 45 tests run: 45 passed, 1 skipped

1. Contract/counterexamples: Original45 command laws execute; tracing adds4 context/lifecycle laws and metrics adds its seven-profile actual-data/accounting case according to selected mode. Retain identity, exact retries, native completion and uncertainty.
2. Execution/selection/services: Actual nonzero nextest selection with one original ignored benchmark; command cases use in-memory stores. Native reentrant/timer child cases require their own successful bounded-child assertions. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414254.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; default does not certify enabled features; feature-specific cases must be selected. No assertions, gate or deadline changes.

Child reentrant stop callback: (1) exact wake1, closed readiness and normally observed shutdown; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

Child disabled-timer cause: (1) native timer panic, exact uncertain original, zero stored rows and terminal closed outcome; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

### Features (mnesis-command), tracing

2026-10-22T01:03:35.0860752Z      Summary [   3.126s] 49 tests run: 49 passed, 1 skipped

1. Contract/counterexamples: Original45 command laws execute; tracing adds4 context/lifecycle laws and metrics adds its seven-profile actual-data/accounting case according to selected mode. Retain identity, exact retries, native completion and uncertainty.
2. Execution/selection/services: Actual nonzero nextest selection with one original ignored benchmark; command cases use in-memory stores. Native reentrant/timer child cases require their own successful bounded-child assertions. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414254.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; default does not certify enabled features; feature-specific cases must be selected. No assertions, gate or deadline changes.

Child reentrant stop callback: (1) exact wake1, closed readiness and normally observed shutdown; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

Child disabled-timer cause: (1) native timer panic, exact uncertain original, zero stored rows and terminal closed outcome; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

### Features (mnesis-command), metrics

2026-10-22T01:03:44.9617034Z      Summary [   3.031s] 46 tests run: 46 passed, 1 skipped

1. Contract/counterexamples: Original45 command laws execute; tracing adds4 context/lifecycle laws and metrics adds its seven-profile actual-data/accounting case according to selected mode. Retain identity, exact retries, native completion and uncertainty.
2. Execution/selection/services: Actual nonzero nextest selection with one original ignored benchmark; command cases use in-memory stores. Native reentrant/timer child cases require their own successful bounded-child assertions. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414254.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; default does not certify enabled features; feature-specific cases must be selected. No assertions, gate or deadline changes.

Child reentrant stop callback: (1) exact wake1, closed readiness and normally observed shutdown; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

Child disabled-timer cause: (1) native timer panic, exact uncertain original, zero stored rows and terminal closed outcome; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

### Features (mnesis-command), combined

2026-10-22T01:03:56.3725757Z      Summary [   3.421s] 50 tests run: 50 passed, 1 skipped

1. Contract/counterexamples: Original45 command laws execute; tracing adds4 context/lifecycle laws and metrics adds its seven-profile actual-data/accounting case according to selected mode. Retain identity, exact retries, native completion and uncertainty.
2. Execution/selection/services: Actual nonzero nextest selection with one original ignored benchmark; command cases use in-memory stores. Native reentrant/timer child cases require their own successful bounded-child assertions. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414254.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; default does not certify enabled features; feature-specific cases must be selected. No assertions, gate or deadline changes.

Child reentrant stop callback: (1) exact wake1, closed readiness and normally observed shutdown; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

Child disabled-timer cause: (1) native timer panic, exact uncertain original, zero stored rows and terminal closed outcome; (2) successful parent result checks exactly one actual child and2s bound; (3) native assertions reject skipped/wrong/stuck child, not just process status. Separately from nextest suite count.

### Compile-fail tests, compiler

2026-10-22T01:04:03.9024932Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 93.44s

1. Contract/counterexamples: Original compiler-negative contracts are checked against expected diagnostics, not inferred from successful compilation.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414255.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual expected compile-fail/pass diagnostics, no edited snapshots or missing-case green.

### Compile-fail tests, compiler

2026-10-22T01:04:29.7734740Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 11.95s

1. Contract/counterexamples: Original compiler-negative contracts are checked against expected diagnostics, not inferred from successful compilation.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414255.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual expected compile-fail/pass diagnostics, no edited snapshots or missing-case green.

### Compile-fail tests, compiler

2026-10-22T01:04:50.6076992Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 14.83s

1. Contract/counterexamples: Original compiler-negative contracts are checked against expected diagnostics, not inferred from successful compilation.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414255.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual expected compile-fail/pass diagnostics, no edited snapshots or missing-case green.

### Features (mnesis-fjall), default

2026-10-22T01:04:27.8931411Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.60s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414260.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-fjall), no-default

2026-10-22T01:04:30.7777156Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.71s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414260.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-fjall), all-features

2026-10-22T01:04:33.6232862Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.67s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414260.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-store), default

2026-10-22T01:05:10.2290407Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.62s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414484.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-store), no-default

2026-10-22T01:05:11.8454433Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.50s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414484.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

### Features (mnesis-store), all-features

2026-10-22T01:05:17.4727203Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.59s

1. Contract/counterexamples: Existing owner unit laws execute against native source and original exact invariants; no new processor/backend integration claim.
2. Execution/selection/services: Actual recorded selected-case counts and wall time above; no ignored/filtered cases reported. Library-only Postgres units do not need a database and are not native service tests. Raw /tmp/mnesis-command-start-20261021/cp5-metrics-main-39702385112-job-119574414484.log.
3. Assertions/source/false positives: unchanged source/test/feature selectors and bounds at exact signed head; actual original assertions, not merely cargo-hack checks or zero selection.

Reviewed actual harness outcomes in these terminal logs: 37. Six zero-case library harnesses per complete feature matrix remain compilation-only. Remaining Nix/native output requires separate classification when terminal.


