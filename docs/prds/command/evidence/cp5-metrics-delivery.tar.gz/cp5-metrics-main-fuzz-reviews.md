# CP5 metrics exact-head fuzz reviews

Run39702385111, signed9c8c95cc; all8campaigns and fuzz-gate terminalSUCCESS. Existing fuzz workspace/targets/toolchains unchanged. Raw full workflow log cp5-metrics-main-fuzz.log. Counts below are fuzzer iterations, not unit cases. None is command-record/history fuzz or exporter/native database/performance proof.

## libFuzzer cbor_decode_header

1. Contract/counterexample: actual saved header decoder rejects invalid framing/schema without panics. Arbitrary input exercises native production decoder, not a copied parser.
2. Execution/selection: actual 1820620, duration61s; native Done-runs terminal line, no reported crash/timeout, normal campaign completion. No external database needed and no unit-suite count inflated from fuzz iterations.
3. Assertions/source/false positives: unchanged corpus/harness/oracles and source tree; campaign reaches executed fuzzing rather than build-only or zero selection. Coverage remains bounded and does not certify processor acceptance. No gate, budget, workload or assertion weakened.

## libFuzzer cbor_decode_chunk

1. Contract/counterexample: actual native chunk decoding validates shape and integrity before import. Arbitrary input exercises native production decoder, not a copied parser.
2. Execution/selection: actual 2220481, duration61s; native Done-runs terminal line, no reported crash/timeout, normal campaign completion. No external database needed and no unit-suite count inflated from fuzz iterations.
3. Assertions/source/false positives: unchanged corpus/harness/oracles and source tree; campaign reaches executed fuzzing rather than build-only or zero selection. Coverage remains bounded and does not certify processor acceptance. No gate, budget, workload or assertion weakened.

## libFuzzer value_event_type

1. Contract/counterexample: actual native UTF8 and event-type length validation handles arbitrary bytes. Arbitrary input exercises native production decoder, not a copied parser.
2. Execution/selection: actual 5809372, duration61s; native Done-runs terminal line, no reported crash/timeout, normal campaign completion. No external database needed and no unit-suite count inflated from fuzz iterations.
3. Assertions/source/false positives: unchanged corpus/harness/oracles and source tree; campaign reaches executed fuzzing rather than build-only or zero selection. Coverage remains bounded and does not certify processor acceptance. No gate, budget, workload or assertion weakened.

## libFuzzer wire_decode_frame

1. Contract/counterexample: actual native event-frame parser preserves validation and round-trip oracles. Arbitrary input exercises native production decoder, not a copied parser.
2. Execution/selection: actual 7480022, duration61s; native Done-runs terminal line, no reported crash/timeout, normal campaign completion. No external database needed and no unit-suite count inflated from fuzz iterations.
3. Assertions/source/false positives: unchanged corpus/harness/oracles and source tree; campaign reaches executed fuzzing rather than build-only or zero selection. Coverage remains bounded and does not certify processor acceptance. No gate, budget, workload or assertion weakened.

## AFL++/CMPLOG cbor_decode_header

1. Contract/counterexample: actual native header decoder under instrumented byte mutations. Arbitrary input exercises native production decoder, not a copied parser.
2. Execution/selection: actual 2 new corpus items;47.61% coverage, duration60s; time-limit termination,0crashes/0timeouts saved, CMPLOG confirmed engaged in terminal job. No external database needed and no unit-suite count inflated from fuzz iterations.
3. Assertions/source/false positives: unchanged corpus/harness/oracles and source tree; campaign reaches executed fuzzing rather than build-only or zero selection. Coverage remains bounded and does not certify processor acceptance. No gate, budget, workload or assertion weakened.

## AFL++/CMPLOG cbor_decode_chunk

1. Contract/counterexample: actual native chunk decoder under instrumented byte mutations. Arbitrary input exercises native production decoder, not a copied parser.
2. Execution/selection: actual 11 new corpus items;43.39% coverage, duration60s; time-limit termination,0crashes/0timeouts saved, CMPLOG confirmed engaged in terminal job. No external database needed and no unit-suite count inflated from fuzz iterations.
3. Assertions/source/false positives: unchanged corpus/harness/oracles and source tree; campaign reaches executed fuzzing rather than build-only or zero selection. Coverage remains bounded and does not certify processor acceptance. No gate, budget, workload or assertion weakened.

## AFL++/CMPLOG value_event_type

1. Contract/counterexample: actual native event-type validator under instrumented byte mutations. Arbitrary input exercises native production decoder, not a copied parser.
2. Execution/selection: actual 0 new corpus items;8.31% coverage, duration60s; time-limit termination,0crashes/0timeouts saved, CMPLOG confirmed engaged in terminal job. No external database needed and no unit-suite count inflated from fuzz iterations.
3. Assertions/source/false positives: unchanged corpus/harness/oracles and source tree; campaign reaches executed fuzzing rather than build-only or zero selection. Coverage remains bounded and does not certify processor acceptance. No gate, budget, workload or assertion weakened.

## AFL++/CMPLOG wire_decode_frame

1. Contract/counterexample: actual native frame parser under instrumented byte mutations. Arbitrary input exercises native production decoder, not a copied parser.
2. Execution/selection: actual 0 new corpus items;34.33% coverage, duration60s; time-limit termination,0crashes/0timeouts saved, CMPLOG confirmed engaged in terminal job. No external database needed and no unit-suite count inflated from fuzz iterations.
3. Assertions/source/false positives: unchanged corpus/harness/oracles and source tree; campaign reaches executed fuzzing rather than build-only or zero selection. Coverage remains bounded and does not certify processor acceptance. No gate, budget, workload or assertion weakened.


