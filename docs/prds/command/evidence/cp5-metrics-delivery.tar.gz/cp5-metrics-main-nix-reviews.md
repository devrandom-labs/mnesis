# Metrics exact-head Nix CI execution reviews

Signed9c8c95cc; expected local merge tree and GitHub virtual97329756758e8ee68bfac430fb9e57dcd564ab4c both7bd3c7495a23052177f05189d569f02a224a0dfa. Push39702379943 and PR39702385112 each pass terminal Nix checks.24actual fresh invocations per Nix job (3corpus,1workspace,20native adapter). Other completed-job reviews separately cover unit/compiler/feature suites and PR standalone20native; push standalone log is cached echo and receives no fresh credit. Combined61push/81PR harness outcomes,6zero-case compiler-only each;55/75nonzero invocations. Every actual command bounded child reviewed separately. This is not CP6 processor/Postgres or SDK/performance/release evidence.

## push Nix job

### Invocation 1

2026-10-22T00:56:06.0948187Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Native header/chunk decoder saved-input oracles.
2. Execution/selection/services: Actual nonzero saved-input Rust harness above,0ignored/filtered,1s; not a new fuzz campaign or command history target.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original decoder bodies, not copied parser or compilation-only. Complete raw logs retained.

### Invocation 2

2026-10-22T00:56:07.0969634Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Native event-type UTF8/length validation over saved inputs.
2. Execution/selection/services: Actual nonzero saved-input Rust harness above,0ignored/filtered,1s; not a new fuzz campaign or command history target.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original decoder bodies, not copied parser or compilation-only. Complete raw logs retained.

### Invocation 3

2026-10-22T00:56:08.0990842Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Native wire frame decoding/validation over saved inputs.
2. Execution/selection/services: Actual nonzero saved-input Rust harness above,0ignored/filtered,1s; not a new fuzz campaign or command history target.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original decoder bodies, not copied parser or compilation-only. Complete raw logs retained.

### Invocation 4

2026-10-22T01:06:56.9859419Z mnesis-nextest>  Nextest run ID e728300f-282c-4b07-b7b0-c240fc36ecbe with nextest profile: default
2026-10-22T01:06:56.9941502Z mnesis-nextest>         PASS [   0.007s] (   1/1639) mnesis aggregate::purist_dispatch_tests::apply_event_accumulates_state_without_advancing_version
2026-10-22T01:09:19.7091585Z mnesis-nextest>      Summary [ 142.723s] 1639 tests run: 1639 passed (4 slow), 5 skipped

1. Contract/counterexamples: Original default workspace invariants, including45command cases, preserve identity/CAS/typed outcomes/native completion/format and uncertainty. Trace/metrics integration cases are disabled here and get no runtime credit.
2. Execution/selection/services: Actual1639PASS/145binaries/5original exclusions/4slow. Native Postgres requires separate service profile; default environment stubs get no native credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; source-qualified actual runtime pass, not cfg-disabled harnesses; existing slow tests allowed to finish. Complete raw logs retained.

Reentrant child: (1) actual callback stop/exact wake1/Closed readiness/normal observed join; (2) actual parentPASS in log checks exact one child/status/2s; (3) original notification/result assertions reject skipped or stuck child. Timer child: (1) exact native disabled-timer panic/original uncertain ID/zero rows/Closed/empty report; (2) actual parentPASS checks exact one child/status/2s; (3) exact native payload/name/result rejects wrong or absent child. Neither is another top-level1639-case invocation.

### Invocation 5

2026-10-22T01:17:41.2006122Z mnesis-postgres-integration>  Nextest run ID c417c127-a81c-4e7e-9c92-ea87fd22d55a with nextest profile: default
2026-10-22T01:17:41.3191265Z mnesis-postgres-integration>         PASS [   0.118s] (1/1) mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all
2026-10-22T01:17:41.3193622Z mnesis-postgres-integration>      Summary [   0.118s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 6

2026-10-22T01:17:45.5408971Z mnesis-postgres-integration>  Nextest run ID 6c02d5ad-499b-403d-a79b-b183911212ca with nextest profile: default
2026-10-22T01:17:45.6053668Z mnesis-postgres-integration>         PASS [   0.144s] (1/1) mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found
2026-10-22T01:17:45.6058583Z mnesis-postgres-integration>      Summary [   0.144s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 7

2026-10-22T01:17:49.8119801Z mnesis-postgres-integration>  Nextest run ID c39bb728-cc74-41ab-acd8-0c6fb63e8879 with nextest profile: default
2026-10-22T01:17:49.9551894Z mnesis-postgres-integration>         PASS [   0.143s] (1/1) mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position
2026-10-22T01:17:49.9554607Z mnesis-postgres-integration>      Summary [   0.143s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 8

2026-10-22T01:17:54.0957600Z mnesis-postgres-integration>  Nextest run ID bae5d0a0-baf6-4803-bb64-7df65038506d with nextest profile: default
2026-10-22T01:17:54.8405479Z mnesis-postgres-integration>         PASS [   0.745s] (1/1) mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen
2026-10-22T01:17:54.8407884Z mnesis-postgres-integration>      Summary [   0.745s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 9

2026-10-22T01:17:58.9787546Z mnesis-postgres-integration>  Nextest run ID 6a6a6f1f-72c6-49d6-b5b2-37aac80e7490 with nextest profile: default
2026-10-22T01:18:00.8821767Z mnesis-postgres-integration>         PASS [   1.903s] (1/1) mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen
2026-10-22T01:18:00.8824695Z mnesis-postgres-integration>      Summary [   1.903s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 10

2026-10-22T01:18:05.0256931Z mnesis-postgres-integration>  Nextest run ID 234dd220-6e59-494e-a263-cfb56167ee01 with nextest profile: default
2026-10-22T01:18:06.9000914Z mnesis-postgres-integration>         PASS [   1.874s] (1/1) mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen
2026-10-22T01:18:06.9002397Z mnesis-postgres-integration>      Summary [   1.874s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 11

2026-10-22T01:18:11.0395297Z mnesis-postgres-integration>  Nextest run ID b83e2e49-ba06-442f-8625-8ffe05deddf5 with nextest profile: default
2026-10-22T01:18:11.0899086Z mnesis-postgres-integration>         PASS [   0.048s] (1/1) mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open
2026-10-22T01:18:11.0900593Z mnesis-postgres-integration>      Summary [   0.048s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 12

2026-10-22T01:18:15.4366370Z mnesis-postgres-integration>  Nextest run ID d9bbfbaf-3aa3-4533-90a3-9e246ce1ada3 with nextest profile: default
2026-10-22T01:18:15.4409514Z mnesis-postgres-integration>         PASS [   0.005s] (  1/264) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:19:22.1739687Z mnesis-postgres-integration>      Summary [  66.737s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 13

2026-10-22T01:19:24.9442305Z mnesis-postgres-integration>  Nextest run ID aff6cc89-619b-4be6-b134-73f18ea6b0d1 with nextest profile: default
2026-10-22T01:19:24.9994169Z mnesis-postgres-integration>         PASS [   0.055s] (1/1) mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips
2026-10-22T01:19:24.9996846Z mnesis-postgres-integration>      Summary [   0.055s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 14

2026-10-22T01:19:27.7644873Z mnesis-postgres-integration>  Nextest run ID 93568303-bc1c-4324-94ba-6bb385806154 with nextest profile: default
2026-10-22T01:19:27.7689985Z mnesis-postgres-integration>         PASS [   0.004s] (  1/149) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:20:07.7026220Z mnesis-postgres-integration>      Summary [  39.936s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 15

2026-10-22T01:20:10.6552345Z mnesis-postgres-integration>  Nextest run ID db011691-e4ca-4965-9895-7e02808b5525 with nextest profile: default
2026-10-22T01:20:10.9258787Z mnesis-postgres-integration>         PASS [   0.270s] (1/1) mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen
2026-10-22T01:20:10.9260957Z mnesis-postgres-integration>      Summary [   0.271s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 16

2026-10-22T01:20:13.9786304Z mnesis-postgres-integration>  Nextest run ID 5be25f20-27bd-4d49-834b-83ae77057761 with nextest profile: default
2026-10-22T01:20:13.9830241Z mnesis-postgres-integration>         PASS [   0.004s] (  1/168) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:20:58.3473215Z mnesis-postgres-integration>      Summary [  44.366s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 17

2026-10-22T01:21:01.1931912Z mnesis-postgres-integration>  Nextest run ID 75fabb91-547e-4e1e-bd95-ee7d39928206 with nextest profile: default
2026-10-22T01:21:01.2659956Z mnesis-postgres-integration>         PASS [   0.073s] (1/1) mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all
2026-10-22T01:21:01.2661373Z mnesis-postgres-integration>      Summary [   0.073s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 18

2026-10-22T01:21:04.1930953Z mnesis-postgres-integration>  Nextest run ID bb7cc31a-7bbb-40a6-96bc-30ef7ade8a3a with nextest profile: default
2026-10-22T01:21:04.1976019Z mnesis-postgres-integration>         PASS [   0.004s] (  1/176) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:21:48.7107365Z mnesis-postgres-integration>      Summary [  44.518s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 19

2026-10-22T01:21:51.7107624Z mnesis-postgres-integration>  Nextest run ID 7586d89c-4eb4-4b3f-8838-c479c0522195 with nextest profile: default
2026-10-22T01:21:51.9165202Z mnesis-postgres-integration>         PASS [   0.205s] (1/1) mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position
2026-10-22T01:21:51.9166695Z mnesis-postgres-integration>      Summary [   0.206s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 20

2026-10-22T01:21:55.0168798Z mnesis-postgres-integration>  Nextest run ID c5e8af1b-f8d6-4c31-8034-34770c79555f with nextest profile: default
2026-10-22T01:21:55.0213636Z mnesis-postgres-integration>         PASS [   0.004s] (  1/173) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:22:37.0432979Z mnesis-postgres-integration>      Summary [  42.025s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 21

2026-10-22T01:22:39.8992134Z mnesis-postgres-integration>  Nextest run ID 55a7aa37-a28d-497d-bdf7-4455cce2959f with nextest profile: default
2026-10-22T01:22:39.9779591Z mnesis-postgres-integration>         PASS [   0.078s] (1/1) mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found
2026-10-22T01:22:39.9781885Z mnesis-postgres-integration>      Summary [   0.079s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 22

2026-10-22T01:22:42.9083956Z mnesis-postgres-integration>  Nextest run ID 89a14d11-988b-4718-9a4d-caa0b57aad33 with nextest profile: default
2026-10-22T01:22:42.9131583Z mnesis-postgres-integration>         PASS [   0.005s] (  1/174) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:23:24.9795393Z mnesis-postgres-integration>      Summary [  42.071s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 23

2026-10-22T01:23:27.8446317Z mnesis-postgres-integration>  Nextest run ID 2cebd2d3-eea3-4ead-9f74-b34b2edf7aa3 with nextest profile: default
2026-10-22T01:23:28.9102910Z mnesis-postgres-integration>         PASS [   1.066s] (1/1) mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields
2026-10-22T01:23:28.9111374Z mnesis-postgres-integration>      Summary [   1.067s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 24

2026-10-22T01:23:31.9118897Z mnesis-postgres-integration>  Nextest run ID eed7163b-3b11-4fd4-adc8-4949f1cb4864 with nextest profile: default
2026-10-22T01:23:31.9167517Z mnesis-postgres-integration>         PASS [   0.005s] (  1/150) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:24:11.8629267Z mnesis-postgres-integration>      Summary [  39.948s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

## pr Nix job

### Invocation 1

2026-10-22T01:02:18.9067907Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Native header/chunk decoder saved-input oracles.
2. Execution/selection/services: Actual nonzero saved-input Rust harness above,0ignored/filtered,1s; not a new fuzz campaign or command history target.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original decoder bodies, not copied parser or compilation-only. Complete raw logs retained.

### Invocation 2

2026-10-22T01:02:19.9096485Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Native event-type UTF8/length validation over saved inputs.
2. Execution/selection/services: Actual nonzero saved-input Rust harness above,0ignored/filtered,1s; not a new fuzz campaign or command history target.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original decoder bodies, not copied parser or compilation-only. Complete raw logs retained.

### Invocation 3

2026-10-22T01:02:20.9110605Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Native wire frame decoding/validation over saved inputs.
2. Execution/selection/services: Actual nonzero saved-input Rust harness above,0ignored/filtered,1s; not a new fuzz campaign or command history target.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original decoder bodies, not copied parser or compilation-only. Complete raw logs retained.

### Invocation 4

2026-10-22T01:13:05.0967748Z mnesis-nextest>  Nextest run ID 073eacca-7c66-484f-af24-500d84128e6a with nextest profile: default
2026-10-22T01:13:05.1056846Z mnesis-nextest>         PASS [   0.006s] (   1/1639) mnesis aggregate::purist_dispatch_tests::apply_events_mid_batch_panic_poisoned_root_rejects_reuse
2026-10-22T01:15:25.7424595Z mnesis-nextest>      Summary [ 140.645s] 1639 tests run: 1639 passed (4 slow), 5 skipped

1. Contract/counterexamples: Original default workspace invariants, including45command cases, preserve identity/CAS/typed outcomes/native completion/format and uncertainty. Trace/metrics integration cases are disabled here and get no runtime credit.
2. Execution/selection/services: Actual1639PASS/145binaries/5original exclusions/4slow. Native Postgres requires separate service profile; default environment stubs get no native credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; source-qualified actual runtime pass, not cfg-disabled harnesses; existing slow tests allowed to finish. Complete raw logs retained.

Reentrant child: (1) actual callback stop/exact wake1/Closed readiness/normal observed join; (2) actual parentPASS in log checks exact one child/status/2s; (3) original notification/result assertions reject skipped or stuck child. Timer child: (1) exact native disabled-timer panic/original uncertain ID/zero rows/Closed/empty report; (2) actual parentPASS checks exact one child/status/2s; (3) exact native payload/name/result rejects wrong or absent child. Neither is another top-level1639-case invocation.

### Invocation 5

2026-10-22T01:23:39.1209287Z mnesis-postgres-integration>  Nextest run ID b81f96ba-74af-4d0b-a05d-22a875a15a9e with nextest profile: default
2026-10-22T01:23:39.2458279Z mnesis-postgres-integration>         PASS [   0.092s] (1/1) mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all
2026-10-22T01:23:39.2460112Z mnesis-postgres-integration>      Summary [   0.125s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 6

2026-10-22T01:23:43.3691701Z mnesis-postgres-integration>  Nextest run ID f09c2e18-78ce-4e68-8f2e-7c2a32679617 with nextest profile: default
2026-10-22T01:23:43.4728803Z mnesis-postgres-integration>         PASS [   0.102s] (1/1) mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found
2026-10-22T01:23:43.4731756Z mnesis-postgres-integration>      Summary [   0.103s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 7

2026-10-22T01:23:47.6138413Z mnesis-postgres-integration>  Nextest run ID f3d0ad16-a57a-4047-947f-5a13dc48ea36 with nextest profile: default
2026-10-22T01:23:47.7358675Z mnesis-postgres-integration>         PASS [   0.120s] (1/1) mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position
2026-10-22T01:23:47.7361089Z mnesis-postgres-integration>      Summary [   0.122s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 8

2026-10-22T01:23:51.8840046Z mnesis-postgres-integration>  Nextest run ID 18e455ee-4940-4008-8499-ed86e444314f with nextest profile: default
2026-10-22T01:23:52.6430811Z mnesis-postgres-integration>         PASS [   0.759s] (1/1) mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen
2026-10-22T01:23:52.6432182Z mnesis-postgres-integration>      Summary [   0.759s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 9

2026-10-22T01:23:56.7807060Z mnesis-postgres-integration>  Nextest run ID 5090391c-c2c9-4408-8de8-02b96e22d762 with nextest profile: default
2026-10-22T01:23:58.7577046Z mnesis-postgres-integration>         PASS [   1.977s] (1/1) mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen
2026-10-22T01:23:58.7579963Z mnesis-postgres-integration>      Summary [   1.977s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 10

2026-10-22T01:24:02.8193380Z mnesis-postgres-integration>  Nextest run ID e4e33613-6649-4683-9751-876838098efe with nextest profile: default
2026-10-22T01:24:04.4467738Z mnesis-postgres-integration>         PASS [   1.627s] (1/1) mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen
2026-10-22T01:24:04.4469852Z mnesis-postgres-integration>      Summary [   1.627s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 11

2026-10-22T01:24:08.6011520Z mnesis-postgres-integration>  Nextest run ID 8cb170fd-24a3-4242-8ec1-d1d0936e5c75 with nextest profile: default
2026-10-22T01:24:08.6474162Z mnesis-postgres-integration>         PASS [   0.046s] (1/1) mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open
2026-10-22T01:24:08.6475960Z mnesis-postgres-integration>      Summary [   0.046s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 12

2026-10-22T01:24:13.1570433Z mnesis-postgres-integration>  Nextest run ID cae334d6-e55c-4396-8d64-680752a81bcc with nextest profile: default
2026-10-22T01:24:13.1614483Z mnesis-postgres-integration>         PASS [   0.004s] (  1/264) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:25:20.6621120Z mnesis-postgres-integration>      Summary [  67.503s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 13

2026-10-22T01:25:23.4394315Z mnesis-postgres-integration>  Nextest run ID 553e4cb9-2807-4cc2-9e98-e42eede284e5 with nextest profile: default
2026-10-22T01:25:23.4966266Z mnesis-postgres-integration>         PASS [   0.056s] (1/1) mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips
2026-10-22T01:25:23.4969339Z mnesis-postgres-integration>      Summary [   0.057s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 14

2026-10-22T01:25:26.2625846Z mnesis-postgres-integration>  Nextest run ID 2caa10a8-cf00-4589-81f7-9be539ba915f with nextest profile: default
2026-10-22T01:25:26.2669397Z mnesis-postgres-integration>         PASS [   0.004s] (  1/149) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:26:05.8018770Z mnesis-postgres-integration>      Summary [  39.539s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 15

2026-10-22T01:26:08.7405857Z mnesis-postgres-integration>  Nextest run ID 03ef8c1a-1ca5-449c-9263-67623c792236 with nextest profile: default
2026-10-22T01:26:09.1102477Z mnesis-postgres-integration>         PASS [   0.370s] (1/1) mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen
2026-10-22T01:26:09.1105766Z mnesis-postgres-integration>      Summary [   0.370s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 16

2026-10-22T01:26:12.1479860Z mnesis-postgres-integration>  Nextest run ID 83f44e4f-c09f-4d84-9c3b-62f7ac06a82f with nextest profile: default
2026-10-22T01:26:12.1521301Z mnesis-postgres-integration>         PASS [   0.004s] (  1/168) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:26:56.0188405Z mnesis-postgres-integration>      Summary [  43.871s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 17

2026-10-22T01:26:58.8536302Z mnesis-postgres-integration>  Nextest run ID d6cc2523-cdd8-4ebc-9ff7-ba4787897ba1 with nextest profile: default
2026-10-22T01:26:58.9226283Z mnesis-postgres-integration>         PASS [   0.069s] (1/1) mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all
2026-10-22T01:26:58.9228086Z mnesis-postgres-integration>      Summary [   0.069s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 18

2026-10-22T01:27:01.8391650Z mnesis-postgres-integration>  Nextest run ID c6b89976-6cdd-408e-a372-86ee9285e4e9 with nextest profile: default
2026-10-22T01:27:01.8434821Z mnesis-postgres-integration>         PASS [   0.004s] (  1/176) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:27:46.7482538Z mnesis-postgres-integration>      Summary [  44.909s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 19

2026-10-22T01:27:49.7370836Z mnesis-postgres-integration>  Nextest run ID 235ef21e-a8e2-44f6-a070-32753df7d3f7 with nextest profile: default
2026-10-22T01:27:49.8725908Z mnesis-postgres-integration>         PASS [   0.135s] (1/1) mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position
2026-10-22T01:27:49.8729055Z mnesis-postgres-integration>      Summary [   0.135s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 20

2026-10-22T01:27:52.9571346Z mnesis-postgres-integration>  Nextest run ID 6879f2db-89ee-434d-8682-b59460fc43f5 with nextest profile: default
2026-10-22T01:27:52.9615765Z mnesis-postgres-integration>         PASS [   0.004s] (  1/173) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:28:34.4260910Z mnesis-postgres-integration>      Summary [  41.469s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 21

2026-10-22T01:28:37.2403091Z mnesis-postgres-integration>  Nextest run ID 77ac8143-b8e2-450e-8b5b-40f069a06304 with nextest profile: default
2026-10-22T01:28:37.3168331Z mnesis-postgres-integration>         PASS [   0.076s] (1/1) mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found
2026-10-22T01:28:37.3169753Z mnesis-postgres-integration>      Summary [   0.077s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 22

2026-10-22T01:28:40.2137984Z mnesis-postgres-integration>  Nextest run ID f13f693b-86f6-45a9-8065-5dd5c1b9f591 with nextest profile: default
2026-10-22T01:28:40.2181409Z mnesis-postgres-integration>         PASS [   0.004s] (  1/174) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:29:20.4107628Z mnesis-postgres-integration>      Summary [  40.197s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 23

2026-10-22T01:29:23.2623367Z mnesis-postgres-integration>  Nextest run ID 0c00ff3d-eeba-4883-8012-f3af176565ab with nextest profile: default
2026-10-22T01:29:24.3271599Z mnesis-postgres-integration>         PASS [   1.064s] (1/1) mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields
2026-10-22T01:29:24.3274499Z mnesis-postgres-integration>      Summary [   1.065s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: The exact native smoke named above executes its original observable law; unselected tests get no credit.
2. Execution/selection/services: Actual1PASS with required no-tests=fail selector and disposable Postgres readiness/migration. Excluded cases not counted.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.

### Invocation 24

2026-10-22T01:29:27.2805594Z mnesis-postgres-integration>  Nextest run ID 411da208-205c-4c13-acc1-fd334f3c44d0 with nextest profile: default
2026-10-22T01:29:27.2849754Z mnesis-postgres-integration>         PASS [   0.004s] (  1/150) mnesis-postgres error::tests::corrupt_row_display_truncates_overlong_stream_id
2026-10-22T01:30:07.2432426Z mnesis-postgres-integration>      Summary [  39.963s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile preserves ordering, transactions, checkpoints, outcome uncertainty, recovery and resource laws. Not a substitute for processor/native composition.
2. Execution/selection/services: Actual nonzero full native counts above,0skipped; disposable PostgreSQL required and checked before suite. No service absence or cached-log runtime credit.
3. Assertions/source/false positives: unchanged source/selectors/corpus/workloads/bounds and gates at verified signed/virtual source tree; original adapter assertions and service guards, no weakened deadlines or green missing-service inference. Complete raw logs retained.


