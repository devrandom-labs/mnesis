# Metrics exact-head PR native Postgres execution reviews

Run39702385112 job119574413852 terminalSUCCESS.20actual fresh native invocations; later plain264PASS echo repeats015650dc and is not another execution. Nix owns disposable service readiness and schema setup; original sources/feature selectors/100ms fixture limits unchanged. Full seven profiles264/149/168/176/173/174/150 and13required smoke laws execute. No processor/Postgres composition claim: CP6 owns that missing work. Raw cp5-metrics-main-pr-postgres.log.

## Native invocation 1

2026-10-22T01:08:26.4696753Z mnesis-postgres-integration>  Nextest run ID 16cd11cb-b657-4d73-b732-57596ff1061f with nextest profile: default
2026-10-22T01:08:26.5714112Z mnesis-postgres-integration>         PASS [   0.100s] (1/1) mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all
2026-10-22T01:08:26.5715547Z mnesis-postgres-integration>      Summary [   0.102s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 2

2026-10-22T01:08:30.9047212Z mnesis-postgres-integration>  Nextest run ID 55f56dfb-1d59-4b17-b525-2f63df2fa632 with nextest profile: default
2026-10-22T01:08:32.7334955Z mnesis-postgres-integration>         PASS [   1.826s] (1/1) mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found
2026-10-22T01:08:32.7336744Z mnesis-postgres-integration>      Summary [   1.827s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 3

2026-10-22T01:08:36.9997886Z mnesis-postgres-integration>  Nextest run ID a2feda97-5fa9-43a8-ab2a-26f05349a3b8 with nextest profile: default
2026-10-22T01:08:37.7104128Z mnesis-postgres-integration>         PASS [   0.710s] (1/1) mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position
2026-10-22T01:08:37.7105825Z mnesis-postgres-integration>      Summary [   0.711s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 4

2026-10-22T01:08:41.9917744Z mnesis-postgres-integration>  Nextest run ID 5899e3ab-82ec-4554-aedb-aa670946fd4d with nextest profile: default
2026-10-22T01:08:42.7324509Z mnesis-postgres-integration>         PASS [   0.739s] (1/1) mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen
2026-10-22T01:08:43.1311404Z mnesis-postgres-integration>      Summary [   0.740s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 5

2026-10-22T01:08:47.0445801Z mnesis-postgres-integration>  Nextest run ID c498a49c-3916-473b-907a-aa2fc5d5feee with nextest profile: default
2026-10-22T01:08:48.4239750Z mnesis-postgres-integration>         PASS [   1.379s] (1/1) mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen
2026-10-22T01:08:48.4241157Z mnesis-postgres-integration>      Summary [   1.379s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 6

2026-10-22T01:08:52.9258038Z mnesis-postgres-integration>  Nextest run ID 6b13fac1-4923-49b7-8fbc-f5452a17d245 with nextest profile: default
2026-10-22T01:08:54.6821342Z mnesis-postgres-integration>         PASS [   1.759s] (1/1) mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen
2026-10-22T01:08:54.6823928Z mnesis-postgres-integration>      Summary [   1.759s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 7

2026-10-22T01:08:58.9209058Z mnesis-postgres-integration>  Nextest run ID 855dd3d0-8ab6-4b19-8635-5b12289a5005 with nextest profile: default
2026-10-22T01:08:58.9736163Z mnesis-postgres-integration>         PASS [   0.051s] (1/1) mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open
2026-10-22T01:08:58.9738223Z mnesis-postgres-integration>      Summary [   0.051s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 8

2026-10-22T01:09:03.3336076Z mnesis-postgres-integration>  Nextest run ID 015650dc-c9d5-40e8-9faf-3534d8708624 with nextest profile: default
Complete native feature profile; first case is not a substitute for the full set.
2026-10-22T01:10:12.2545310Z mnesis-postgres-integration>      Summary [  68.919s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Complete selected adapter feature profile checks original ordering/atomicity/format/recovery/resource laws with actual database access. It does not certify command processing.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Zero skipped in complete profile; failed connection/service would fail native fixtures. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 9

2026-10-22T01:10:15.0983496Z mnesis-postgres-integration>  Nextest run ID 028326a3-121f-4a32-8193-2d6be6eef5a3 with nextest profile: default
2026-10-22T01:10:15.1607753Z mnesis-postgres-integration>         PASS [   0.062s] (1/1) mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips
2026-10-22T01:10:15.1609977Z mnesis-postgres-integration>      Summary [   0.063s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 10

2026-10-22T01:10:17.9744855Z mnesis-postgres-integration>  Nextest run ID 18c6ff58-3af5-4dad-83a2-97d927d62ba8 with nextest profile: default
Complete native feature profile; first case is not a substitute for the full set.
2026-10-22T01:10:58.7155081Z mnesis-postgres-integration>      Summary [  40.740s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Complete selected adapter feature profile checks original ordering/atomicity/format/recovery/resource laws with actual database access. It does not certify command processing.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Zero skipped in complete profile; failed connection/service would fail native fixtures. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 11

2026-10-22T01:11:01.7313895Z mnesis-postgres-integration>  Nextest run ID 5da0bd6f-3ec3-48c5-99d6-a023ecff120f with nextest profile: default
2026-10-22T01:11:01.9829897Z mnesis-postgres-integration>         PASS [   0.249s] (1/1) mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen
2026-10-22T01:11:01.9832239Z mnesis-postgres-integration>      Summary [   0.251s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 12

2026-10-22T01:11:05.0983907Z mnesis-postgres-integration>  Nextest run ID 22657e6f-c6cb-41e5-94b2-3f0c8037b339 with nextest profile: default
Complete native feature profile; first case is not a substitute for the full set.
2026-10-22T01:11:49.7320352Z mnesis-postgres-integration>      Summary [  44.633s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Complete selected adapter feature profile checks original ordering/atomicity/format/recovery/resource laws with actual database access. It does not certify command processing.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Zero skipped in complete profile; failed connection/service would fail native fixtures. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 13

2026-10-22T01:11:52.5915009Z mnesis-postgres-integration>  Nextest run ID 981c9e18-891d-45d3-a9be-a4644d0d0e21 with nextest profile: default
2026-10-22T01:11:52.6643690Z mnesis-postgres-integration>         PASS [   0.073s] (1/1) mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all
2026-10-22T01:11:52.6645124Z mnesis-postgres-integration>      Summary [   0.073s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 14

2026-10-22T01:11:55.6213293Z mnesis-postgres-integration>  Nextest run ID 5fd3350c-3ab2-419d-9e00-03121deacad2 with nextest profile: default
Complete native feature profile; first case is not a substitute for the full set.
2026-10-22T01:12:40.9090261Z mnesis-postgres-integration>      Summary [  45.287s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Complete selected adapter feature profile checks original ordering/atomicity/format/recovery/resource laws with actual database access. It does not certify command processing.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Zero skipped in complete profile; failed connection/service would fail native fixtures. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 15

2026-10-22T01:12:43.9214005Z mnesis-postgres-integration>  Nextest run ID 56e1af49-dd1a-434a-8aab-c545e8ae21d2 with nextest profile: default
2026-10-22T01:12:44.1595093Z mnesis-postgres-integration>         PASS [   0.238s] (1/1) mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position
2026-10-22T01:12:44.1597477Z mnesis-postgres-integration>      Summary [   0.238s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 16

2026-10-22T01:12:47.2859209Z mnesis-postgres-integration>  Nextest run ID fe9861c0-cc6e-4056-8e8b-b79935eadd64 with nextest profile: default
Complete native feature profile; first case is not a substitute for the full set.
2026-10-22T01:13:29.8027658Z mnesis-postgres-integration>      Summary [  42.516s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Complete selected adapter feature profile checks original ordering/atomicity/format/recovery/resource laws with actual database access. It does not certify command processing.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Zero skipped in complete profile; failed connection/service would fail native fixtures. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 17

2026-10-22T01:13:32.6503362Z mnesis-postgres-integration>  Nextest run ID 423aae13-f940-41ab-a463-cbab37283015 with nextest profile: default
2026-10-22T01:13:32.7298415Z mnesis-postgres-integration>         PASS [   0.079s] (1/1) mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found
2026-10-22T01:13:32.7300569Z mnesis-postgres-integration>      Summary [   0.080s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 18

2026-10-22T01:13:35.6743937Z mnesis-postgres-integration>  Nextest run ID fd8f3681-48dc-49b1-8b38-4cdfec6f1322 with nextest profile: default
Complete native feature profile; first case is not a substitute for the full set.
2026-10-22T01:14:18.1407401Z mnesis-postgres-integration>      Summary [  42.464s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Complete selected adapter feature profile checks original ordering/atomicity/format/recovery/resource laws with actual database access. It does not certify command processing.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Zero skipped in complete profile; failed connection/service would fail native fixtures. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 19

2026-10-22T01:14:21.0121288Z mnesis-postgres-integration>  Nextest run ID 6c3fc0d3-97c9-477d-8ac4-7a222c9fa528 with nextest profile: default
2026-10-22T01:14:22.0794697Z mnesis-postgres-integration>         PASS [   1.065s] (1/1) mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields
2026-10-22T01:14:22.0796326Z mnesis-postgres-integration>      Summary [   1.065s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: The exact selected native law above executes its existing invariant/assertions; unrelated unselected cases receive no credit.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Required no-tests=fail selector, excluded smoke cases not counted. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.

## Native invocation 20

2026-10-22T01:14:25.0747287Z mnesis-postgres-integration>  Nextest run ID f683aadb-0b05-4226-b452-f51f12639572 with nextest profile: default
Complete native feature profile; first case is not a substitute for the full set.
2026-10-22T01:15:05.3747932Z mnesis-postgres-integration>      Summary [  40.300s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Complete selected adapter feature profile checks original ordering/atomicity/format/recovery/resource laws with actual database access. It does not certify command processing.
2. Execution/selection/services: actual nonzero counts and duration above, native disposable Postgres available and schema/migrations explicit. Zero skipped in complete profile; failed connection/service would fail native fixtures. Not cached log or echoed output.
3. Assertions/source/false positives: original native assertions, sources, feature guards, limits/deadlines and workload unchanged. No absent-service green or shortened tests claimed; baseline existing native delivery supports provenance, and these are fresh invocations at the signed metrics tree. No new runtime/framework introduced.


