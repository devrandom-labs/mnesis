# Metrics initial push CI reviews

Run39697914083 SUCCESS on signed3dfcd96ae974d10bc98444c25be2935b04409ee2, tree df7b81f8060fc6dc84161620bcdbe59437338b68.81harness outcomes:3compiler,30unit,4command,3corpus,1workspace,40fresh native adapter.6zero-case unit harnesses get compilation-only credit,75nonzero invocations. Plain264native output echo is not a new execution. Raw cp5-metrics-first-push-ci.log. Every actual outcome and reached command child reviewed; no exporter/native command CP6/performance/publication credit.

## Outcome 1

Postgres Integration	Postgres integration	2026-10-22T00:19:54.6108337Z mnesis-postgres-integration>      Summary [   1.072s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 2

Postgres Integration	Postgres integration	2026-10-22T00:19:58.8921394Z mnesis-postgres-integration>      Summary [   0.821s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 3

Postgres Integration	Postgres integration	2026-10-22T00:20:02.6701800Z mnesis-postgres-integration>      Summary [   0.441s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 4

Postgres Integration	Postgres integration	2026-10-22T00:20:08.3558344Z mnesis-postgres-integration>      Summary [   1.145s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 5

Postgres Integration	Postgres integration	2026-10-22T00:20:12.7020297Z mnesis-postgres-integration>      Summary [   0.637s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 6

Postgres Integration	Postgres integration	2026-10-22T00:20:19.8433708Z mnesis-postgres-integration>      Summary [   3.655s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 7

Postgres Integration	Postgres integration	2026-10-22T00:20:22.8892321Z mnesis-postgres-integration>      Summary [   0.031s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 8

Postgres Integration	Postgres integration	2026-10-22T00:21:27.0181443Z mnesis-postgres-integration>      Summary [  60.620s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Complete native all profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual264PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 9

Postgres Integration	Postgres integration	2026-10-22T00:21:29.2679030Z mnesis-postgres-integration>      Summary [   0.040s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 10

Postgres Integration	Postgres integration	2026-10-22T00:22:06.6337658Z mnesis-postgres-integration>      Summary [  35.191s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Complete native default profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual149PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 11

Postgres Integration	Postgres integration	2026-10-22T00:22:09.6417302Z mnesis-postgres-integration>      Summary [   0.538s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 12

Postgres Integration	Postgres integration	2026-10-22T00:22:52.6754176Z mnesis-postgres-integration>      Summary [  40.703s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Complete native export profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual168PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 13

Postgres Integration	Postgres integration	2026-10-22T00:22:54.8426843Z mnesis-postgres-integration>      Summary [   0.049s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 14

Postgres Integration	Postgres integration	2026-10-22T00:23:34.6197411Z mnesis-postgres-integration>      Summary [  37.587s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Complete native import profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual176PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 15

Postgres Integration	Postgres integration	2026-10-22T00:23:37.0906216Z mnesis-postgres-integration>      Summary [   0.173s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 16

Postgres Integration	Postgres integration	2026-10-22T00:24:13.5019703Z mnesis-postgres-integration>      Summary [  34.055s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Complete native projection profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual173PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 17

Postgres Integration	Postgres integration	2026-10-22T00:24:15.7419734Z mnesis-postgres-integration>      Summary [   0.054s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 18

Postgres Integration	Postgres integration	2026-10-22T00:24:51.9040640Z mnesis-postgres-integration>      Summary [  33.910s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Complete native snapshot profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual174PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 19

Postgres Integration	Postgres integration	2026-10-22T00:24:55.0665702Z mnesis-postgres-integration>      Summary [   1.046s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 20

Postgres Integration	Postgres integration	2026-10-22T00:25:30.0096465Z mnesis-postgres-integration>      Summary [  32.788s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Complete native tracing profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual150PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 21

Compile-fail tests	Kernel compile-fail tests	2026-10-22T00:12:04.7751669Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 123.15s

1. Contract/counterexamples: Kernel/macro/store intended misuse diagnostics and valid compiler fixtures.
2. Actual execution/selection/services: Actual2PASS native compiler-fixture harness, no fail/ignore/filter/database.
3. Assertions/source/false positives: Exact selected toolchain/fixtures/golden diagnostics unchanged; no setup/compiler failure treated as expected success.

## Outcome 22

Compile-fail tests	Macro compile-fail tests	2026-10-22T00:12:37.5910149Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 14.72s

1. Contract/counterexamples: Kernel/macro/store intended misuse diagnostics and valid compiler fixtures.
2. Actual execution/selection/services: Actual1PASS native compiler-fixture harness, no fail/ignore/filter/database.
3. Assertions/source/false positives: Exact selected toolchain/fixtures/golden diagnostics unchanged; no setup/compiler failure treated as expected success.

## Outcome 23

Compile-fail tests	Store compile-fail tests	2026-10-22T00:13:03.6696175Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 18.33s

1. Contract/counterexamples: Kernel/macro/store intended misuse diagnostics and valid compiler fixtures.
2. Actual execution/selection/services: Actual1PASS native compiler-fixture harness, no fail/ignore/filter/database.
3. Assertions/source/false positives: Exact selected toolchain/fixtures/golden diagnostics unchanged; no setup/compiler failure treated as expected success.

## Outcome 24

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-22T00:12:12.1354217Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Features (mnesis-command) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual9PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 25

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-22T00:12:12.8681475Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Features (mnesis-command) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual9PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 26

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-22T00:12:14.0224741Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Features (mnesis-command) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual9PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 27

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-22T00:12:21.0262474Z      Summary [   2.223s] 45 tests run: 45 passed, 1 skipped

1. Contract/counterexamples: All45original laws.
2. Actual execution/selection/services: Actual45PASS locked/fail-on-no-tests command integration,1existing ignored measurement. Modenone; no native database. No-collector operation in other test binary processes remains real.
3. Assertions/source/false positives: Exact feature mode, unchanged assertions/workloads/deadlines and signed source; data/identity oracles precede telemetry checks. Both command bounded child parents PASS, separately reviewed.

Reentrant child: (1) actual native callback stop/exact wake1/Closed/normal empty pending join; (2) actual PASS parent checks exact-one-child/status/2s; (3) unchanged notification/join rejects skipped wake/deadlock. Timer child: (1) exact native timer panic/Uncertain ID/zero rows/Closed/empty report; (2) actual PASS parent checks exact-one-child/status/2s; (3) original payload/name/summary rejects wrong cause, zero selection or failed/stuck process. Both separately3reviewed, not added to top-level case count.

## Outcome 28

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-22T00:12:29.6928690Z      Summary [   2.541s] 49 tests run: 49 passed, 1 skipped

1. Contract/counterexamples: All45original laws plus4independent subscriber context/closure/outcome/data laws.
2. Actual execution/selection/services: Actual49PASS locked/fail-on-no-tests command integration,1existing ignored measurement. Modetracing; no native database. No-collector operation in other test binary processes remains real.
3. Assertions/source/false positives: Exact feature mode, unchanged assertions/workloads/deadlines and signed source; data/identity oracles precede telemetry checks. Both command bounded child parents PASS, separately reviewed.

Reentrant child: (1) actual native callback stop/exact wake1/Closed/normal empty pending join; (2) actual PASS parent checks exact-one-child/status/2s; (3) unchanged notification/join rejects skipped wake/deadlock. Timer child: (1) exact native timer panic/Uncertain ID/zero rows/Closed/empty report; (2) actual PASS parent checks exact-one-child/status/2s; (3) original payload/name/summary rejects wrong cause, zero selection or failed/stuck process. Both separately3reviewed, not added to top-level case count.

## Outcome 29

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-22T00:12:38.2832470Z      Summary [   2.437s] 46 tests run: 46 passed, 1 skipped

1. Contract/counterexamples: All45original laws plus7profile metric fixture with exact27calls24admissions, source-restored controls, two pending hosts/thirdstartup/abort/resume, exact data and native metric counters/gauges/timings.
2. Actual execution/selection/services: Actual46PASS locked/fail-on-no-tests command integration,1existing ignored measurement. Modemetrics; no native database. No-collector operation in other test binary processes remains real.
3. Assertions/source/false positives: Exact feature mode, unchanged assertions/workloads/deadlines and signed source; data/identity oracles precede telemetry checks. Both command bounded child parents PASS, separately reviewed.

Reentrant child: (1) actual native callback stop/exact wake1/Closed/normal empty pending join; (2) actual PASS parent checks exact-one-child/status/2s; (3) unchanged notification/join rejects skipped wake/deadlock. Timer child: (1) exact native timer panic/Uncertain ID/zero rows/Closed/empty report; (2) actual PASS parent checks exact-one-child/status/2s; (3) original payload/name/summary rejects wrong cause, zero selection or failed/stuck process. Both separately3reviewed, not added to top-level case count.

## Outcome 30

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-22T00:12:48.0223726Z      Summary [   2.746s] 50 tests run: 50 passed, 1 skipped

1. Contract/counterexamples: All45original laws plus4independent subscriber context/closure/outcome/data laws plus7profile metric fixture with exact27calls24admissions, source-restored controls, two pending hosts/thirdstartup/abort/resume, exact data and native metric counters/gauges/timings.
2. Actual execution/selection/services: Actual50PASS locked/fail-on-no-tests command integration,1existing ignored measurement. Modeboth; no native database. No-collector operation in other test binary processes remains real.
3. Assertions/source/false positives: Exact feature mode, unchanged assertions/workloads/deadlines and signed source; data/identity oracles precede telemetry checks. Both command bounded child parents PASS, separately reviewed.

Reentrant child: (1) actual native callback stop/exact wake1/Closed/normal empty pending join; (2) actual PASS parent checks exact-one-child/status/2s; (3) unchanged notification/join rejects skipped wake/deadlock. Timer child: (1) exact native timer panic/Uncertain ID/zero rows/Closed/empty report; (2) actual PASS parent checks exact-one-child/status/2s; (3) original payload/name/summary rejects wrong cause, zero selection or failed/stuck process. Both separately3reviewed, not added to top-level case count.

## Outcome 31

Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-22T00:12:35.3871705Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 3.14s

1. Contract/counterexamples: Features (mnesis-store) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual217PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 32

Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-22T00:12:38.6346622Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 3.08s

1. Contract/counterexamples: Features (mnesis-store) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual217PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 33

Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-22T00:12:47.3117917Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 3.19s

1. Contract/counterexamples: Features (mnesis-store) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual217PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 34

Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-22T00:11:41.2896637Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-macros) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual1PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 35

Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-22T00:11:41.4023378Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-macros) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual1PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 36

Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-22T00:11:41.5149253Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-macros) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual1PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 37

Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-22T00:11:48.4060199Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Features (mnesis-wake) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual17PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 38

Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-22T00:11:48.6729936Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Features (mnesis-wake) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual17PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 39

Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-22T00:11:48.9409877Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Features (mnesis-wake) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual17PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 40

Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-22T00:11:53.4891476Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual15PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 41

Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-22T00:11:53.6349396Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual15PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 42

Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-22T00:11:54.2184552Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual15PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 43

Nix Flake Check	Flake Check	2026-10-22T00:11:46.0003337Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Existing saved decoder corpus boundary oracles, not fresh random command fuzz.
2. Actual execution/selection/services: Actual2PASS/0fail/ignore/filter/no database, native harness.
3. Assertions/source/false positives: Unchanged decoder/corpus/assertions and nonzero cases; no stateful processor/native/performance proof.

## Outcome 44

Nix Flake Check	Flake Check	2026-10-22T00:11:47.0021594Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Existing saved decoder corpus boundary oracles, not fresh random command fuzz.
2. Actual execution/selection/services: Actual1PASS/0fail/ignore/filter/no database, native harness.
3. Assertions/source/false positives: Unchanged decoder/corpus/assertions and nonzero cases; no stateful processor/native/performance proof.

## Outcome 45

Nix Flake Check	Flake Check	2026-10-22T00:11:48.0037962Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Existing saved decoder corpus boundary oracles, not fresh random command fuzz.
2. Actual execution/selection/services: Actual1PASS/0fail/ignore/filter/no database, native harness.
3. Assertions/source/false positives: Unchanged decoder/corpus/assertions and nonzero cases; no stateful processor/native/performance proof.

## Outcome 46

Nix Flake Check	Flake Check	2026-10-22T00:21:46.5384801Z mnesis-nextest>      Summary [ 120.325s] 1639 tests run: 1639 passed (4 slow), 5 skipped

1. Contract/counterexamples: Original default workspace including45command typed receipt/identity/uncertainty/custody/admission laws; instrumentation tests have separate enabled evidence.
2. Actual execution/selection/services: Actual1639PASS/145binaries/5original exclusions; native PG claims only from service jobs. Four trace and one metric owning cases cfg-disabled here.
3. Assertions/source/false positives: Exact signed candidate and original assertions/workload/profile; actual command child parents PASS, separately reviewed below.

Reentrant child: (1) actual native callback stop/exact wake1/Closed/normal empty pending join; (2) actual PASS parent checks exact-one-child/status/2s; (3) unchanged notification/join rejects skipped wake/deadlock. Timer child: (1) exact native timer panic/Uncertain ID/zero rows/Closed/empty report; (2) actual PASS parent checks exact-one-child/status/2s; (3) original payload/name/summary rejects wrong cause, zero selection or failed/stuck process. Both separately3reviewed, not added to top-level case count.

## Outcome 47

Nix Flake Check	Flake Check	2026-10-22T00:28:37.7267799Z mnesis-postgres-integration>      Summary [   0.949s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 48

Nix Flake Check	Flake Check	2026-10-22T00:28:42.3577435Z mnesis-postgres-integration>      Summary [   0.797s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 49

Nix Flake Check	Flake Check	2026-10-22T00:28:46.8370662Z mnesis-postgres-integration>      Summary [   1.294s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 50

Nix Flake Check	Flake Check	2026-10-22T00:28:51.8508936Z mnesis-postgres-integration>      Summary [   1.533s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 51

Nix Flake Check	Flake Check	2026-10-22T00:28:56.6978205Z mnesis-postgres-integration>      Summary [   0.697s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 52

Nix Flake Check	Flake Check	2026-10-22T00:29:03.5164633Z mnesis-postgres-integration>      Summary [   3.511s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 53

Nix Flake Check	Flake Check	2026-10-22T00:29:06.3025388Z mnesis-postgres-integration>      Summary [   0.035s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 54

Nix Flake Check	Flake Check	2026-10-22T00:30:11.6877554Z mnesis-postgres-integration>      Summary [  62.141s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Complete native all profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual264PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 55

Nix Flake Check	Flake Check	2026-10-22T00:30:13.6324384Z mnesis-postgres-integration>      Summary [   0.043s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 56

Nix Flake Check	Flake Check	2026-10-22T00:30:51.4149492Z mnesis-postgres-integration>      Summary [  35.939s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Complete native default profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual149PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 57

Nix Flake Check	Flake Check	2026-10-22T00:30:54.0849711Z mnesis-postgres-integration>      Summary [   0.627s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 58

Nix Flake Check	Flake Check	2026-10-22T00:31:36.7337274Z mnesis-postgres-integration>      Summary [  40.585s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Complete native export profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual168PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 59

Nix Flake Check	Flake Check	2026-10-22T00:31:38.7481081Z mnesis-postgres-integration>      Summary [   0.052s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 60

Nix Flake Check	Flake Check	2026-10-22T00:32:21.7541463Z mnesis-postgres-integration>      Summary [  41.043s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Complete native import profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual176PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 61

Nix Flake Check	Flake Check	2026-10-22T00:32:25.0065092Z mnesis-postgres-integration>      Summary [   0.305s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 62

Nix Flake Check	Flake Check	2026-10-22T00:33:05.8316776Z mnesis-postgres-integration>      Summary [  38.654s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Complete native projection profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual173PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 63

Nix Flake Check	Flake Check	2026-10-22T00:33:07.8756289Z mnesis-postgres-integration>      Summary [   0.056s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 64

Nix Flake Check	Flake Check	2026-10-22T00:33:42.8409665Z mnesis-postgres-integration>      Summary [  32.999s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Complete native snapshot profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual174PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 65

Nix Flake Check	Flake Check	2026-10-22T00:33:45.8469668Z mnesis-postgres-integration>      Summary [   1.048s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Actual required exact-name smoke law in the preceding PASS; supported native behavior must execute.
2. Actual execution/selection/services: Actual1PASS with disposable server readiness/create/migrations and required-law guards. Unselected smoke cases not credited.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 66

Nix Flake Check	Flake Check	2026-10-22T00:34:23.2790055Z mnesis-postgres-integration>      Summary [  35.443s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Complete native tracing profile retains row/atomicity/checkpoint/recovery/resource invariants.
2. Actual execution/selection/services: Actual150PASS with disposable server readiness/create/migrations and required-law guards. Whole profile zero skips.
3. Assertions/source/false positives: Original adapter source/assertions/deadlines unchanged; not new processor/backend composition and not an absent-service green skip.

## Outcome 67

Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-22T00:11:28.3539722Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this unit harness, compilation only.
2. Actual execution/selection/services: Actual0case/0fail/ignore/filter, no behavioral/native credit.
3. Assertions/source/false positives: Zero selection remains explicit, not passed conformance; owning integration and real service runs are separate.

## Outcome 68

Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-22T00:11:28.4372556Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this unit harness, compilation only.
2. Actual execution/selection/services: Actual0case/0fail/ignore/filter, no behavioral/native credit.
3. Assertions/source/false positives: Zero selection remains explicit, not passed conformance; owning integration and real service runs are separate.

## Outcome 69

Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-22T00:11:28.5202854Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this unit harness, compilation only.
2. Actual execution/selection/services: Actual0case/0fail/ignore/filter, no behavioral/native credit.
3. Assertions/source/false positives: Zero selection remains explicit, not passed conformance; owning integration and real service runs are separate.

## Outcome 70

Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-22T00:12:18.6301469Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.53s

1. Contract/counterexamples: Features (mnesis-fjall) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual131PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 71

Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-22T00:12:21.2972874Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.50s

1. Contract/counterexamples: Features (mnesis-fjall) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual131PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 72

Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-22T00:12:23.9159429Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.46s

1. Contract/counterexamples: Features (mnesis-fjall) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual131PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 73

Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-22T00:11:44.9886927Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this unit harness, compilation only.
2. Actual execution/selection/services: Actual0case/0fail/ignore/filter, no behavioral/native credit.
3. Assertions/source/false positives: Zero selection remains explicit, not passed conformance; owning integration and real service runs are separate.

## Outcome 74

Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-22T00:11:45.1305017Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this unit harness, compilation only.
2. Actual execution/selection/services: Actual0case/0fail/ignore/filter, no behavioral/native credit.
3. Assertions/source/false positives: Zero selection remains explicit, not passed conformance; owning integration and real service runs are separate.

## Outcome 75

Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-22T00:11:45.2672797Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this unit harness, compilation only.
2. Actual execution/selection/services: Actual0case/0fail/ignore/filter, no behavioral/native credit.
3. Assertions/source/false positives: Zero selection remains explicit, not passed conformance; owning integration and real service runs are separate.

## Outcome 76

Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-22T00:11:47.6364222Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-postgres) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual11PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 77

Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-22T00:11:47.7354080Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-postgres) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual11PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 78

Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-22T00:11:49.5744742Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-postgres) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual11PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 79

Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-22T00:11:25.6283428Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s

1. Contract/counterexamples: Features (mnesis-inmemory) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual25PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 80

Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-22T00:11:25.8008064Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s

1. Contract/counterexamples: Features (mnesis-inmemory) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual25PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.

## Outcome 81

Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-22T00:11:28.4678214Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s

1. Contract/counterexamples: Features (mnesis-inmemory) owning isolated unit invariants under the preceding actual default/none/all mode.
2. Actual execution/selection/services: Actual30PASS/0fail/ignore/filter; no real database evidence.
3. Assertions/source/false positives: Original source/assertions unchanged; nonzero execution, not a substitute for command/native composition.


