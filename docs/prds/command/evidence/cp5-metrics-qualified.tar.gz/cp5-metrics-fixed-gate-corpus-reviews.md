# CP5 metrics fixed full-gate corpus reviews

Three actual Rust harness invocations in cp5-metrics-full-gate-fixed.log,
reviewed separately while the main workspace run still builds. No command
fuzz, arbitrary-input campaign, native database or performance credit.

CBOR replay: (1) real header/chunk saved-corpus decoder boundaries and existing
oracles; (2)2PASS/0FAIL/0ignored/0filtered/1.00s, nonzero actual harness run,
no service required; (3) unchanged corpus/source/assertions, not just compilation
and no new arbitrary-input/command-history claim.

Value replay: (1) actual value/event-type saved-corpus input boundaries;
(2)1PASS/0FAIL/0ignored/0filtered/1.00s, actual selected Rust harness, no database;
(3) unchanged native decoder assertions/corpus and nonzero execution, no claim
that existing codec harness proves command processing.

Wire replay: (1) actual saved wire frame validation corpus; (2)1PASS/0FAIL/
0ignored/0filtered/1.00s, actual Rust harness and no database; (3) unchanged
oracles/corpus and raw native result, not a build-only or zero-selection pass.
