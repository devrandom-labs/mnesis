# Metrics candidate default workspace gate

Run c3601b1e-1742-40a6-a877-b134cd53b085:1639PASS/145binaries/5existing
exclusions/16slow/615.302s. Raw cp5-metrics-full-gate-fixed.log. Normal whole
Nix command still finishing compile-only checks; not yet an all12pass claim.

1. Contract/counterexamples: complete original default workspace laws, including
45actual command model/consumer/property/recovery cases, pass. Retained original
CAS/byte/receipt/format limits, concurrent exact identity, delayed commit barrier,
typed failures, native terminal custody and admitted caller cancellation remain.
New metrics case and4trace cases are cfg-disabled here and receive no default
runtime credit; enabled four-mode45/49/46/50 and release50 evidence is separate.
2. Actual execution/selection/services: actual1639cases pass, original4compile-
fail and1ignored measurement excluded by unchanged gate. Both command bounded
subprocess parents actually PASS. Default Postgres tests without service receive
no native credit; real native CI jobs are separately reviewed. Existing native
Fjall/core tests do not replace command/backend CP6 composition.16slow cases
reported honestly, including final unchanged random-version case. No blanket
performance conclusion from this resource-shared verification run.
3. Assertions/source/false positives:13source/manifest/fixture owners cmp exactly
to actual /nix/store/bdpfd5zzpjipi0x7bch88q2wy3fqh4ga-source; recorded current
hashes allmatch. No assertion/workload/deadline/profile/gate weakening. Last slow
property was allowed to finish normally, not stopped/restarted for observation.
Original testsource and source-restored clock/label/gauge controls remain. Empty
cfg-disabled integration harnesses are not counted as metric/trace test coverage.

Timer child: (1) exact native disabled-timer panic/caller Uncertain ID/zero rows/
Closed and empty report; (2) actual parent PASS0.037s after exact-one-test child
status/2s checks; (3) unchanged exact payload/name/summary rejects zero selection,
wrong panic or stuck/failed process. Reentrant child: (1) actual native callback
stop/exact wake1/Closed readiness/normal empty join; (2) actual parent PASS0.060s
with exact-one-child/status/2s checks; (3) native notification/join assertions
reject dropped callbacks/deadlock. Each separately3reviewed and not inflated into
the top-level1639case count. Existing other owners' subprocess scenarios retain
their parent assertions; no new independent processor guarantee inferred.
