# Metrics mutation baseline

Actual unmodified baseline:50PASS/1existing ignored/3.625s,25sbuild. Raw
/tmp/mnesis-command-metrics/mutants.out/log/baseline.log.69mutants scheduled;
no inference that any mutant has completed yet. Standard adaptive test timeout22s
from baseline, not manually changed. Native owning2s/3s case bounds unchanged.

1. Contract/counterexamples: original45command laws,4independent subscriber laws
and seven-profile metrics fixture all execute. Exact27calls24admissions, native
late acceptance and pending custody, two simultaneous pending originals through
third-host startup/abort/resume, finite labels/duration bounds and exact records/
facts/receipts remain. Existing source-scale/clock/label/reset controls retained.
2. Actual execution/selection/services: actual native nextest50case serial run,
1existing ignored optimized measurement; zero failures. Both bounded subprocess
parents PASS in native baseline. Controlled in-memory backend only; no native
CP6/performance/real Postgres credit. Copied native scratch source, not in-place.
3. Assertions/source/false positives: exact metrics diff against c13ef43f and
source hashes saved before launch. Unchanged test suite and gates, nonzero cases;
this is baseline health, not mutation effectiveness. Check every later outcome
and actual failed assertion before classifying caught versus compiler-only.

Timer child: (1) native exact timer-driver panic, caller unknown ID, zero rows/
Closed and empty report; (2) actual parent PASS after exact-one-child/status/2s
checks; (3) native payload/name/summary reject zero selection or substituted
success. Reentrant child: (1) actual callback stop/exact wake1/Closed readiness/
normal empty report; (2) actual parent PASS after exact-one-child/status/2s;
(3) unchanged notification/join assertions reject skipped callback/deadlock.
Each child separately three-reviewed; not added to the top-level50case count.
