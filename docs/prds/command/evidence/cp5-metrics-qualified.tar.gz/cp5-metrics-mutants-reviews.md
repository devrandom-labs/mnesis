# CP5 metrics mutation reviews

Established cargo-mutants27.1.0 CLI on the exact metrics diff against signed c13ef43f.69mutants37caught32compiler-only0missed/timeout; baseline50PASS.70outcomes,38actual nextest invocations. Every actual failure and compiler diagnostic reviewed. Native scratch copy only; original source hashes unchanged afterward. Existing test assertions/workloads/selection/deadlines/gates unchanged. Source oracles distinguish metric-value, typed outcome, custody and liveness catches; no claim that each mutant proves all of them.

## Baseline

1. Contract/counterexample: Original45laws,4subscriber laws and seven-profile metrics fixture all execute and pass. Positive native receipt/custody/queue/labels/timing invariants are retained.
2. Actual execution: Summary [   3.625s] 50 tests run: 50 passed, 1 skipped; native Test status"Success". No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/baseline.log; unmodified baseline, nonzero50case execution. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

Reentrant child: (1) actual callback stop/exact wake1/Closed readiness/normal empty join; (2) actual parent PASS checks exact-one-child/status/2s; (3) native notification/join assertions reject skipped wake or deadlock.

Timer child: (1) exact native timer panic/caller Uncertain ID/zero rows/Closed/empty report; (2) actual parent PASS checks exact-one-child/status/2s; (3) unchanged native payload/name/summary rejects wrong panic, zero selection or stuck process.

## crates/command/src/engine.rs:47:9: replace <impl Drop for Engine<S, A, C, I, N>>::drop with ()

1. Contract/counterexample: Native panic completion must retain the exact unresolved original; None versus the original rejects lost custody.
2. Actual execution: Summary [   0.175s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__engine.rs_line_47_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/engine.rs:90:9: replace Engine<S, A, C, I, N>::replace_pending -> Option<Request<C, I>> with None

1. Contract/counterexample: Observed native busy gauges must be [queued1,reserved1,inflight1,unresolved1]; exact vector rejects missing pending accounting or leaked resource guards.
2. Actual execution: Summary [   0.164s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__engine.rs_line_90_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/engine.rs:90:9: replace Engine<S, A, C, I, N>::replace_pending -> Option<Request<C, I>> with Some(Default::default())

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `model::Request<C, I>: Default` is not satisfied
3. Source/assertions: log/crates__command__src__engine.rs_line_90_col_9_001.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/engine.rs:94:13: delete match arm (None, Some(_)) in Engine<S, A, C, I, N>::replace_pending

1. Contract/counterexample: Observed native busy gauges must be [queued1,reserved1,inflight1,unresolved1]; exact vector rejects missing pending accounting or leaked resource guards.
2. Actual execution: Summary [   0.156s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__engine.rs_line_94_col_13.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/engine.rs:95:13: delete match arm (Some(_), None) in Engine<S, A, C, I, N>::replace_pending

1. Contract/counterexample: Observed normal cleanup must balance the pending gauge while retaining the live readiness reservation; exact final vector rejects missing decrements.
2. Actual execution: Summary [   0.238s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__engine.rs_line_95_col_13.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/engine.rs:116:9: replace Engine<S, A, C, I, N>::settle -> Result<(), Error<A::Error, I, S::Error>> with Ok(())

1. Contract/counterexample: An empty read must not settle a write still able to commit; exact-ID Uncertain rejects the erased barrier.
2. Actual execution: Summary [   0.158s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__engine.rs_line_116_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/engine.rs:134:13: replace && with || in Engine<S, A, C, I, N>::settle

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. Rust rejects || operators in let-chain conditions; actual first compiler diagnostic retained in raw log.
3. Source/assertions: log/crates__command__src__engine.rs_line_134_col_13.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/engine.rs:150:9: replace Engine<S, A, C, I, N>::write -> Result<(), Error<A::Error, I, S::Error>> with Ok(())

1. Contract/counterexample: A valid admitted application command must return its original successful receipt; dropped or rejected dispatch fails the actual SUT call.
2. Actual execution: Summary [   0.084s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__engine.rs_line_150_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/engine.rs:163:52: replace match guard error.is_conflict() with true in Engine<S, A, C, I, N>::write

1. Contract/counterexample: Oversized encoded record preserves its exact typed codec failure; a false Conflict classification is rejected.
2. Actual execution: Summary [   0.089s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__engine.rs_line_163_col_52.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/engine.rs:163:52: replace match guard error.is_conflict() with false in Engine<S, A, C, I, N>::write

1. Contract/counterexample: Actual overlapping CAS race retains a definite Conflict loser; treating it as an unclassified write is rejected.
2. Actual execution: Summary [   1.789s] 13/50 tests run: 12 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__engine.rs_line_163_col_52_001.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/engine.rs:178:9: replace Engine<S, A, C, I, N>::failure -> Result<(), Error<A::Error, I, S::Error>> with Ok(())

1. Contract/counterexample: Application rejection must retain its exact typed cause and original pending semantics; fake successful failure handling is rejected.
2. Actual execution: Summary [   0.094s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__engine.rs_line_178_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/engine.rs:212:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::new())

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
3. Source/assertions: log/crates__command__src__engine.rs_line_212_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/engine.rs:212:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::from_iter([Default::default()]))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope
3. Source/assertions: log/crates__command__src__engine.rs_line_212_col_9_001.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/engine.rs:212:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::new(Default::default()))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
3. Source/assertions: log/crates__command__src__engine.rs_line_212_col_9_002.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/engine.rs:212:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::from(Default::default()))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied
3. Source/assertions: log/crates__command__src__engine.rs_line_212_col_9_003.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:98:9: replace <impl Future for Worker<C, I>>::poll -> Poll<Self::Output> with Poll::new()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no variant, associated function, or constant named `new` found for enum `Poll<T>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_98_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:98:9: replace <impl Future for Worker<C, I>>::poll -> Poll<Self::Output> with Poll::from_iter([Default::default()])

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no variant, associated function, or constant named `from_iter` found for enum `Poll<T>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_98_col_9_001.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:98:9: replace <impl Future for Worker<C, I>>::poll -> Poll<Self::Output> with Poll::new(Default::default())

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no variant, associated function, or constant named `new` found for enum `Poll<T>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_98_col_9_002.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:98:9: replace <impl Future for Worker<C, I>>::poll -> Poll<Self::Output> with Poll::from(Default::default())

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0283]: type annotations needed
3. Source/assertions: log/crates__command__src__host.rs_line_98_col_9_003.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:221:9: replace Call<A, C, I, E>::execute with ()

1. Contract/counterexample: A valid admitted application command must return its original successful receipt; dropped or rejected dispatch fails the actual SUT call.
2. Actual execution: Summary [   0.091s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_221_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:270:9: replace <impl Drop for Inbox<A, C, I, E>>::drop with ()

1. Contract/counterexample: Queued request at native abort must resolve Closed; silently dropped responses violate the original lifecycle contract.
2. Actual execution: Summary [   0.150s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_270_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:274:26: replace == with != in <impl Drop for Inbox<A, C, I, E>>::drop

1. Contract/counterexample: Three earlier known explicit stop intervals must exist before the held stopping profile; missing or overwritten origins produce None.
2. Actual execution: Summary [   0.182s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_274_col_26.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:306:9: replace <impl Clone for CommandProcessor<A, C, I, N, E>>::clone -> Self with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `CommandProcessor<A, C, I, N, E>: Default` is not satisfied
3. Source/assertions: log/crates__command__src__host.rs_line_306_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:379:9: replace CommandProcessor<A, C, I, N, E>::launch -> Started<S, A, C, I, N> with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Result<(CommandProcessor<A, C, I, N, E>, Worker<C, I>), _>: Default` is not satisfied
3. Source/assertions: log/crates__command__src__host.rs_line_379_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:446:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(None)

1. Contract/counterexample: A known original's exact retry must retain its successful receipt; None fails generated reconstruction.
2. Actual execution: Summary [   0.326s] 12/50 tests run: 11 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_446_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:446:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::new()))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_446_col_9_001.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:446:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::from_iter([Default::default()])))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_446_col_9_002.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:446:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::new(Default::default())))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_446_col_9_003.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:446:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::from(Default::default())))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied
3. Source/assertions: log/crates__command__src__host.rs_line_446_col_9_004.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:472:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::new())

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_472_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:472:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::from_iter([Default::default()]))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_472_col_9_001.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:472:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::new(Default::default()))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_472_col_9_002.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:472:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::from(Default::default()))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied
3. Source/assertions: log/crates__command__src__host.rs_line_472_col_9_003.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:512:9: replace CommandProcessor<A, C, I, N, E>::stop with ()

1. Contract/counterexample: Explicit stop must lead to observed native worker completion within the existing3s bound; deleted or inverted stop remains live.
2. Actual execution: Summary [   3.087s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_512_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:514:22: replace == with != in CommandProcessor<A, C, I, N, E>::stop

1. Contract/counterexample: Explicit stop must lead to observed native worker completion within the existing3s bound; deleted or inverted stop remains live.
2. Actual execution: Summary [   3.089s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_514_col_22.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:523:9: replace CommandProcessor<A, C, I, N, E>::send -> Result<(), Error<A::Error, I, E>> with Ok(())

1. Contract/counterexample: A valid admitted application command must return its original successful receipt; dropped or rejected dispatch fails the actual SUT call.
2. Actual execution: Summary [   0.082s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_523_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:537:32: replace != with == in CommandProcessor<A, C, I, N, E>::send

1. Contract/counterexample: A valid admitted application command must return its original successful receipt; dropped or rejected dispatch fails the actual SUT call.
2. Actual execution: Summary [   0.066s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_537_col_32.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:587:9: replace <impl Service<Request<C, I>> for CommandProcessor<A, C, I, N, E>>::poll_ready -> Poll<Result<(), Self::Error>> with Poll::new()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no variant, associated function, or constant named `new` found for enum `Poll<T>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_587_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:587:9: replace <impl Service<Request<C, I>> for CommandProcessor<A, C, I, N, E>>::poll_ready -> Poll<Result<(), Self::Error>> with Poll::from_iter([Ok(())])

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no variant, associated function, or constant named `from_iter` found for enum `Poll<T>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_587_col_9_001.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:587:9: replace <impl Service<Request<C, I>> for CommandProcessor<A, C, I, N, E>>::poll_ready -> Poll<Result<(), Self::Error>> with Poll::new(Ok(()))

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0599]: no variant, associated function, or constant named `new` found for enum `Poll<T>` in the current scope
3. Source/assertions: log/crates__command__src__host.rs_line_587_col_9_002.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:587:9: replace <impl Service<Request<C, I>> for CommandProcessor<A, C, I, N, E>>::poll_ready -> Poll<Result<(), Self::Error>> with Poll::from(Ok(()))

1. Contract/counterexample: Successful Tower readiness must own a native permit; fake Ready without reservation triggers the native PollSender programmer-contract panic. This is a readiness counterexample, not numeric metric proof.
2. Actual execution: Summary [   0.080s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_587_col_9_003.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:588:22: replace != with == in <impl Service<Request<C, I>> for CommandProcessor<A, C, I, N, E>>::poll_ready

1. Contract/counterexample: A running processor must provide valid bounded readiness; inverted lifecycle predicate returns Closed at the actual SUT boundary. Later workload receives no execution credit.
2. Actual execution: Summary [   0.081s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_588_col_22.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:608:9: replace <impl Service<Request<C, I>> for CommandProcessor<A, C, I, N, E>>::call -> Self::Future with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `dyn Future<Output = Result<Receipt<I>, _>> + Send: Default` is not satisfied
3. Source/assertions: log/crates__command__src__host.rs_line_608_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/host.rs:629:32: replace != with == in <impl Service<Request<C, I>> for CommandProcessor<A, C, I, N, E>>::call

1. Contract/counterexample: A valid admitted call must reach the controlled actual append; inverted call admission never reaches the gate and fails the unchanged2s bound. This is dispatch liveness evidence, not independent metric-value coverage.
2. Actual execution: Summary [   2.091s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_629_col_32.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:674:5: replace run with ()

1. Contract/counterexample: A valid admitted application command must return its original successful receipt; dropped or rejected dispatch fails the actual SUT call.
2. Actual execution: Summary [   0.105s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_674_col_5.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:675:31: replace != with == in run

1. Contract/counterexample: A valid admitted application command must return its original successful receipt; dropped or rejected dispatch fails the actual SUT call.
2. Actual execution: Summary [   0.086s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_675_col_31.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/host.rs:687:22: replace != with == in run

1. Contract/counterexample: A valid admitted application command must return its original successful receipt; dropped or rejected dispatch fails the actual SUT call.
2. Actual execution: Summary [   0.129s] 10/50 tests run: 9 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__host.rs_line_687_col_22.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/meter.rs:16:9: replace Observation::request -> Self with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Observation: Default` is not satisfied
3. Source/assertions: log/crates__command__src__meter.rs_line_16_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/meter.rs:20:9: replace Observation::stage -> Self with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Observation: Default` is not satisfied
3. Source/assertions: log/crates__command__src__meter.rs_line_20_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/meter.rs:26:9: replace Observation::finish with ()

1. Contract/counterexample: The actually overloaded call increments exact QueueFull rejection count1; missing terminal observation yields None.
2. Actual execution: Summary [   0.119s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__meter.rs_line_26_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/meter.rs:32:31: replace == with != in Observation::finish

1. Contract/counterexample: Only calls whose outer result is Conflict count as conflicts; inverted reason match yields7 instead of1.
2. Actual execution: Summary [   0.171s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__meter.rs_line_32_col_31.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/meter.rs:38:26: replace != with == in Observation::finish

1. Contract/counterexample: Actual required stage histogram samples must exist after joined data and gauge checks; inverted queue exclusion removes required nonqueue stage histograms.
2. Actual execution: Summary [   0.119s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__meter.rs_line_38_col_26.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/meter.rs:41:26: replace == with != in Observation::finish

1. Contract/counterexample: Reconciliation counter belongs only to reconciliation stages; inverted name comparison produces28 instead of1.
2. Actual execution: Summary [   0.139s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__meter.rs_line_41_col_26.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/meter.rs:51:5: replace count with ()

1. Contract/counterexample: Two actual newly observed accepted records count2; omitted native counter/event emission yields None.
2. Actual execution: Summary [   0.120s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__meter.rs_line_51_col_5.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/meter.rs:54:5: replace admitted with ()

1. Contract/counterexample: Two actual transferred calls increment admitted count2; omitted admission counter yields None.
2. Actual execution: Summary [   0.124s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__meter.rs_line_54_col_5.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/meter.rs:57:5: replace unknown with ()

1. Contract/counterexample: Observed uncertain calls retain exact expected per-operation count; omitted unknown outcome increments yield None instead of3.
2. Actual execution: Summary [   0.154s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__meter.rs_line_57_col_5.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/meter.rs:60:5: replace failure with ()

1. Contract/counterexample: Observed native worker cancellation counts1; omitted terminal failure observation yields None.
2. Actual execution: Summary [   0.139s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__meter.rs_line_60_col_5.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/meter.rs:68:5: replace shutdown with ()

1. Contract/counterexample: Three earlier known explicit stop intervals must exist before the held stopping profile; missing or overwritten origins produce None.
2. Actual execution: Summary [   0.163s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__meter.rs_line_68_col_5.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/meter.rs:83:9: replace Slot::reserved -> Self with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Slot: Default` is not satisfied
3. Source/assertions: log/crates__command__src__meter.rs_line_83_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/meter.rs:86:9: replace Slot::queued -> Self with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Slot: Default` is not satisfied
3. Source/assertions: log/crates__command__src__meter.rs_line_86_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/meter.rs:92:9: replace Slot::active -> Self with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Slot: Default` is not satisfied
3. Source/assertions: log/crates__command__src__meter.rs_line_92_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/meter.rs:100:9: replace <impl Drop for Slot>::drop with ()

1. Contract/counterexample: Observed native busy gauges must be [queued1,reserved1,inflight1,unresolved1]; exact vector rejects missing pending accounting or leaked resource guards.
2. Actual execution: Summary [   0.108s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__meter.rs_line_100_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/trace.rs:28:9: replace Trace::request -> Self with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Trace: Default` is not satisfied
3. Source/assertions: log/crates__command__src__trace.rs_line_28_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/trace.rs:48:9: replace Trace::worker -> Self with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Trace: Default` is not satisfied
3. Source/assertions: log/crates__command__src__trace.rs_line_48_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/trace.rs:62:9: replace Trace::stage -> Self with Default::default()

1. Contract: actual Rust type/interface/grammar rejects this replacement; no runtime behavior claimed.
2. Execution: build fails101, no Test phase/actual test invocation. error[E0277]: the trait bound `Trace: Default` is not satisfied
3. Source/assertions: log/crates__command__src__trace.rs_line_62_col_9.log identifies exact mutant and native compiler diagnostic; compiler-only rejection is not a behavioral catch. No added waiver or assertion change.

## crates/command/src/trace.rs:90:9: replace Trace::finish with ()

1. Contract/counterexample: The actually overloaded call increments exact QueueFull rejection count1; missing terminal observation yields None.
2. Actual execution: Summary [   0.121s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__trace.rs_line_90_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/trace.rs:100:9: replace <impl Drop for Trace>::drop with ()

1. Contract/counterexample: The actually overloaded call increments exact QueueFull rejection count1; missing terminal observation yields None.
2. Actual execution: Summary [   0.110s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__trace.rs_line_100_col_9.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/trace.rs:203:5: replace accepted with ()

1. Contract/counterexample: Two actual newly observed accepted records count2; omitted native counter/event emission yields None.
2. Actual execution: Summary [   0.123s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__trace.rs_line_203_col_5.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.

## crates/command/src/trace.rs:210:5: replace duplicate with ()

1. Contract/counterexample: An exact repeated receipt increments duplicate count1 without another acceptance; omitted duplicate event/counter yields None.
2. Actual execution: Summary [   0.135s] 11/50 tests run: 10 passed, 1 failed, 1 skipped; native Test status{"Failure":100}. No database. Later fail-fast cases receive no execution credit; printed expected fixture panic73 is not automatically treated as the failure.
3. Source/assertions: exact source and failed assertion locations retained in log/crates__command__src__trace.rs_line_210_col_5.log; compiled product mutation causes the stated actual failure, not a compiler or service-availability failure. No assertion, workload, selector or bound weakened. Original source hash checked after completion.


