CP5 metrics experiment before edits (2026-10-21): isolated ordinary worktree
/tmp/mnesis-command-metrics, feat/command-metrics from signed1539509a plus the
exact frozen tracing patch. Trace source remains frozen in observe for its live
Nix gate91717. This is a dependent metrics slice, not another runtime/workflow.
Budget: <=300 net production lines, <=500 test/helper lines, <=10 authored
source/manifest owners plus existing research/docs; generated lock/workspace-hack
changes measured separately. Whole processor checkpoint <=1950 physical product
lines from the trace candidate's1637. No extra public export, framework, runtime,
SDK, tooling or Python. If real requirements exceed this budget, record evidence
and amend before edits rather than omit required behavior.

First verify actual resolved optional metrics0.24.6 graph and dev-only
metrics-util0.20.4 registry storage cost. Record both new normal packages and new
dev packages, licenses/toolchain/maintenance and exact supported feature graph.
A thin Recorder adapter over upstream Registry/AtomicStorage is preferred to
handwritten synchronized maps, atomics and histogram storage if its measured
cost is proportionate. Do not use DebuggingRecorder's resetting snapshots.
Then write a recorder characterization that forces actual active+queued+reserved
native states, dropped callers/handles, invalid admission, duplicate and delayed
commit reconciliation, abort/panic/stop, and exact final counters/gauges. Run it
red before instrumenting, preserving original actual data/receipt assertions.
Readiness clones/repeated polls cannot duplicate a native permit, queue gauges
cannot briefly go negative from enqueue/dequeue reversal, callbacks remain
outside admission, and pending Option remains the sole unresolved authority.
Metrics source work may proceed while the trace gate builds; all local Cargo
compilation remains serial. Rollback is the exact frozen trace patch and ten
verified code/manifest/test hashes. All actual runs/children get three reviews.

Metrics storage qualification before product instrumentation: actual resolution
adds six lock packages (metrics0.24.6, rapidhash4.5.1, portable-atomic1.15.0,
metrics-util0.20.4, rand_xoshiro0.7.0, sketches-ddsketch0.3.1). Native optional
facade adds metrics+rapidhash; portable-atomic is 32-bit only. However supported
metrics-util registry implies its storage bundle, and actual hakari generation
then adds rand/rand_chacha/ppv-lite86 normal workspace-hack edges (six generated
manifest lines). This imports unused sketch/random machinery for passive test
observations. Compare saved before/after normal trees and generated manifest.
Reject metrics-util for this bounded recorder fixture; retain the facade's own
supported CounterFn/GaugeFn atomic handles, standard HashMap and parking_lot
for test registration, and a passive Vec histogram under parking_lot. No custom
production collection, atomics, observer interface or development tool. About
30 additional fixture lines removes four new dev packages and normal RNG edges;
actual regenerated lock/tree/hakari evidence must confirm this before retention.
Keep initial candidate graph/manifests in raw evidence, not an unrecorded pivot.

Before strengthening the new metrics characterization: formatted fixture is477
physical lines. The String-ID invalid/mismatch/domain/no-op profile currently
checks state/receipts but must also assert its actual persisted originals and
zero-fact acceptance. Amend test budget500to550 before adding these data checks;
this is stronger independent persistence evidence, not relaxing a metric oracle.
Preserve exact typed domain rejection instead of matching any Failed cause.
Histogram/finite-label/export and overhead evidence remain required later slices;
this initial counter/gauge characterization does not establish complete metrics.

Dependent metrics parent update before edits: tracing is signed/pushed as
PR418 head dc9882e82a3b6377d4daf636ed6a20d72e7174f4, clean observe tree. Preserve
all metrics binary/index patches/status/source hashes and retain its full stash.
Save an exact metrics-only patch against that signed parent for the four owning
Cargo/manifest/lock/new-test files, plus complete original research records and
their metric-owned append sections. Rebase zero unpublished metrics commits
from1539509a to dc9882e8; apply that exact four-owner patch with index, append
metric-owned hypotheses/sources/experiment/research to the authoritative incoming
records, and rewrite only this goal's progress checkpoint. Verify every source
hash; original staged/unstaged records stay recoverable in retained stash/raw
snapshots. Do not reapply the older trace patch over the newer delivery records.
No source/API/assertion/workload change or new implementation is part of this
parent update. Publication/merge status remains pending actual CI.
