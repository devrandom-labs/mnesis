2026-10-21 metrics follow-up verified current official version pages:
https://docs.rs/metrics/0.24.6/metrics/ and
https://docs.rs/metrics-util/0.20.4/metrics_util/registry/struct.Registry.html.
Facade separates emitting library from application Recorder; Registry documents
supported atomic handles and non-destructive individual lookups. Actual local
published manifests/source remain dependency authority. No global collector or
network/export task belongs in mnesis-command. Dependency graph cost is still
pending actual Cargo resolution; no unexecuted compatibility/performance claim.
