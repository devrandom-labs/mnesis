Metrics dependency selection (2026-10-22): actual initial six-package lock and
hakari graph archived in raw cp5-metrics-registry-candidate.patch/selected-graph.
Rejected dev metrics-util0.20.4 registry because its mandatory storage bundle
adds random/sketch packages and generated normal workspace-hack RNG edges.
After removal, metadata and hakari regeneration restore workspace-hack exactly;
minimal normal tree has optional metrics0.24.6+rapidhash4.5.1, portable-atomic1.15.0
on32bit only. No unrelated lock upgrades. MIT/MIT-or-Apache supported toolchain
floors1.71.1/1.71.0/1.34 fit pinned1.99.0. Passive test recorder uses facade-native
atomic CounterFn/GaugeFn implementations, standard HashMap/parking_lot and a Vec
histogram, without custom production observer API, collection or synchronization.
Characterization is written but not executed; no compatibility/runtime claim yet.

Metrics characterization red (before any metrics product implementation): owning
--test metrics --features metrics --no-tests=fail run compiled and actually ran
one law,0PASS/1FAIL/0SKIP/0.013s, exit100. Raw cp5-metrics-before.log; source hash
cp5-metrics-characterization.sha256. Three distinct reviews before source edits:
1. Contract/counterexamples: native active append is gated, one other handle
   retains readiness, one queued response is dropped unpolled, overload rejects
   exactly QueueFull. Repeated ready and cloning are exercised. Both actual
   originals/facts persist in order, state16/physical2 and original receipt are
   verified; worker stop/join and retained-permit release finish before the
   intended missing-meter assertion. Thus failure is missing queued/reserved/
   inflight/unresolved observations, not fabricated storage failure or deadlock.
2. Execution/selection/services: actual1selected/1failed/0skipped, successful
   compilation and global recorder installation, source metrics.rs249 failure.
   Actual busy snapshot [None,None,None,None] versus exact [Some(1);4]. Real
   in-memory backend/fault gate, no database service required or native claim.
   The later reconciliation/abort/panic/invalid profiles were not reached and
   receive no execution credit. No child process in this owning invocation.
3. Source/assertion/false positives: before-product source is the exact frozen
   trace candidate plus optional facade declaration. Recorder uses maintained
   facade atomic CounterFn/GaugeFn handles and passive storage, not a processor
   reimplementation. Independent persisted records and exact typed QueueFull
   precede the failing metric oracle; missing measurements are not defaulted to
   zero. Snapshot reads do not reset gauges/counters. Bounded genuine native
   permit/queue overlap and final joined cleanup preclude empty/zero-work green.
   No metric oracle, workload, gate or deadline was weakened to obtain this red.
