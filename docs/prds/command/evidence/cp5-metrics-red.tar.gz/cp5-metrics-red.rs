#![cfg(feature = "metrics")]
#![allow(
    clippy::unwrap_used,
    reason = "metric contract failures retain exact observations"
)]

use std::collections::HashMap;
use std::io::ErrorKind;
use std::num::{NonZeroU64, NonZeroUsize};
use std::panic::panic_any;
use std::sync::Arc;
use std::sync::atomic::Ordering;
use std::time::Duration;

use futures::TryStreamExt;
use metrics::atomics::AtomicU64;
use metrics::{
    Counter, Gauge, Histogram, HistogramFn, Key, KeyName, Label, Metadata, Recorder, SharedString,
    Unit,
};
use mnesis::{Events, Handle, Version};
use mnesis_command::{
    Acceptance, AcceptanceCodec, Cause, CodecError, CommandProcessor, Error, Limits, Request,
};
use mnesis_inmemory::InMemoryStore;
use mnesis_store::{Decode, RawEventStore, Store, StreamKey};
use parking_lot::Mutex;
use tower::{Service, ServiceExt};

#[path = "support/counter.rs"]
mod counter;
#[path = "faults/mod.rs"]
#[allow(
    clippy::expect_used,
    reason = "shared controlled faults retain bounded diagnostics"
)]
mod faults;
#[path = "support/finish.rs"]
#[allow(
    clippy::expect_used,
    reason = "shared completion retains bounded diagnostics"
)]
mod shutdown;
use counter::{Counter as Aggregate, Increment, Operation, Rejection, Sum};
use faults::{Fault, FaultStore, Gate};

type Backend = FaultStore<InMemoryStore>;
type Host =
    CommandProcessor<Aggregate, Operation, NonZeroU64, 0, <Backend as RawEventStore>::Error>;
const WAIT: Duration = Duration::from_secs(2);

#[derive(Default)]
struct Samples(Mutex<Vec<f64>>);
impl HistogramFn for Samples {
    fn record(&self, value: f64) {
        self.0.lock().push(value);
    }
}
#[derive(Default)]
struct Records {
    counters: Mutex<HashMap<Key, Arc<AtomicU64>>>,
    gauges: Mutex<HashMap<Key, Arc<AtomicU64>>>,
    histograms: Mutex<HashMap<Key, Arc<Samples>>>,
}
#[derive(Clone, Default)]
struct Recording(Arc<Records>);
impl Recorder for Recording {
    fn describe_counter(&self, _: KeyName, _: Option<Unit>, _: SharedString) {}
    fn describe_gauge(&self, _: KeyName, _: Option<Unit>, _: SharedString) {}
    fn describe_histogram(&self, _: KeyName, _: Option<Unit>, _: SharedString) {}
    fn register_counter(&self, key: &Key, _: &Metadata<'_>) -> Counter {
        Counter::from_arc(Arc::clone(
            self.0.counters.lock().entry(key.clone()).or_default(),
        ))
    }
    fn register_gauge(&self, key: &Key, _: &Metadata<'_>) -> Gauge {
        Gauge::from_arc(Arc::clone(
            self.0.gauges.lock().entry(key.clone()).or_default(),
        ))
    }
    fn register_histogram(&self, key: &Key, _: &Metadata<'_>) -> Histogram {
        Histogram::from_arc(Arc::clone(
            self.0.histograms.lock().entry(key.clone()).or_default(),
        ))
    }
}
impl Recording {
    fn gauge(&self, name: &'static str) -> Option<f64> {
        self.0
            .gauges
            .lock()
            .get(&Key::from_static_name(name))
            .map(|value| f64::from_bits(value.load(Ordering::Acquire)))
    }
    fn count(&self, name: &'static str) -> Option<u64> {
        self.0
            .counters
            .lock()
            .get(&Key::from_static_name(name))
            .map(|value| value.load(Ordering::Acquire))
    }
    fn labeled(
        &self,
        metric: &'static str,
        labels: &[(&'static str, &'static str)],
    ) -> Option<u64> {
        let key = Key::from_parts(
            metric,
            labels
                .iter()
                .map(|&(name, value)| Label::new(name, value))
                .collect::<Vec<_>>(),
        );
        self.0
            .counters
            .lock()
            .get(&key)
            .map(|value| value.load(Ordering::Acquire))
    }
    fn calls(&self) -> [Option<f64>; 4] {
        [
            self.gauge("mnesis_command_queued"),
            self.gauge("mnesis_command_reserved"),
            self.gauge("mnesis_command_inflight"),
            self.gauge("mnesis_command_unresolved"),
        ]
    }
    async fn idle(&self) -> [Option<f64>; 4] {
        tokio::time::timeout(WAIT, async {
            while self.gauge("mnesis_command_inflight") == Some(1.0) {
                tokio::task::yield_now().await;
            }
        })
        .await
        .unwrap();
        self.calls()
    }
}
const fn request(id: u64, expected: Option<Version>, amount: u8) -> Request<Operation> {
    Request {
        id: NonZeroU64::new(id).unwrap(),
        expected,
        command: Operation::Add(amount),
    }
}
async fn rows(
    store: &InMemoryStore,
    stream: &'static str,
) -> Vec<Acceptance<Operation, Increment>> {
    store
        .read_stream(&StreamKey::from_slice(stream.as_bytes()), Version::INITIAL)
        .await
        .unwrap()
        .map_ok(|row| AcceptanceCodec.decode(&row).unwrap())
        .try_collect()
        .await
        .unwrap()
}
fn startup(
    store: &Store<Backend>,
    stream: &'static str,
    operation: Duration,
) -> (Host, mnesis_command::Worker<Operation>) {
    CommandProcessor::<Aggregate, Operation>::start(
        store,
        stream.into(),
        Limits {
            queue: NonZeroUsize::new(2).unwrap(),
            operation,
        },
    )
    .unwrap()
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn metrics_follow_native_admission_and_observed_acceptances() {
    let recording = Recording::default();
    assert!(metrics::set_global_recorder(recording.clone()).is_ok());
    admission(&recording).await;
    reconciliation(&recording).await;
    abort(&recording).await;
    panic(&recording).await;
    invalid(&recording).await;
}
async fn admission(recording: &Recording) {
    let store = Store::new(FaultStore::new(InMemoryStore::new()));
    let gate = Gate::new();
    store.raw().arm(Fault::Delayed(Arc::clone(&gate)));
    let (mut host, worker) = startup(&store, "admission", WAIT);
    let first = tokio::time::timeout(WAIT, host.ready())
        .await
        .unwrap()
        .unwrap()
        .call(request(1, None, 7));
    gate.entered().await;
    let mut reserved = host.clone();
    tokio::time::timeout(WAIT, reserved.ready())
        .await
        .unwrap()
        .unwrap();
    tokio::time::timeout(WAIT, reserved.ready())
        .await
        .unwrap()
        .unwrap();
    drop(reserved.clone());
    let queued = tokio::time::timeout(WAIT, host.ready())
        .await
        .unwrap()
        .unwrap()
        .call(request(2, Some(Version::INITIAL), 9));
    drop(queued);
    assert!(matches!(
        host.submit(request(3, None, 1)).await,
        Err(Error::QueueFull)
    ));
    let busy = recording.calls();
    gate.release();
    gate.done().await;
    let receipt = tokio::time::timeout(WAIT, first).await.unwrap().unwrap();
    assert_eq!((receipt.version, receipt.events), (Version::INITIAL, 1));
    tokio::time::timeout(WAIT, async {
        while rows(&store.raw().inner, "admission").await.len() < 2 {
            tokio::task::yield_now().await;
        }
    })
    .await
    .unwrap();
    assert_eq!(
        tokio::time::timeout(WAIT, host.read())
            .await
            .unwrap()
            .unwrap(),
        (Version::new(2), Sum(16))
    );
    host.stop();
    assert_eq!(shutdown::finish(worker).await.uncertain(), None);
    let stopped = recording.calls();
    drop(reserved);
    let released = recording.calls();
    let accepted = rows(&store.raw().inner, "admission").await;
    assert_eq!(accepted.len(), 2);
    assert_eq!(accepted[0].request(), &request(1, None, 7));
    assert_eq!(
        accepted[1].request(),
        &request(2, Some(Version::INITIAL), 9)
    );
    assert_eq!(accepted[0].facts(), &[Increment(7)]);
    assert_eq!(accepted[1].facts(), &[Increment(9)]);
    assert_eq!(busy, [Some(1.0), Some(1.0), Some(1.0), Some(1.0)]);
    assert_eq!(stopped, [Some(0.0), Some(1.0), Some(0.0), Some(0.0)]);
    assert_eq!(released, [Some(0.0); 4]);
    assert_eq!(recording.count("mnesis_command_acceptances_total"), Some(2));
    assert_eq!(
        recording.labeled("mnesis_command_submitted_total", &[("operation", "submit")]),
        Some(3)
    );
    assert_eq!(
        recording.labeled("mnesis_command_admitted_total", &[("operation", "submit")]),
        Some(2)
    );
    assert_eq!(
        recording.labeled(
            "mnesis_command_rejected_total",
            &[("operation", "submit"), ("outcome", "queue_full")]
        ),
        Some(1)
    );
}
async fn reconciliation(recording: &Recording) {
    let store = Store::new(FaultStore::new(InMemoryStore::new()));
    let gate = Gate::new();
    store.raw().arm(Fault::Delayed(Arc::clone(&gate)));
    let (host, worker) = startup(&store, "reconcile", Duration::from_millis(20));
    let original = request(1, None, 3);
    assert!(
        matches!(host.submit(original.clone()).await, Err(Error::Uncertain { command, source: None }) if command == NonZeroU64::MIN)
    );
    assert!(
        matches!(host.read().await, Err(Error::Uncertain { command, source: None }) if command == NonZeroU64::MIN)
    );
    let before = recording.count("mnesis_command_acceptances_total");
    let unresolved = recording.idle().await;
    gate.release();
    gate.done().await;
    assert_eq!(host.read().await.unwrap(), (Some(Version::INITIAL), Sum(3)));
    let observed = recording.count("mnesis_command_acceptances_total");
    let receipt = host.submit(original.clone()).await.unwrap();
    assert_eq!((receipt.version, receipt.events), (Version::INITIAL, 1));
    host.stop();
    assert_eq!(shutdown::finish(worker).await.uncertain(), None);
    let accepted = rows(&store.raw().inner, "reconcile").await;
    assert_eq!(accepted.len(), 1);
    assert_eq!(accepted[0].request(), &original);
    assert_eq!(accepted[0].receipt(), &receipt);
    assert_eq!(accepted[0].facts(), &[Increment(3)]);
    assert_eq!(before, Some(2));
    assert_eq!(observed, Some(3));
    assert_eq!(recording.count("mnesis_command_acceptances_total"), Some(3));
    assert_eq!(recording.count("mnesis_command_duplicates_total"), Some(1));
    assert_eq!(unresolved, [Some(0.0), Some(0.0), Some(0.0), Some(1.0)]);
    assert_eq!(recording.calls(), [Some(0.0); 4]);
    assert_eq!(
        recording.labeled(
            "mnesis_command_reconciliations_total",
            &[("outcome", "uncertain")]
        ),
        Some(1)
    );
    assert_eq!(
        recording.labeled("mnesis_command_reconciliations_total", &[("outcome", "ok")]),
        Some(1)
    );
}

async fn abort(recording: &Recording) {
    let store = Store::new(FaultStore::new(InMemoryStore::new()));
    let gate = Gate::new();
    *store.raw().read_gate.lock() = Some(Arc::clone(&gate));
    let (mut host, worker) = startup(&store, "abort", WAIT);
    let active = tokio::time::timeout(WAIT, host.ready())
        .await
        .unwrap()
        .unwrap()
        .call(request(1, None, 7));
    gate.entered().await;
    let queued = tokio::time::timeout(WAIT, host.ready())
        .await
        .unwrap()
        .unwrap()
        .call(request(2, None, 9));
    worker.abort();
    let report = tokio::time::timeout(WAIT, worker).await.unwrap();
    assert!(report.cause().unwrap().is_cancelled());
    assert_eq!(report.uncertain(), None);
    assert!(
        matches!(tokio::time::timeout(WAIT, active).await.unwrap(), Err(Error::Uncertain { command, source: None }) if command == NonZeroU64::MIN)
    );
    assert!(matches!(
        tokio::time::timeout(WAIT, queued).await.unwrap(),
        Err(Error::Closed)
    ));
    assert_eq!(rows(&store.raw().inner, "abort").await.len(), 0);
    assert_eq!(recording.calls(), [Some(0.0); 4]);
    assert_eq!(
        recording.labeled(
            "mnesis_command_worker_failures_total",
            &[("cause", "cancelled")]
        ),
        Some(1)
    );
}
impl Handle<u8> for Aggregate {
    #[allow(
        clippy::panic,
        reason = "prove metrics retain native worker failure and original request"
    )]
    fn handle(_: &Sum, _: u8) -> Result<Option<Events<Increment>>, Rejection> {
        panic_any(73_u32);
    }
}
async fn panic(recording: &Recording) {
    let store = Store::new(InMemoryStore::new());
    let (host, worker) = CommandProcessor::<Aggregate, u8>::start(
        &store,
        "panic".into(),
        Limits {
            queue: NonZeroUsize::MIN,
            operation: WAIT,
        },
    )
    .unwrap();
    let input = Request {
        id: NonZeroU64::MIN,
        expected: None,
        command: 7,
    };
    assert!(
        matches!(host.submit(input.clone()).await, Err(Error::Uncertain { command, source: None }) if command == input.id)
    );
    let mut report = tokio::time::timeout(WAIT, worker).await.unwrap();
    assert_eq!(report.uncertain(), Some(&input));
    assert_eq!(
        *report
            .take_cause()
            .unwrap()
            .into_panic()
            .downcast::<u32>()
            .unwrap(),
        73
    );
    assert_eq!(rows(store.raw(), "panic").await.len(), 0);
    assert_eq!(recording.calls(), [Some(0.0); 4]);
    assert_eq!(
        recording.labeled(
            "mnesis_command_worker_failures_total",
            &[("cause", "panic")]
        ),
        Some(1)
    );
}
async fn invalid(recording: &Recording) {
    let store = Store::new(InMemoryStore::new());
    let (mut host, worker) = CommandProcessor::<Aggregate, Operation, String>::start(
        &store,
        "invalid".into(),
        Limits {
            queue: NonZeroUsize::MIN,
            operation: WAIT,
        },
    )
    .unwrap();
    let oversized = Request {
        id: "x".repeat(4097),
        expected: None,
        command: Operation::Add(3),
    };
    let direct = host.submit(oversized.clone()).await;
    tokio::time::timeout(WAIT, host.ready())
        .await
        .unwrap()
        .unwrap();
    let service = host.call(oversized).await;
    for outcome in [direct, service] {
        assert!(
            matches!(outcome, Err(Error::Request(CodecError::Bytes { source: Some(ref error) })) if error.io_error_kind() == Some(ErrorKind::WriteZero))
        );
    }
    let valid = Request {
        id: "stable".to_owned(),
        expected: None,
        command: Operation::Add(3),
    };
    let receipt = host.submit(valid.clone()).await.unwrap();
    assert_eq!((receipt.version, receipt.events), (Version::INITIAL, 1));
    assert!(matches!(
        host.submit(Request {
            command: Operation::Add(4),
            ..valid.clone()
        })
        .await,
        Err(Error::Mismatch)
    ));
    assert!(matches!(
        host.submit(Request {
            id: "stale".to_owned(),
            ..valid.clone()
        })
        .await,
        Err(Error::Conflict)
    ));
    assert!(matches!(
        host.submit(Request {
            id: "rejected".to_owned(),
            expected: Some(Version::INITIAL),
            command: Operation::Reject
        })
        .await,
        Err(Error::Failed(ref cause)) if matches!(&**cause, Cause::Rejected(Rejection))
    ));
    let no_op = Request {
        id: "noop".to_owned(),
        expected: Some(Version::INITIAL),
        command: Operation::Ignore,
    };
    let noop = host.submit(no_op.clone()).await.unwrap();
    assert_eq!((noop.version, noop.events), (Version::new(2).unwrap(), 0));
    assert_eq!(host.read().await.unwrap(), (Version::new(2), Sum(3)));
    host.stop();
    assert_eq!(shutdown::finish(worker).await.uncertain(), None);
    let accepted: Vec<Acceptance<Operation, Increment, String>> = store
        .raw()
        .read_stream(&StreamKey::from_slice(b"invalid"), Version::INITIAL)
        .await
        .unwrap()
        .map_ok(|row| AcceptanceCodec.decode(&row).unwrap())
        .try_collect::<Vec<_>>()
        .await
        .unwrap();
    assert_eq!(accepted.len(), 2);
    assert_eq!(accepted[0].request(), &valid);
    assert_eq!(accepted[0].receipt(), &receipt);
    assert_eq!(accepted[0].facts(), &[Increment(3)]);
    assert_eq!(accepted[1].request(), &no_op);
    assert_eq!(accepted[1].receipt(), &noop);
    assert_eq!(accepted[1].facts(), &[]);
    assert_eq!(recording.calls(), [Some(0.0); 4]);
    assert_eq!(recording.count("mnesis_command_acceptances_total"), Some(5));
    assert_eq!(recording.count("mnesis_command_conflicts_total"), Some(1));
    assert_eq!(
        recording.labeled(
            "mnesis_command_rejected_total",
            &[("operation", "submit"), ("outcome", "request")]
        ),
        Some(2)
    );
}
