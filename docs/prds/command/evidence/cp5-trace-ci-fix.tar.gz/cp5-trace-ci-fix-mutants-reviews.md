# Shared trace factories: local unchanged mutation command

Exact current observe source, rollback dc9882e8. Native Nix cargo-mutants27.1.0 with --all-features --in-diff full PR source diff --test-tool nextest --no-shuffle --colors never; original serial nextest filter retained. Baseline49PASS3.345s.63mutants:23caught/40compiler-only/0missed/timeout;24actual nextest invocations. No exclusion, skip attribute, gate or workload change. Uncompiled duplicate helpers removed from product; all original behavioral catches remain. This local result does not repair the old GitHub check until the signed source is pushed and actual CI succeeds.

Outcome 0: Baseline — Success
PASS [   0.024s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.024s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
     Summary [   3.345s] 49 tests run: 49 passed, 1 skipped
1. Contract/counterexample: Actual49-law baseline retains original data/identity/lifecycle, all four subscriber laws and original property workloads.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Nonzero actual baseline, unchanged exact data/parentage/outcome/closure oracles. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome0:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome0:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 1: crates/command/src/engine.rs:74:9: replace Engine<S, A, C, I, N>::load -> Result<Root<A, C, I, N>, Error<A::Error, I, S::Error>> with Ok(Default::default()) — Unviable
error[E0277]: the trait bound `AggregateRoot<Adapted<A, C, I, N>>: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 2: crates/command/src/engine.rs:88:9: replace Engine<S, A, C, I, N>::settle -> Result<(), Error<A::Error, I, S::Error>> with Ok(()) — CaughtMutant
FAIL [   0.155s] (11/49) mnesis-command::properties generated_histories_preserve_identity_and_reconstruction
     Summary [   0.253s] 11/49 tests run: 10 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.155s] (11/49) mnesis-command::properties generated_histories_preserve_identity_and_reconstruction.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 3: crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::new()) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 4: crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::from_iter([Default::default()])) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 5: crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::new(Default::default())) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 6: crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::from(Default::default())) — Unviable
error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 7: crates/command/src/host.rs:126:9: replace Message<A, C, I, E>::operation -> &'static str with "" — CaughtMutant
PASS [   0.023s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.019s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.009s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.408s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome7:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome7:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 8: crates/command/src/host.rs:126:9: replace Message<A, C, I, E>::operation -> &'static str with "xyzzy" — CaughtMutant
PASS [   0.022s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.023s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.014s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.410s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.014s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome8:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome8:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 9: crates/command/src/host.rs:160:9: replace Call<A, C, I, E>::finish with () — CaughtMutant
PASS [   0.020s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.023s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.009s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans
     Summary [   3.299s] 46/49 tests run: 45 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome9:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome9:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 10: crates/command/src/host.rs:167:9: replace Call<A, C, I, E>::reject with () — CaughtMutant
FAIL [   0.009s] (32/49) mnesis-command::recovery overload_and_shutdown_reject_queued_calls_before_acceptance
     Summary [   3.186s] 32/49 tests run: 31 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (32/49) mnesis-command::recovery overload_and_shutdown_reject_queued_calls_before_acceptance.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 11: crates/command/src/host.rs:176:5: replace respond with () — CaughtMutant
FAIL [   0.009s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy
     Summary [   0.077s] 10/49 tests run: 9 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 12: crates/command/src/host.rs:195:9: replace Call<A, C, I, E>::execute with () — CaughtMutant
FAIL [   0.009s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy
     Summary [   0.081s] 10/49 tests run: 9 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 13: crates/command/src/host.rs:237:9: replace <impl Drop for Inbox<A, C, I, E>>::drop with () — CaughtMutant
FAIL [   0.009s] (32/49) mnesis-command::recovery overload_and_shutdown_reject_queued_calls_before_acceptance
     Summary [   3.177s] 32/49 tests run: 31 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (32/49) mnesis-command::recovery overload_and_shutdown_reject_queued_calls_before_acceptance.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 14: crates/command/src/host.rs:334:9: replace CommandProcessor<A, C, I, N, E>::launch -> Started<S, A, C, I, N> with Default::default() — Unviable
error[E0277]: the trait bound `Result<(_, _), _>: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 15: crates/command/src/host.rs:397:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(None) — CaughtMutant
FAIL [   0.181s] (11/49) mnesis-command::properties generated_histories_preserve_identity_and_reconstruction
     Summary [   0.267s] 11/49 tests run: 10 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.181s] (11/49) mnesis-command::properties generated_histories_preserve_identity_and_reconstruction.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 16: crates/command/src/host.rs:397:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::new())) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 17: crates/command/src/host.rs:397:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::from_iter([Default::default()]))) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 18: crates/command/src/host.rs:397:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::new(Default::default()))) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 19: crates/command/src/host.rs:397:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::from(Default::default()))) — Unviable
error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 20: crates/command/src/host.rs:419:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::new()) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 21: crates/command/src/host.rs:419:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::from_iter([Default::default()])) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 22: crates/command/src/host.rs:419:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::new(Default::default())) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 23: crates/command/src/host.rs:419:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::from(Default::default())) — Unviable
error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 24: crates/command/src/host.rs:437:9: replace CommandProcessor<A, C, I, N, E>::read -> Result<(Option<Version>, A::State), Error<A::Error, I, E>> with Ok((None, Default::default())) — Unviable
error[E0277]: the trait bound `<A as Aggregate>::State: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 25: crates/command/src/host.rs:437:9: replace CommandProcessor<A, C, I, N, E>::read -> Result<(Option<Version>, A::State), Error<A::Error, I, E>> with Ok((Some(Default::default()), Default::default())) — Unviable
error[E0277]: the trait bound `Version: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 26: crates/command/src/host.rs:448:9: replace CommandProcessor<A, C, I, N, E>::original -> Result<Option<Request<C, I>>, Error<A::Error, I, E>> with Ok(None) — CaughtMutant
FAIL [   0.010s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy
     Summary [   0.086s] 10/49 tests run: 9 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.010s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 27: crates/command/src/host.rs:448:9: replace CommandProcessor<A, C, I, N, E>::original -> Result<Option<Request<C, I>>, Error<A::Error, I, E>> with Ok(Some(Default::default())) — Unviable
error[E0277]: the trait bound `model::Request<C, I>: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 28: crates/command/src/host.rs:459:9: replace CommandProcessor<A, C, I, N, E>::send -> Result<(), Error<A::Error, I, E>> with Ok(()) — CaughtMutant
FAIL [   0.009s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy
     Summary [   0.097s] 10/49 tests run: 9 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 29: crates/command/src/host.rs:513:9: replace <impl Service<Request<C, I>> for CommandProcessor<A, C, I, N, E>>::call -> Self::Future with Default::default() — Unviable
error[E0277]: the trait bound `dyn Future<Output = _> + Send: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 30: crates/command/src/host.rs:566:5: replace run with () — CaughtMutant
FAIL [   0.009s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy
     Summary [   0.083s] 10/49 tests run: 9 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 31: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(None) — CaughtMutant
FAIL [   0.012s] ( 4/49) mnesis-command model::tests::full_receipt_history_preserves_old_ids_including_noops
     Summary [   0.037s] 4/49 tests run: 3 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.012s] ( 4/49) mnesis-command model::tests::full_receipt_history_preserves_old_ids_including_noops.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 32: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new())) — Unviable
error[E0061]: this function takes 1 argument but 0 arguments were supplied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 33: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::new()]))) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 34: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::new()))) — Unviable
error[E0599]: no associated function or constant named `new` found for type `_` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 35: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::new()))) — Unviable
error[E0599]: no associated function or constant named `new` found for type `_` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 36: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::from_iter([Default::default()])]))) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 37: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::from_iter([Default::default()])))) — Unviable
error[E0277]: a value of type `Record<C, I, _>` cannot be built from an iterator over elements of type `_`
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 38: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::from_iter([Default::default()])))) — Unviable
error[E0283]: type annotations needed
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 39: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::new(Default::default())]))) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 40: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::new(Default::default())))) — Unviable
error[E0599]: no associated function or constant named `new` found for type `_` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 41: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::new(Default::default())))) — Unviable
error[E0599]: no associated function or constant named `new` found for type `_` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 42: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::from(Default::default())]))) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 43: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::from(Default::default())))) — Unviable
error[E0277]: the trait bound `Record<C, I, _>: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 44: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::from(Default::default())))) — Unviable
error[E0283]: type annotations needed
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 45: crates/command/src/model.rs:425:37: replace >= with < in <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle — CaughtMutant
FAIL [   0.012s] ( 4/49) mnesis-command model::tests::full_receipt_history_preserves_old_ids_including_noops
     Summary [   0.039s] 4/49 tests run: 3 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.012s] ( 4/49) mnesis-command model::tests::full_receipt_history_preserves_old_ids_including_noops.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 46: crates/command/src/trace.rs:24:9: replace Trace::request -> Self with Default::default() — Unviable
error[E0277]: the trait bound `Trace: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 47: crates/command/src/trace.rs:42:9: replace Trace::worker -> Self with Default::default() — Unviable
error[E0277]: the trait bound `Trace: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 48: crates/command/src/trace.rs:54:9: replace Trace::stage -> Self with Default::default() — Unviable
error[E0277]: the trait bound `Trace: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 49: crates/command/src/trace.rs:72:9: replace Trace::scope -> Scope with Default::default() — Unviable
error[E0277]: the trait bound `trace::Scope: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 50: crates/command/src/trace.rs:77:9: replace Trace::child -> Self with Default::default() — Unviable
error[E0277]: the trait bound `Trace: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 51: crates/command/src/trace.rs:80:9: replace Trace::finish with () — CaughtMutant
PASS [   0.024s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.022s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.014s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans
     Summary [   3.438s] 46/49 tests run: 45 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.014s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome51:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome51:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 52: crates/command/src/trace.rs:90:9: replace <impl Drop for Trace>::drop with () — CaughtMutant
PASS [   0.024s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.024s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.009s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans
     Summary [   3.276s] 46/49 tests run: 45 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome52:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome52:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 53: crates/command/src/trace.rs:107:9: replace Scope::sync -> T with Default::default() — Unviable
error[E0277]: the trait bound `T: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 54: crates/command/src/trace.rs:118:9: replace Scope::run -> F::Output with Default::default() — Unviable
error[E0277]: the trait bound `<F as Future>::Output: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 55: crates/command/src/trace.rs:134:9: replace <impl Drop for Scope>::drop with () — CaughtMutant
PASS [   0.023s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.023s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.010s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans
     Summary [   3.376s] 46/49 tests run: 45 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.010s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome55:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome55:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 56: crates/command/src/trace.rs:145:5: replace step -> Result<T, Error<D, I, E>> with Ok(Default::default()) — Unviable
error[E0277]: the trait bound `T: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 57: crates/command/src/trace.rs:156:5: replace sync -> Result<T, E> with Ok(Default::default()) — Unviable
error[E0277]: the trait bound `T: Default` is not satisfied
1. Contract/counterexample: Recorded first compiler error rejects the invalid generated trait/function/type construction; no runtime proof.
2. Execution/selection/services: Only failed Build, no test phase executed. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Compiler-only classified honestly; no behavioral catch or passed test inferred. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Outcome 58: crates/command/src/trace.rs:164:5: replace invalid_request with () — CaughtMutant
PASS [   0.024s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.024s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.010s] (48/49) mnesis-command::trace invalid_requests_are_observed_without_payloads_or_spending_admission
     Summary [   3.454s] 48/49 tests run: 47 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.010s] (48/49) mnesis-command::trace invalid_requests_are_observed_without_payloads_or_spending_admission.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome58:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome58:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 59: crates/command/src/trace.rs:170:5: replace outcome -> &'static str with "" — CaughtMutant
PASS [   0.020s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.024s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.010s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.309s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.010s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome59:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome59:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 60: crates/command/src/trace.rs:170:5: replace outcome -> &'static str with "xyzzy" — CaughtMutant
PASS [   0.024s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.024s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.009s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.272s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome60:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome60:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 61: crates/command/src/trace.rs:191:5: replace accepted with () — CaughtMutant
PASS [   0.022s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.024s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.010s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.371s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.010s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome61:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome61:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 62: crates/command/src/trace.rs:195:5: replace duplicate with () — CaughtMutant
PASS [   0.021s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.028s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.010s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.448s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.010s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome62:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome62:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Outcome 63: crates/command/src/trace.rs:199:5: replace reply_dropped with () — CaughtMutant
PASS [   0.021s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.023s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.009s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.296s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law catches the replacement: FAIL [   0.009s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual nextest invocation and executed count shown; fail-fast does not credit later cases, original performance ignore retained. Selected command tests use real in-memory controlled fixtures; no native Postgres or publication credit.
3. Source/assertion/false positives: Concrete named assertion failure, not compiler/setup/zero-selection failure. Frozen current source and raw log/diff match; mutation command and all assertions/workloads/deadlines unchanged.

Child readiness_release_allows_a_reentrant_stop_callback, outcome63:
1. Contract: actual native readiness callback may reenter stop; observed join must finish with empty uncertainty.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.

Child timer_disabled_runtime_retains_the_native_failure, outcome63:
1. Contract: exact native timer panic, uncertain identity, empty rows and closed admission.
2. Execution: actual parent PASS; exact child name, successful process and exactly one PASS verified inside2seconds.
3. Source/assertion: original exact oracle/helper unchanged; wrong cause, zero selection, process failure or deadlock cannot pass. Unreached children receive no credit.
