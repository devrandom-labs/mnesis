# PR418 head dc9882e8: eight initial fuzz campaigns

Run39685062226 successful. Raw cp5-trace-initial-fuzz.log. Existing codec fuzz targets only; no command-specific fuzz, native durability or telemetry credit. Original bounded campaigns/workloads/gates unchanged.

libFuzzer wire_decode_frame
1. Contract/counterexample: exercise the existing actual wire_decode_frame production decoder/event-type boundary with its retained assertions and corpus; no command worker claim.
2. Execution/selection/services: actual 13546943 executions in61seconds, normal bounded completion. No database required; no service/zero-selection green substitution.
3. Source/assertion/false positives: exact initial PR head and unchanged target assertions/workload; engine output demonstrates execution. Bounded randomized exploration is not exhaustive proof or a passing counterexample; no inferred new benchmark, native or command-recovery evidence.

libFuzzer cbor_decode_header
1. Contract/counterexample: exercise the existing actual cbor_decode_header production decoder/event-type boundary with its retained assertions and corpus; no command worker claim.
2. Execution/selection/services: actual 1850651 executions in61seconds, normal bounded completion. No database required; no service/zero-selection green substitution.
3. Source/assertion/false positives: exact initial PR head and unchanged target assertions/workload; engine output demonstrates execution. Bounded randomized exploration is not exhaustive proof or a passing counterexample; no inferred new benchmark, native or command-recovery evidence.

libFuzzer cbor_decode_chunk
1. Contract/counterexample: exercise the existing actual cbor_decode_chunk production decoder/event-type boundary with its retained assertions and corpus; no command worker claim.
2. Execution/selection/services: actual 1725433 executions in61seconds, normal bounded completion. No database required; no service/zero-selection green substitution.
3. Source/assertion/false positives: exact initial PR head and unchanged target assertions/workload; engine output demonstrates execution. Bounded randomized exploration is not exhaustive proof or a passing counterexample; no inferred new benchmark, native or command-recovery evidence.

libFuzzer value_event_type
1. Contract/counterexample: exercise the existing actual value_event_type production decoder/event-type boundary with its retained assertions and corpus; no command worker claim.
2. Execution/selection/services: actual 5703320 executions in61seconds, normal bounded completion. No database required; no service/zero-selection green substitution.
3. Source/assertion/false positives: exact initial PR head and unchanged target assertions/workload; engine output demonstrates execution. Bounded randomized exploration is not exhaustive proof or a passing counterexample; no inferred new benchmark, native or command-recovery evidence.

AFL++/CMPLOG wire_decode_frame
1. Contract/counterexample: exercise the existing actual wire_decode_frame production decoder/event-type boundary with its retained assertions and corpus; no command worker claim.
2. Execution/selection/services: actual60second campaign, CMPLOG explicitly confirmed,0new corpus items,34.33%coverage,0saved crashes and0saved timeouts; time-limit programmatic termination is expected. No database required; no service/zero-selection green substitution.
3. Source/assertion/false positives: exact initial PR head and unchanged target assertions/workload; engine output demonstrates execution. Bounded randomized exploration is not exhaustive proof or a passing counterexample; no inferred new benchmark, native or command-recovery evidence.

AFL++/CMPLOG cbor_decode_header
1. Contract/counterexample: exercise the existing actual cbor_decode_header production decoder/event-type boundary with its retained assertions and corpus; no command worker claim.
2. Execution/selection/services: actual60second campaign, CMPLOG explicitly confirmed,2new corpus items,47.61%coverage,0saved crashes and0saved timeouts; time-limit programmatic termination is expected. No database required; no service/zero-selection green substitution.
3. Source/assertion/false positives: exact initial PR head and unchanged target assertions/workload; engine output demonstrates execution. Bounded randomized exploration is not exhaustive proof or a passing counterexample; no inferred new benchmark, native or command-recovery evidence.

AFL++/CMPLOG cbor_decode_chunk
1. Contract/counterexample: exercise the existing actual cbor_decode_chunk production decoder/event-type boundary with its retained assertions and corpus; no command worker claim.
2. Execution/selection/services: actual60second campaign, CMPLOG explicitly confirmed,13new corpus items,43.39%coverage,0saved crashes and0saved timeouts; time-limit programmatic termination is expected. No database required; no service/zero-selection green substitution.
3. Source/assertion/false positives: exact initial PR head and unchanged target assertions/workload; engine output demonstrates execution. Bounded randomized exploration is not exhaustive proof or a passing counterexample; no inferred new benchmark, native or command-recovery evidence.

AFL++/CMPLOG value_event_type
1. Contract/counterexample: exercise the existing actual value_event_type production decoder/event-type boundary with its retained assertions and corpus; no command worker claim.
2. Execution/selection/services: actual60second campaign, CMPLOG explicitly confirmed,0new corpus items,8.31%coverage,0saved crashes and0saved timeouts; time-limit programmatic termination is expected. No database required; no service/zero-selection green substitution.
3. Source/assertion/false positives: exact initial PR head and unchanged target assertions/workload; engine output demonstrates execution. Bounded randomized exploration is not exhaustive proof or a passing counterexample; no inferred new benchmark, native or command-recovery evidence.
