# Initial tracing pr CI 39685062323: three reviews per actual invocation

Exact head dc9882e8.79actual invocations:3compiler/30unit/2command integration/3replay/1workspace/40native adapter. Plain echoed PG summaries excluded. Workflow succeeded, but initial mutation gate FAILED separately; not a green PR or merged delivery. Raw cp5-trace-initial-pr-ci.log. No metrics, command-native CP6, publication or release credit.

Invocation1: Nix Flake Check	Flake Check	2026-10-21T22:20:44.7895054Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing actual decoder corpus group with2law(s); replay, not a fresh random campaign.
2. Execution/selection/services: Actual executable2PASS/zero failed/ignored/filtered, no database needed.
3. Source/assertion/false positives: Existing target/corpus/assertions unchanged; finite replay alone does not prove arbitrary-input completeness, command behavior or durability.

Invocation2: Nix Flake Check	Flake Check	2026-10-21T22:20:45.7913576Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing actual decoder corpus group with1law(s); replay, not a fresh random campaign.
2. Execution/selection/services: Actual executable1PASS/zero failed/ignored/filtered, no database needed.
3. Source/assertion/false positives: Existing target/corpus/assertions unchanged; finite replay alone does not prove arbitrary-input completeness, command behavior or durability.

Invocation3: Nix Flake Check	Flake Check	2026-10-21T22:20:46.7932527Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing actual decoder corpus group with1law(s); replay, not a fresh random campaign.
2. Execution/selection/services: Actual executable1PASS/zero failed/ignored/filtered, no database needed.
3. Source/assertion/false positives: Existing target/corpus/assertions unchanged; finite replay alone does not prove arbitrary-input completeness, command behavior or durability.

Invocation4: Nix Flake Check	Flake Check	2026-10-21T22:31:24.9867500Z mnesis-nextest>      Summary [ 138.697s] 1639 tests run: 1639 passed (4 slow), 5 skipped
1. Contract/counterexample: Whole workspace including45actual default command laws and original identity/late-commit/custody/resource/property invariants. Four trace laws not inferred from this default invocation.
2. Execution/selection/services: 1639actual PASS/144binaries/five existing exclusions; adapter cases without a service gain no native credit here.
3. Source/assertion/false positives: Original assertions/workloads/selection remain. Both bounded children actually PASS; exact child reviews below. No source default gate inflation into49trace passes.

Child readiness_release_allows_a_reentrant_stop_callback, invocation4:
1. Contract: real native readiness callback reenters stop and actual joined uncertainty is empty.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Child timer_disabled_runtime_retains_the_native_failure, invocation4:
1. Contract: exact native Tokio timer panic, uncertain ID, zero rows and closed admission.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Invocation5: Nix Flake Check	Flake Check	2026-10-21T22:38:43.7555318Z mnesis-postgres-integration>      Summary [   0.760s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation6: Nix Flake Check	Flake Check	2026-10-21T22:38:49.3130382Z mnesis-postgres-integration>      Summary [   0.993s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation7: Nix Flake Check	Flake Check	2026-10-21T22:38:55.0451541Z mnesis-postgres-integration>      Summary [   1.248s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation8: Nix Flake Check	Flake Check	2026-10-21T22:39:00.0564833Z mnesis-postgres-integration>      Summary [   1.221s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation9: Nix Flake Check	Flake Check	2026-10-21T22:39:05.4850079Z mnesis-postgres-integration>      Summary [   0.959s] 1 test run: 1 passed, 10 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation10: Nix Flake Check	Flake Check	2026-10-21T22:39:12.8020822Z mnesis-postgres-integration>      Summary [   3.707s] 1 test run: 1 passed, 4 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation11: Nix Flake Check	Flake Check	2026-10-21T22:39:16.3836655Z mnesis-postgres-integration>      Summary [   0.039s] 1 test run: 1 passed, 9 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation12: Nix Flake Check	Flake Check	2026-10-21T22:40:36.3749944Z mnesis-postgres-integration>      Summary [  75.931s] 264 tests run: 264 passed, 0 skipped
1. Contract/counterexample: Full selected 264-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 264PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation13: Nix Flake Check	Flake Check	2026-10-21T22:40:38.8358471Z mnesis-postgres-integration>      Summary [   0.048s] 1 test run: 1 passed, 39 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation14: Nix Flake Check	Flake Check	2026-10-21T22:41:23.5034818Z mnesis-postgres-integration>      Summary [  42.289s] 149 tests run: 149 passed, 0 skipped
1. Contract/counterexample: Full selected 149-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 149PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation15: Nix Flake Check	Flake Check	2026-10-21T22:41:26.4841300Z mnesis-postgres-integration>      Summary [   0.460s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation16: Nix Flake Check	Flake Check	2026-10-21T22:42:17.0077004Z mnesis-postgres-integration>      Summary [  47.928s] 168 tests run: 168 passed, 0 skipped
1. Contract/counterexample: Full selected 168-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 168PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation17: Nix Flake Check	Flake Check	2026-10-21T22:42:19.6230940Z mnesis-postgres-integration>      Summary [   0.190s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation18: Nix Flake Check	Flake Check	2026-10-21T22:43:11.8800917Z mnesis-postgres-integration>      Summary [  49.791s] 176 tests run: 176 passed, 0 skipped
1. Contract/counterexample: Full selected 176-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 176PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation19: Nix Flake Check	Flake Check	2026-10-21T22:43:14.9344460Z mnesis-postgres-integration>      Summary [   0.474s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation20: Nix Flake Check	Flake Check	2026-10-21T22:44:01.9449085Z mnesis-postgres-integration>      Summary [  44.311s] 173 tests run: 173 passed, 0 skipped
1. Contract/counterexample: Full selected 173-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 173PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation21: Nix Flake Check	Flake Check	2026-10-21T22:44:04.8344193Z mnesis-postgres-integration>      Summary [   0.062s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation22: Nix Flake Check	Flake Check	2026-10-21T22:44:46.5727865Z mnesis-postgres-integration>      Summary [  39.213s] 174 tests run: 174 passed, 0 skipped
1. Contract/counterexample: Full selected 174-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 174PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation23: Nix Flake Check	Flake Check	2026-10-21T22:44:50.1050960Z mnesis-postgres-integration>      Summary [   1.054s] 1 test run: 1 passed, 0 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation24: Nix Flake Check	Flake Check	2026-10-21T22:45:30.9825918Z mnesis-postgres-integration>      Summary [  38.332s] 150 tests run: 150 passed, 0 skipped
1. Contract/counterexample: Full selected 150-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 150PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation25: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T22:20:05.8985777Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation26: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T22:20:06.0438546Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation27: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T22:20:06.1732334Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation28: Postgres Integration	Postgres integration	2026-10-21T22:28:59.3949348Z mnesis-postgres-integration>      Summary [   0.689s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation29: Postgres Integration	Postgres integration	2026-10-21T22:29:05.2135260Z mnesis-postgres-integration>      Summary [   1.035s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation30: Postgres Integration	Postgres integration	2026-10-21T22:29:10.3299750Z mnesis-postgres-integration>      Summary [   1.089s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation31: Postgres Integration	Postgres integration	2026-10-21T22:29:15.5314630Z mnesis-postgres-integration>      Summary [   1.182s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation32: Postgres Integration	Postgres integration	2026-10-21T22:29:20.3566710Z mnesis-postgres-integration>      Summary [   0.664s] 1 test run: 1 passed, 10 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation33: Postgres Integration	Postgres integration	2026-10-21T22:29:27.9996826Z mnesis-postgres-integration>      Summary [   3.561s] 1 test run: 1 passed, 4 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation34: Postgres Integration	Postgres integration	2026-10-21T22:29:31.4158049Z mnesis-postgres-integration>      Summary [   0.037s] 1 test run: 1 passed, 9 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation35: Postgres Integration	Postgres integration	2026-10-21T22:30:47.3297167Z mnesis-postgres-integration>      Summary [  71.273s] 264 tests run: 264 passed, 0 skipped
1. Contract/counterexample: Full selected 264-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 264PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation36: Postgres Integration	Postgres integration	2026-10-21T22:30:49.6776095Z mnesis-postgres-integration>      Summary [   0.046s] 1 test run: 1 passed, 39 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation37: Postgres Integration	Postgres integration	2026-10-21T22:31:31.3255940Z mnesis-postgres-integration>      Summary [  39.387s] 149 tests run: 149 passed, 0 skipped
1. Contract/counterexample: Full selected 149-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 149PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation38: Postgres Integration	Postgres integration	2026-10-21T22:31:34.2796846Z mnesis-postgres-integration>      Summary [   0.537s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation39: Postgres Integration	Postgres integration	2026-10-21T22:32:22.3292427Z mnesis-postgres-integration>      Summary [  45.540s] 168 tests run: 168 passed, 0 skipped
1. Contract/counterexample: Full selected 168-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 168PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation40: Postgres Integration	Postgres integration	2026-10-21T22:32:24.6845088Z mnesis-postgres-integration>      Summary [   0.053s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation41: Postgres Integration	Postgres integration	2026-10-21T22:33:07.3692680Z mnesis-postgres-integration>      Summary [  40.339s] 176 tests run: 176 passed, 0 skipped
1. Contract/counterexample: Full selected 176-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 176PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation42: Postgres Integration	Postgres integration	2026-10-21T22:33:10.3328674Z mnesis-postgres-integration>      Summary [   0.492s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation43: Postgres Integration	Postgres integration	2026-10-21T22:33:56.0758252Z mnesis-postgres-integration>      Summary [  43.040s] 173 tests run: 173 passed, 0 skipped
1. Contract/counterexample: Full selected 173-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 173PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation44: Postgres Integration	Postgres integration	2026-10-21T22:33:58.4894061Z mnesis-postgres-integration>      Summary [   0.060s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation45: Postgres Integration	Postgres integration	2026-10-21T22:34:44.4380352Z mnesis-postgres-integration>      Summary [  43.544s] 174 tests run: 174 passed, 0 skipped
1. Contract/counterexample: Full selected 174-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 174PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation46: Postgres Integration	Postgres integration	2026-10-21T22:34:48.0706937Z mnesis-postgres-integration>      Summary [   1.226s] 1 test run: 1 passed, 0 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation47: Postgres Integration	Postgres integration	2026-10-21T22:35:27.5139796Z mnesis-postgres-integration>      Summary [  37.010s] 150 tests run: 150 passed, 0 skipped
1. Contract/counterexample: Full selected 150-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 150PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation48: Compile-fail tests	Kernel compile-fail tests	2026-10-21T22:24:04.8750642Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 120.01s
1. Contract/counterexample: Compile-fail tests preserves existing supported/misuse diagnostic compiler fixtures,2harness cases.
2. Execution/selection/services: Actual checkout harness2PASS/zero failed/ignored/filtered; separate from five default Nix exclusions.
3. Source/assertion/false positives: Original expected diagnostics and positive/negative fixtures unchanged; no runtime, native or publication inference from compiler success.

Invocation49: Compile-fail tests	Macro compile-fail tests	2026-10-21T22:24:38.7117273Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 15.84s
1. Contract/counterexample: Compile-fail tests preserves existing supported/misuse diagnostic compiler fixtures,1harness cases.
2. Execution/selection/services: Actual checkout harness1PASS/zero failed/ignored/filtered; separate from five default Nix exclusions.
3. Source/assertion/false positives: Original expected diagnostics and positive/negative fixtures unchanged; no runtime, native or publication inference from compiler success.

Invocation50: Compile-fail tests	Store compile-fail tests	2026-10-21T22:25:05.0646168Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 18.61s
1. Contract/counterexample: Compile-fail tests preserves existing supported/misuse diagnostic compiler fixtures,1harness cases.
2. Execution/selection/services: Actual checkout harness1PASS/zero failed/ignored/filtered; separate from five default Nix exclusions.
3. Source/assertion/false positives: Original expected diagnostics and positive/negative fixtures unchanged; no runtime, native or publication inference from compiler success.

Invocation51: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T22:24:25.5150835Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation52: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T22:24:25.6102001Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation53: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T22:24:25.7016961Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation54: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T22:23:34.0001128Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-macros) isolated feature unit laws: 1 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,1PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation55: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T22:23:34.1429977Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-macros) isolated feature unit laws: 1 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,1PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation56: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T22:23:34.2826982Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-macros) isolated feature unit laws: 1 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,1PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation57: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T22:24:15.5172994Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-postgres) isolated feature unit laws: 11 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,11PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation58: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T22:24:15.6418446Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-postgres) isolated feature unit laws: 11 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,11PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation59: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T22:24:18.0533042Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-postgres) isolated feature unit laws: 11 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,11PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation60: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T22:25:39.2561553Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.49s
1. Contract/counterexample: Features (mnesis-fjall) isolated feature unit laws: 131 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,131PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation61: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T22:25:41.8785890Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.47s
1. Contract/counterexample: Features (mnesis-fjall) isolated feature unit laws: 131 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,131PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation62: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T22:25:44.5156529Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.48s
1. Contract/counterexample: Features (mnesis-fjall) isolated feature unit laws: 131 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,131PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation63: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T22:21:50.2346206Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s
1. Contract/counterexample: Features (mnesis-inmemory) isolated feature unit laws: 25 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,25PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation64: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T22:21:50.4266475Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s
1. Contract/counterexample: Features (mnesis-inmemory) isolated feature unit laws: 25 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,25PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation65: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T22:21:52.9998290Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s
1. Contract/counterexample: Features (mnesis-inmemory) isolated feature unit laws: 30 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,30PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation66: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T22:22:39.5705513Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis) isolated feature unit laws: 15 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,15PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation67: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T22:22:39.6676177Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis) isolated feature unit laws: 15 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,15PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation68: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T22:22:40.0403271Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis) isolated feature unit laws: 15 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,15PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation69: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T22:23:59.7247036Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.57s
1. Contract/counterexample: Features (mnesis-store) isolated feature unit laws: 217 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,217PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation70: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T22:24:01.2437196Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.41s
1. Contract/counterexample: Features (mnesis-store) isolated feature unit laws: 217 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,217PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation71: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T22:24:06.4052430Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.78s
1. Contract/counterexample: Features (mnesis-store) isolated feature unit laws: 217 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,217PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation72: Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T22:25:11.1896309Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s
1. Contract/counterexample: Features (mnesis-command) isolated feature unit laws: 9 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,9PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation73: Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T22:25:11.9874428Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s
1. Contract/counterexample: Features (mnesis-command) isolated feature unit laws: 9 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,9PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation74: Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T22:25:12.8155885Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s
1. Contract/counterexample: Features (mnesis-command) isolated feature unit laws: 9 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,9PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation75: Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T22:25:22.0806266Z      Summary [   3.663s] 45 tests run: 45 passed, 1 skipped
1. Contract/counterexample: All45default command laws retain non-instrumented public semantics, exact data, typed causes and uncertainty.
2. Execution/selection/services: Actual 45PASS command integration invocation via existing Nix feature job, locked dependencies and fail-on-no-tests; one original ignore. No database required.
3. Source/assertion/false positives: Source/test identity matches actual head; explicit feature mode, real selected laws and original data/parentage/count/closure oracles. Both bounded child parents actually PASS and retain exact-one/status/time-bound assertions.

Child readiness_release_allows_a_reentrant_stop_callback, invocation75:
1. Contract: real native readiness callback reenters stop and actual joined uncertainty is empty.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Child timer_disabled_runtime_retains_the_native_failure, invocation75:
1. Contract: exact native Tokio timer panic, uncertain ID, zero rows and closed admission.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Invocation76: Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T22:25:32.6845947Z      Summary [   3.578s] 49 tests run: 49 passed, 1 skipped
1. Contract/counterexample: All49enabled command laws, including four actual recording-subscriber context/closure/outcome/data laws.
2. Execution/selection/services: Actual 49PASS command integration invocation via existing Nix feature job, locked dependencies and fail-on-no-tests; one original ignore. No database required.
3. Source/assertion/false positives: Source/test identity matches actual head; explicit feature mode, real selected laws and original data/parentage/count/closure oracles. Both bounded child parents actually PASS and retain exact-one/status/time-bound assertions.

Child readiness_release_allows_a_reentrant_stop_callback, invocation76:
1. Contract: real native readiness callback reenters stop and actual joined uncertainty is empty.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Child timer_disabled_runtime_retains_the_native_failure, invocation76:
1. Contract: exact native Tokio timer panic, uncertain ID, zero rows and closed admission.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Invocation77: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T22:25:22.6659030Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Features (mnesis-wake) isolated feature unit laws: 17 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,17PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation78: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T22:25:22.9447134Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Features (mnesis-wake) isolated feature unit laws: 17 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,17PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation79: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T22:25:23.2236870Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Features (mnesis-wake) isolated feature unit laws: 17 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,17PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.
