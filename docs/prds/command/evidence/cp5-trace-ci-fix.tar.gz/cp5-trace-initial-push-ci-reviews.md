# Initial tracing push CI 39685054084: three reviews per actual invocation

Exact head dc9882e8.79actual invocations:3compiler/30unit/2command integration/3replay/1workspace/40native adapter. Plain echoed PG summaries excluded. Workflow succeeded, but initial mutation gate FAILED separately; not a green PR or merged delivery. Raw cp5-trace-initial-push-ci.log. No metrics, command-native CP6, publication or release credit.

Invocation1: Postgres Integration	Postgres integration	2026-10-21T22:25:40.7532136Z mnesis-postgres-integration>      Summary [   0.703s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation2: Postgres Integration	Postgres integration	2026-10-21T22:25:45.7279445Z mnesis-postgres-integration>      Summary [   0.658s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation3: Postgres Integration	Postgres integration	2026-10-21T22:25:50.8411353Z mnesis-postgres-integration>      Summary [   1.024s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation4: Postgres Integration	Postgres integration	2026-10-21T22:25:56.8572541Z mnesis-postgres-integration>      Summary [   1.112s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation5: Postgres Integration	Postgres integration	2026-10-21T22:26:00.6118844Z mnesis-postgres-integration>      Summary [   0.709s] 1 test run: 1 passed, 10 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation6: Postgres Integration	Postgres integration	2026-10-21T22:26:08.4611627Z mnesis-postgres-integration>      Summary [   3.608s] 1 test run: 1 passed, 4 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation7: Postgres Integration	Postgres integration	2026-10-21T22:26:11.8816047Z mnesis-postgres-integration>      Summary [   0.037s] 1 test run: 1 passed, 9 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation8: Postgres Integration	Postgres integration	2026-10-21T22:27:22.9531558Z mnesis-postgres-integration>      Summary [  67.240s] 264 tests run: 264 passed, 0 skipped
1. Contract/counterexample: Full selected 264-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 264PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation9: Postgres Integration	Postgres integration	2026-10-21T22:27:25.3120081Z mnesis-postgres-integration>      Summary [   0.047s] 1 test run: 1 passed, 39 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation10: Postgres Integration	Postgres integration	2026-10-21T22:28:06.6910374Z mnesis-postgres-integration>      Summary [  39.089s] 149 tests run: 149 passed, 0 skipped
1. Contract/counterexample: Full selected 149-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 149PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation11: Postgres Integration	Postgres integration	2026-10-21T22:28:09.3635032Z mnesis-postgres-integration>      Summary [   0.253s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation12: Postgres Integration	Postgres integration	2026-10-21T22:28:55.7492945Z mnesis-postgres-integration>      Summary [  43.875s] 168 tests run: 168 passed, 0 skipped
1. Contract/counterexample: Full selected 168-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 168PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation13: Postgres Integration	Postgres integration	2026-10-21T22:28:58.1294139Z mnesis-postgres-integration>      Summary [   0.056s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation14: Postgres Integration	Postgres integration	2026-10-21T22:29:40.7742248Z mnesis-postgres-integration>      Summary [  40.272s] 176 tests run: 176 passed, 0 skipped
1. Contract/counterexample: Full selected 176-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 176PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation15: Postgres Integration	Postgres integration	2026-10-21T22:29:43.5720609Z mnesis-postgres-integration>      Summary [   0.309s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation16: Postgres Integration	Postgres integration	2026-10-21T22:30:26.2428699Z mnesis-postgres-integration>      Summary [  40.084s] 173 tests run: 173 passed, 0 skipped
1. Contract/counterexample: Full selected 173-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 173PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation17: Postgres Integration	Postgres integration	2026-10-21T22:30:28.6551572Z mnesis-postgres-integration>      Summary [   0.059s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation18: Postgres Integration	Postgres integration	2026-10-21T22:31:07.3619365Z mnesis-postgres-integration>      Summary [  36.303s] 174 tests run: 174 passed, 0 skipped
1. Contract/counterexample: Full selected 174-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 174PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation19: Postgres Integration	Postgres integration	2026-10-21T22:31:10.7909689Z mnesis-postgres-integration>      Summary [   1.053s] 1 test run: 1 passed, 0 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation20: Postgres Integration	Postgres integration	2026-10-21T22:31:49.8676933Z mnesis-postgres-integration>      Summary [  36.642s] 150 tests run: 150 passed, 0 skipped
1. Contract/counterexample: Full selected 150-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 150PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation21: Nix Flake Check	Flake Check	2026-10-21T22:17:29.5273931Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing actual decoder corpus group with2law(s); replay, not a fresh random campaign.
2. Execution/selection/services: Actual executable2PASS/zero failed/ignored/filtered, no database needed.
3. Source/assertion/false positives: Existing target/corpus/assertions unchanged; finite replay alone does not prove arbitrary-input completeness, command behavior or durability.

Invocation22: Nix Flake Check	Flake Check	2026-10-21T22:17:30.5293212Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing actual decoder corpus group with1law(s); replay, not a fresh random campaign.
2. Execution/selection/services: Actual executable1PASS/zero failed/ignored/filtered, no database needed.
3. Source/assertion/false positives: Existing target/corpus/assertions unchanged; finite replay alone does not prove arbitrary-input completeness, command behavior or durability.

Invocation23: Nix Flake Check	Flake Check	2026-10-21T22:17:31.5311642Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s
1. Contract/counterexample: Existing actual decoder corpus group with1law(s); replay, not a fresh random campaign.
2. Execution/selection/services: Actual executable1PASS/zero failed/ignored/filtered, no database needed.
3. Source/assertion/false positives: Existing target/corpus/assertions unchanged; finite replay alone does not prove arbitrary-input completeness, command behavior or durability.

Invocation24: Nix Flake Check	Flake Check	2026-10-21T22:26:58.0663327Z mnesis-nextest>      Summary [ 116.843s] 1639 tests run: 1639 passed (4 slow), 5 skipped
1. Contract/counterexample: Whole workspace including45actual default command laws and original identity/late-commit/custody/resource/property invariants. Four trace laws not inferred from this default invocation.
2. Execution/selection/services: 1639actual PASS/144binaries/five existing exclusions; adapter cases without a service gain no native credit here.
3. Source/assertion/false positives: Original assertions/workloads/selection remain. Both bounded children actually PASS; exact child reviews below. No source default gate inflation into49trace passes.

Child readiness_release_allows_a_reentrant_stop_callback, invocation24:
1. Contract: real native readiness callback reenters stop and actual joined uncertainty is empty.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Child timer_disabled_runtime_retains_the_native_failure, invocation24:
1. Contract: exact native Tokio timer panic, uncertain ID, zero rows and closed admission.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Invocation25: Nix Flake Check	Flake Check	2026-10-21T22:33:34.6785102Z mnesis-postgres-integration>      Summary [   0.286s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation26: Nix Flake Check	Flake Check	2026-10-21T22:33:39.8730864Z mnesis-postgres-integration>      Summary [   0.835s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation27: Nix Flake Check	Flake Check	2026-10-21T22:33:45.0338036Z mnesis-postgres-integration>      Summary [   1.099s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation28: Nix Flake Check	Flake Check	2026-10-21T22:33:50.2569627Z mnesis-postgres-integration>      Summary [   1.301s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation29: Nix Flake Check	Flake Check	2026-10-21T22:33:54.9105641Z mnesis-postgres-integration>      Summary [   0.767s] 1 test run: 1 passed, 10 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation30: Nix Flake Check	Flake Check	2026-10-21T22:34:03.3109421Z mnesis-postgres-integration>      Summary [   3.972s] 1 test run: 1 passed, 4 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation31: Nix Flake Check	Flake Check	2026-10-21T22:34:06.4744282Z mnesis-postgres-integration>      Summary [   0.034s] 1 test run: 1 passed, 9 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation32: Nix Flake Check	Flake Check	2026-10-21T22:35:12.2535214Z mnesis-postgres-integration>      Summary [  62.124s] 264 tests run: 264 passed, 0 skipped
1. Contract/counterexample: Full selected 264-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 264PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation33: Nix Flake Check	Flake Check	2026-10-21T22:35:14.1451458Z mnesis-postgres-integration>      Summary [   0.046s] 1 test run: 1 passed, 39 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation34: Nix Flake Check	Flake Check	2026-10-21T22:35:51.5245466Z mnesis-postgres-integration>      Summary [  35.177s] 149 tests run: 149 passed, 0 skipped
1. Contract/counterexample: Full selected 149-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 149PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation35: Nix Flake Check	Flake Check	2026-10-21T22:35:54.1410942Z mnesis-postgres-integration>      Summary [   0.365s] 1 test run: 1 passed, 7 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation36: Nix Flake Check	Flake Check	2026-10-21T22:36:38.3815784Z mnesis-postgres-integration>      Summary [  41.653s] 168 tests run: 168 passed, 0 skipped
1. Contract/counterexample: Full selected 168-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 168PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation37: Nix Flake Check	Flake Check	2026-10-21T22:36:40.3577132Z mnesis-postgres-integration>      Summary [   0.053s] 1 test run: 1 passed, 14 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation38: Nix Flake Check	Flake Check	2026-10-21T22:37:20.3834145Z mnesis-postgres-integration>      Summary [  37.793s] 176 tests run: 176 passed, 0 skipped
1. Contract/counterexample: Full selected 176-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 176PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation39: Nix Flake Check	Flake Check	2026-10-21T22:37:23.0971149Z mnesis-postgres-integration>      Summary [   0.316s] 1 test run: 1 passed, 2 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation40: Nix Flake Check	Flake Check	2026-10-21T22:38:03.0177939Z mnesis-postgres-integration>      Summary [  37.474s] 173 tests run: 173 passed, 0 skipped
1. Contract/counterexample: Full selected 173-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 173PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation41: Nix Flake Check	Flake Check	2026-10-21T22:38:05.3125395Z mnesis-postgres-integration>      Summary [   0.055s] 1 test run: 1 passed, 15 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation42: Nix Flake Check	Flake Check	2026-10-21T22:38:41.5749383Z mnesis-postgres-integration>      Summary [  33.978s] 174 tests run: 174 passed, 0 skipped
1. Contract/counterexample: Full selected 174-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 174PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation43: Nix Flake Check	Flake Check	2026-10-21T22:38:44.8735460Z mnesis-postgres-integration>      Summary [   1.052s] 1 test run: 1 passed, 0 skipped
1. Contract/counterexample: Actual required selected law mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields; matching feature must execute its supported native behavior.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 1PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Other cases deliberately filtered by required-law selection.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation44: Nix Flake Check	Flake Check	2026-10-21T22:39:20.7853090Z mnesis-postgres-integration>      Summary [  33.602s] 150 tests run: 150 passed, 0 skipped
1. Contract/counterexample: Full selected 150-law native adapter profile retains actual atomic/read/checkpoint/recovery/cleanup invariants.
2. Execution/selection/services: Actual derivation-prefixed Postgres execution with 150PASS; source/log retain SQL readiness, disposable service and fail-on-no-tests. Full selected suite zero skips.
3. Source/assertion/false positives: Exact head, actual selected PASS count/name; original native SQL/persistence/cleanup assertions unchanged. Service absence cannot replace this runner with green skipping; no command/native composition inference.

Invocation45: Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T22:17:17.8508304Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s
1. Contract/counterexample: Features (mnesis-command) isolated feature unit laws: 9 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,9PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation46: Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T22:17:18.6521533Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s
1. Contract/counterexample: Features (mnesis-command) isolated feature unit laws: 9 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,9PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation47: Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T22:17:19.4866556Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s
1. Contract/counterexample: Features (mnesis-command) isolated feature unit laws: 9 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,9PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation48: Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T22:17:28.6230708Z      Summary [   3.481s] 45 tests run: 45 passed, 1 skipped
1. Contract/counterexample: All45default command laws retain non-instrumented public semantics, exact data, typed causes and uncertainty.
2. Execution/selection/services: Actual 45PASS command integration invocation via existing Nix feature job, locked dependencies and fail-on-no-tests; one original ignore. No database required.
3. Source/assertion/false positives: Source/test identity matches actual head; explicit feature mode, real selected laws and original data/parentage/count/closure oracles. Both bounded child parents actually PASS and retain exact-one/status/time-bound assertions.

Child readiness_release_allows_a_reentrant_stop_callback, invocation48:
1. Contract: real native readiness callback reenters stop and actual joined uncertainty is empty.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Child timer_disabled_runtime_retains_the_native_failure, invocation48:
1. Contract: exact native Tokio timer panic, uncertain ID, zero rows and closed admission.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Invocation49: Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T22:17:39.4588863Z      Summary [   3.727s] 49 tests run: 49 passed, 1 skipped
1. Contract/counterexample: All49enabled command laws, including four actual recording-subscriber context/closure/outcome/data laws.
2. Execution/selection/services: Actual 49PASS command integration invocation via existing Nix feature job, locked dependencies and fail-on-no-tests; one original ignore. No database required.
3. Source/assertion/false positives: Source/test identity matches actual head; explicit feature mode, real selected laws and original data/parentage/count/closure oracles. Both bounded child parents actually PASS and retain exact-one/status/time-bound assertions.

Child readiness_release_allows_a_reentrant_stop_callback, invocation49:
1. Contract: real native readiness callback reenters stop and actual joined uncertainty is empty.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Child timer_disabled_runtime_retains_the_native_failure, invocation49:
1. Contract: exact native Tokio timer panic, uncertain ID, zero rows and closed admission.
2. Execution: actual parent PASS; existing helper requires exact child name, exactly one PASS and successful child status within2seconds.
3. Source/assertion: original exact helper/oracle unchanged; zero selection, wrong panic, process failure or deadlock cannot pass. No extra top-level count inferred from the nested child.

Invocation50: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T22:17:39.8858135Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.92s
1. Contract/counterexample: Features (mnesis-store) isolated feature unit laws: 217 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,217PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation51: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T22:17:41.7333147Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.73s
1. Contract/counterexample: Features (mnesis-store) isolated feature unit laws: 217 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,217PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation52: Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T22:17:47.4106963Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.66s
1. Contract/counterexample: Features (mnesis-store) isolated feature unit laws: 217 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,217PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation53: Compile-fail tests	Kernel compile-fail tests	2026-10-21T22:17:39.9657496Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 120.73s
1. Contract/counterexample: Compile-fail tests preserves existing supported/misuse diagnostic compiler fixtures,2harness cases.
2. Execution/selection/services: Actual checkout harness2PASS/zero failed/ignored/filtered; separate from five default Nix exclusions.
3. Source/assertion/false positives: Original expected diagnostics and positive/negative fixtures unchanged; no runtime, native or publication inference from compiler success.

Invocation54: Compile-fail tests	Macro compile-fail tests	2026-10-21T22:18:13.2753034Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 14.96s
1. Contract/counterexample: Compile-fail tests preserves existing supported/misuse diagnostic compiler fixtures,1harness cases.
2. Execution/selection/services: Actual checkout harness1PASS/zero failed/ignored/filtered; separate from five default Nix exclusions.
3. Source/assertion/false positives: Original expected diagnostics and positive/negative fixtures unchanged; no runtime, native or publication inference from compiler success.

Invocation55: Compile-fail tests	Store compile-fail tests	2026-10-21T22:18:39.4795089Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 18.46s
1. Contract/counterexample: Compile-fail tests preserves existing supported/misuse diagnostic compiler fixtures,1harness cases.
2. Execution/selection/services: Actual checkout harness1PASS/zero failed/ignored/filtered; separate from five default Nix exclusions.
3. Source/assertion/false positives: Original expected diagnostics and positive/negative fixtures unchanged; no runtime, native or publication inference from compiler success.

Invocation56: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T22:17:19.3528175Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Features (mnesis-wake) isolated feature unit laws: 17 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,17PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation57: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T22:17:19.6414769Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Features (mnesis-wake) isolated feature unit laws: 17 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,17PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation58: Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T22:17:19.9294575Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s
1. Contract/counterexample: Features (mnesis-wake) isolated feature unit laws: 17 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,17PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation59: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T22:18:03.3868062Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-postgres) isolated feature unit laws: 11 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,11PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation60: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T22:18:03.5261575Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-postgres) isolated feature unit laws: 11 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,11PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation61: Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T22:18:06.2816498Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-postgres) isolated feature unit laws: 11 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,11PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation62: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T22:17:13.0853128Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation63: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T22:17:13.2156111Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation64: Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T22:17:13.3438619Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation65: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T22:17:17.7554356Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-macros) isolated feature unit laws: 1 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,1PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation66: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T22:17:17.8703291Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-macros) isolated feature unit laws: 1 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,1PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation67: Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T22:17:17.9854076Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis-macros) isolated feature unit laws: 1 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,1PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation68: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T22:17:56.3523388Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.50s
1. Contract/counterexample: Features (mnesis-fjall) isolated feature unit laws: 131 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,131PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation69: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T22:17:58.9062588Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.39s
1. Contract/counterexample: Features (mnesis-fjall) isolated feature unit laws: 131 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,131PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation70: Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T22:18:01.4855052Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.41s
1. Contract/counterexample: Features (mnesis-fjall) isolated feature unit laws: 131 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,131PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation71: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T22:17:06.4427568Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s
1. Contract/counterexample: Features (mnesis-inmemory) isolated feature unit laws: 25 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,25PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation72: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T22:17:06.6134542Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s
1. Contract/counterexample: Features (mnesis-inmemory) isolated feature unit laws: 25 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,25PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation73: Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T22:17:09.2164691Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s
1. Contract/counterexample: Features (mnesis-inmemory) isolated feature unit laws: 30 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,30PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation74: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T22:17:24.8927955Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation75: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T22:17:25.0100308Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation76: Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T22:17:25.1266723Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: This feature harness contains zero unit cases; compilation/feature availability only, no runtime proof.
2. Execution/selection/services: Distinct actual harness invocation,0PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Zero stays visible; no behavior or concurrency/durability inference.

Invocation77: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T22:17:38.1930883Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis) isolated feature unit laws: 15 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,15PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation78: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T22:17:38.3434902Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis) isolated feature unit laws: 15 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,15PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.

Invocation79: Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T22:17:38.9260480Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
1. Contract/counterexample: Features (mnesis) isolated feature unit laws: 15 actual passing cases.
2. Execution/selection/services: Distinct actual harness invocation,15PASS/zero failed/ignored/filtered; no native service credit.
3. Source/assertion/false positives: Original unit source/assertions unchanged; integration/native contracts verified separately rather than inferred.
