# CP5 tracing final-head fuzz reviews

Run39692645752, signed headc13ef43fe4e60cdfacb3f747b5f00d867b412aee,
8actual campaigns. Raw cp5-trace-ci-fixed-fuzz.log. These are the unchanged
codec fuzz owners, NOT command identity/history/native-adapter fuzz evidence.
No corpus reduction, claim of exhaustive coverage or new fuzz runtime introduced.

## libFuzzer cbor_decode_chunk
1. Contract: existing bounded chunk decoder arbitrary-input boundary.
2. Execution:1,532,087actual iterations/61s, completed success, no database.
3. Assertions/source: existing harness/oracles; nonzero engine progress, no codec
failure/crash reported; not command-processor coverage.

## libFuzzer cbor_decode_header
1. Contract: existing bounded header decoder arbitrary-input boundary.
2. Execution:1,798,399actual iterations/61s, completed success, no database.
3. Assertions/source: unchanged harness/corpus, actual progress rather than
build-only/zero-test credit; no arbitrary format-proof or command claim.

## libFuzzer wire_decode_frame
1. Contract: existing frame validation/decoder input boundary.
2. Execution:8,891,245actual iterations/61s, completed success, no database.
3. Assertions/source: unchanged harness/oracles, no crash; no command history
acceptance or publisher claim inferred.

## libFuzzer value_event_type
1. Contract: existing value/event-type decoder input boundary.
2. Execution:6,041,407actual iterations/61s, completed success, no database.
3. Assertions/source: unchanged harness/corpus/limits, no failure; not command
processor stateful-history fuzz evidence.

## AFL++ cbor_decode_chunk
1. Contract: existing chunk decoder boundary under actual CMPLOG exploration.
2. Execution:60s/11newitems/43.39%coverage/0savedcrashes/0timeouts; CMPLOGconfirmed.
3. Assertions/source: unchanged engine/harness and saved-crash verdict, actual
fuzzer statistics retained; coverage percentage is not complete product proof.

## AFL++ cbor_decode_header
1. Contract: existing header decoder arbitrary-input boundary with CMPLOG.
2. Execution:60s/1newitem/47.61%coverage/0savedcrashes/0timeouts; CMPLOGconfirmed.
3. Assertions/source: actual completed campaign plus native crash verdict,
unchanged corpus/oracles; not a command processor gate substitute.

## AFL++ wire_decode_frame
1. Contract: existing wire-frame input/verification boundaries with CMPLOG.
2. Execution:60s/0newitems/34.33%coverage/0savedcrashes/0timeouts; CMPLOGconfirmed.
3. Assertions/source: existing harness/assertions/crash verdict, native runtime
statistics not inferred from successful compilation; no native recovery claim.

## AFL++ value_event_type
1. Contract: existing value/event-type input boundaries with CMPLOG.
2. Execution:60s/0newitems/8.31%coverage/0savedcrashes/0timeouts; CMPLOGconfirmed.
3. Assertions/source: unchanged native crash verdict and harness, actual iterations
shown in raw log, not zero selection; no stateful command or exhaustive proof.
