# CP5 tracing exact-head CI mutation reviews

Run39692645711, artifact12390115765, signed headc13ef43fe4e60cdfacb3f747b5f00d867b412aee. Baseline49PASS;63mutants23caught/40compiler-only/0missed/timeout. All64outcomes examined;24actual nextest runs. Original failed five uncompiled conditional helpers remain archived separately. No gate/skip/exclusion/assertion change.

Each entry records contract, execution and assertion/source reviews separately. Runtime failures are from changed production bodies against unchanged owning tests. Serial fail-fast logs retain49 scheduled cases but only actual completed counts get credit. Existing ignored measurement remains ignored. No external database used. Successful bounded children have independent reviews per reached parent; their counts are not added to the nextest case count.

## Baseline

1. Contract/counterexample: Original45 command laws and4 enabled trace laws cover native causes/custody, original identity/atomic records and independent subscriber contexts; all49 pass.
2. Actual execution: Summary [   3.279s] 49 tests run: 49 passed, 1 skipped; native Test status "Success". Log log/baseline.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; unmodified baseline, no false green through zero selection. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/engine.rs:74:9: replace Engine<S, A, C, I, N>::load -> Result<Root<A, C, I, N>, Error<A::Error, I, S::Error>> with Ok(Default::default())

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `AggregateRoot<Adapted<A, C, I, N>>: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__engine.rs_line_74_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/engine.rs:88:9: replace Engine<S, A, C, I, N>::settle -> Result<(), Error<A::Error, I, S::Error>> with Ok(())

1. Contract/counterexample: An unresolved append must remain a barrier; generated histories reject missing Uncertain at history.rs159.
2. Actual execution: Summary [   0.120s] 11/49 tests run: 10 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__engine.rs_line_88_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::new())

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope.
3. Assertion/source: log/crates__command__src__engine.rs_line_179_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::from_iter([Default::default()]))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope.
3. Assertion/source: log/crates__command__src__engine.rs_line_179_col_9_001.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::new(Default::default()))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope.
3. Assertion/source: log/crates__command__src__engine.rs_line_179_col_9_002.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::from(Default::default()))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__engine.rs_line_179_col_9_003.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:126:9: replace Message<A, C, I, E>::operation -> &'static str with ""

1. Contract/counterexample: Operation labels must retain the caller operation; exact [submit] rejects the substituted label at trace.rs379.
2. Actual execution: Summary [   3.181s] 47/49 tests run: 46 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_126_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/host.rs:126:9: replace Message<A, C, I, E>::operation -> &'static str with "xyzzy"

1. Contract/counterexample: Operation labels must retain the caller operation; exact [submit] rejects the substituted label at trace.rs379.
2. Actual execution: Summary [   3.379s] 47/49 tests run: 46 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_126_col_9_001.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/host.rs:160:9: replace Call<A, C, I, E>::finish with ()

1. Contract/counterexample: Queued abort must record closed, while active abort records interrupted; exact pair rejects an unchanged outcome at trace.rs303.
2. Actual execution: Summary [   3.195s] 46/49 tests run: 45 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_160_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/host.rs:167:9: replace Call<A, C, I, E>::reject with ()

1. Contract/counterexample: Stopping must complete queued responses with Closed; recovery.rs613 rejects silently dropped replies.
2. Actual execution: Summary [   3.268s] 32/49 tests run: 31 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_167_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/host.rs:176:5: replace respond with ()

1. Contract/counterexample: An admitted valid request must return its exact successful receipt; adaptation.rs465 rejects substituted Uncertain from a dropped response.
2. Actual execution: Summary [   0.047s] 10/49 tests run: 9 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_176_col_5.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/host.rs:195:9: replace Call<A, C, I, E>::execute with ()

1. Contract/counterexample: An admitted valid request must return its exact successful receipt; adaptation.rs465 rejects substituted Uncertain from a dropped response.
2. Actual execution: Summary [   0.040s] 10/49 tests run: 9 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_195_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/host.rs:237:9: replace <impl Drop for Inbox<A, C, I, E>>::drop with ()

1. Contract/counterexample: Stopping must complete queued responses with Closed; recovery.rs613 rejects silently dropped replies.
2. Actual execution: Summary [   3.197s] 32/49 tests run: 31 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_237_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/host.rs:334:9: replace CommandProcessor<A, C, I, N, E>::launch -> Started<S, A, C, I, N> with Default::default()

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `Result<(CommandProcessor<A, C, I, N, E>, Worker<C, I>), _>: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__host.rs_line_334_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:397:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(None)

1. Contract/counterexample: Known original receipt must remain available; generated history.rs185 rejects None.
2. Actual execution: Summary [   0.127s] 11/49 tests run: 10 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_397_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/host.rs:397:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::new()))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope.
3. Assertion/source: log/crates__command__src__host.rs_line_397_col_9_001.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:397:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::from_iter([Default::default()])))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope.
3. Assertion/source: log/crates__command__src__host.rs_line_397_col_9_002.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:397:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::new(Default::default())))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope.
3. Assertion/source: log/crates__command__src__host.rs_line_397_col_9_003.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:397:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::from(Default::default())))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__host.rs_line_397_col_9_004.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:419:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::new())

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope.
3. Assertion/source: log/crates__command__src__host.rs_line_419_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:419:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::from_iter([Default::default()]))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope.
3. Assertion/source: log/crates__command__src__host.rs_line_419_col_9_001.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:419:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::new(Default::default()))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope.
3. Assertion/source: log/crates__command__src__host.rs_line_419_col_9_002.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:419:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::from(Default::default()))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__host.rs_line_419_col_9_003.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:437:9: replace CommandProcessor<A, C, I, N, E>::read -> Result<(Option<Version>, A::State), Error<A::Error, I, E>> with Ok((None, Default::default()))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `<A as Aggregate>::State: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__host.rs_line_437_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:437:9: replace CommandProcessor<A, C, I, N, E>::read -> Result<(Option<Version>, A::State), Error<A::Error, I, E>> with Ok((Some(Default::default()), Default::default()))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `<A as Aggregate>::State: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__host.rs_line_437_col_9_001.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:448:9: replace CommandProcessor<A, C, I, N, E>::original -> Result<Option<Request<C, I>>, Error<A::Error, I, E>> with Ok(None)

1. Contract/counterexample: Accepted original must retain exact identity, CAS and command; adaptation.rs503 rejects None.
2. Actual execution: Summary [   0.043s] 10/49 tests run: 9 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_448_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/host.rs:448:9: replace CommandProcessor<A, C, I, N, E>::original -> Result<Option<Request<C, I>>, Error<A::Error, I, E>> with Ok(Some(Default::default()))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `model::Request<C, I>: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__host.rs_line_448_col_9_001.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:459:9: replace CommandProcessor<A, C, I, N, E>::send -> Result<(), Error<A::Error, I, E>> with Ok(())

1. Contract/counterexample: Real bounded admission must transfer and return the original receipt; adaptation.rs465 rejects Uncertain from a fake successful send.
2. Actual execution: Summary [   0.045s] 10/49 tests run: 9 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_459_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/host.rs:513:9: replace <impl Service<Request<C, I>> for CommandProcessor<A, C, I, N, E>>::call -> Self::Future with Default::default()

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `dyn Future<Output = Result<Receipt<I>, _>> + Send: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__host.rs_line_513_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/host.rs:566:5: replace run with ()

1. Contract/counterexample: An admitted valid request must return its exact successful receipt; adaptation.rs465 rejects substituted Uncertain from a dropped response.
2. Actual execution: Summary [   0.046s] 10/49 tests run: 9 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__host.rs_line_566_col_5.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(None)

1. Contract/counterexample: Receipt capacity must reject excess records including no-ops; exact HistoryFull at model unit334 rejects the missing or inverted bound.
2. Actual execution: Summary [   0.020s] 4/49 tests run: 3 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__model.rs_line_422_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new()))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0061]: this function takes 1 argument but 0 arguments were supplied.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_001.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::new()])))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_002.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::new())))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `new` found for type `_` in the current scope.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_003.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::new())))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `new` found for type `_` in the current scope.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_004.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::from_iter([Default::default()])])))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_005.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::from_iter([Default::default()]))))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: a value of type `model::Record<C, I, <<A as Aggregate>::State as AggregateState>::Event>` cannot be built from an iterator over elements of type `_`.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_006.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::from_iter([Default::default()]))))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0283]: type annotations needed.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_007.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::new(Default::default())])))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_008.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::new(Default::default()))))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `new` found for type `_` in the current scope.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_009.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::new(Default::default()))))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `new` found for type `_` in the current scope.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_010.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::from(Default::default())])))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_011.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::from(Default::default()))))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `model::Record<C, I, <<A as Aggregate>::State as AggregateState>::Event>: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_012.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::from(Default::default()))))

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0283]: type annotations needed.
3. Assertion/source: log/crates__command__src__model.rs_line_422_col_9_013.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/model.rs:425:37: replace >= with < in <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle

1. Contract/counterexample: Receipt capacity must reject excess records including no-ops; exact HistoryFull at model unit334 rejects the missing or inverted bound.
2. Actual execution: Summary [   0.021s] 4/49 tests run: 3 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__model.rs_line_425_col_37.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

## crates/command/src/trace.rs:24:9: replace Trace::request -> Self with Default::default()

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `Trace: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__trace.rs_line_24_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/trace.rs:42:9: replace Trace::worker -> Self with Default::default()

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `Trace: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__trace.rs_line_42_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/trace.rs:54:9: replace Trace::stage -> Self with Default::default()

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `Trace: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__trace.rs_line_54_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/trace.rs:72:9: replace Trace::scope -> Scope with Default::default()

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `trace::Scope: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__trace.rs_line_72_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/trace.rs:77:9: replace Trace::child -> Self with Default::default()

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `Trace: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__trace.rs_line_77_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/trace.rs:80:9: replace Trace::finish with ()

1. Contract/counterexample: Queued abort must record closed, while active abort records interrupted; exact pair rejects an unchanged outcome at trace.rs303.
2. Actual execution: Summary [   3.303s] 46/49 tests run: 45 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__trace.rs_line_80_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/trace.rs:90:9: replace <impl Drop for Trace>::drop with ()

1. Contract/counterexample: Abort trace outcomes must exist; native recorded outcome lookup at trace.rs301 rejects omitted final recording.
2. Actual execution: Summary [   3.267s] 46/49 tests run: 45 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__trace.rs_line_90_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/trace.rs:107:9: replace Scope::sync -> T with Default::default()

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `T: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__trace.rs_line_107_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/trace.rs:118:9: replace Scope::run -> F::Output with Default::default()

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `<F as Future>::Output: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__trace.rs_line_118_col_9.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/trace.rs:134:9: replace <impl Drop for Scope>::drop with ()

1. Contract/counterexample: Final span release must use the captured dispatcher; native registry panic and failed cancellation cause at trace.rs286 reject omitted cleanup.
2. Actual execution: Summary [   3.154s] 46/49 tests run: 45 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__trace.rs_line_134_col_9.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/trace.rs:145:5: replace step -> Result<T, Error<D, I, E>> with Ok(Default::default())

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `T: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__trace.rs_line_145_col_5.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/trace.rs:156:5: replace sync -> Result<T, E> with Ok(Default::default())

1. Contract: replacement is rejected by the actual Rust type/interface contract; no runtime invariant claimed.
2. Execution: build phase fails101; no Test phase or actual test run. First diagnostic: error[E0277]: the trait bound `T: Default` is not satisfied.
3. Assertion/source: log/crates__command__src__trace.rs_line_156_col_5.log and native mutant diff identify the selected product owner; compiler rejection is not a behavioral catch. No assertion or workaround added.

## crates/command/src/trace.rs:164:5: replace invalid_request with ()

1. Contract/counterexample: Invalid direct and Tower requests remain observed; exact [ok,request,request] at trace.rs566 rejects missing request spans.
2. Actual execution: Summary [   3.246s] 48/49 tests run: 47 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__trace.rs_line_164_col_5.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/trace.rs:170:5: replace outcome -> &'static str with ""

1. Contract/counterexample: Stage outcomes retain exact ok; trace.rs387 rejects empty or xyzzy.
2. Actual execution: Summary [   3.443s] 47/49 tests run: 46 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__trace.rs_line_170_col_5.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/trace.rs:170:5: replace outcome -> &'static str with "xyzzy"

1. Contract/counterexample: Stage outcomes retain exact ok; trace.rs387 rejects empty or xyzzy.
2. Actual execution: Summary [   3.185s] 47/49 tests run: 46 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__trace.rs_line_170_col_5_001.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/trace.rs:191:5: replace accepted with ()

1. Contract/counterexample: A newly observed acceptance emits exactly one event; trace.rs235 rejects zero.
2. Actual execution: Summary [   3.194s] 47/49 tests run: 46 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__trace.rs_line_191_col_5.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/trace.rs:195:5: replace duplicate with ()

1. Contract/counterexample: An exact retry emits duplicate alongside accepted, not another acceptance; trace.rs466 rejects the missing duplicate.
2. Actual execution: Summary [   3.310s] 47/49 tests run: 46 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__trace.rs_line_195_col_5.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.

## crates/command/src/trace.rs:199:5: replace reply_dropped with ()

1. Contract/counterexample: An admitted dropped response emits reply_dropped alongside accepted; trace.rs466 rejects omitted cancellation observation.
2. Actual execution: Summary [   3.225s] 47/49 tests run: 46 passed, 1 failed, 1 skipped; native Test status {"Failure":100}. Log log/crates__command__src__trace.rs_line_199_col_5.log. Later canceled cases receive no credit.
3. Assertions/source: exact source/assertion location retained in the raw log and mutation diff; compiled product mutant produces the intended observable assertion failure, not a service/setup or compiler failure. No workload, deadline, test assertion or gate weakened.

Reentrant child three reviews: (1) real native callback stop, exact wake1, Closed readiness and normal empty pending join; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged notification/join assertions reject a swallowed callback, skipped test or deadlock.

Timer child three reviews: (1) exact native disabled-timer panic, caller Uncertain ID, zero rows/Closed and empty pending report; (2) actual parent PASS after exact-one-test child/status/2s checks; (3) unchanged helper and native payload assertions reject empty selection, substituted panic or process failure.


