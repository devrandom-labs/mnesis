# PR418 original final-head PR CI failure

Run39692645748 attempt1, virtual779e5877f0acf3d40b31d7c7a97befeb5c1a5cd1,
signed headc13ef43f, expected treef2036076. Nix job119542318013 exits100.
Whole raw/failure logs retained. Successful push39692638604 is not a replacement
for the failed required PR check. No protected merge before an actual accepted run.

Failure is Nix native snapshot profile invocation76/174:75PASS/1FAIL/98notrun,
0SKIP/11.917s. Exact failing law initial_listener_acquisition_failure_recovers_
after_service_returns, lifecycle_tests.rs134. Three reviews:
1. Contract/counterexamples: actual code lines131-134 await PgPoolOptions.connect_
with before line135 PostgresStore::from_pool. Its100ms healthy pool deadline
expires with PoolTimedOut; target listener injection/recovery/notification
assertions have NOT executed in this case. Do not claim observed listener defect
or cause from filesystem/load timing: why this initial connection was slow is not
proven. Previous native cases/service readiness actual, not absent-service skipping.
2. Actual execution/selection/services: actual whole snapshot174case invocation
fails after76executed. The failed individual libtest stdout0PASS1FAIL/10filtered
is nested diagnostics, not an extra suite or second failure. Remaining98snapshot
cases and subsequent tracing smoke/full native runs are unexecuted. Disposable
server ready and previous native laws pass, then normal service cleanup executes.
3. Assertions/source/false positives: source is untouched adapter fixture, exact
same100ms before_acquire/after_connect injected failure profile used throughout.
Failure occurs in healthy fixture construction before product listener launch;
no proof that adapter recovery regressed. Same-source prior complete native jobs
pass, but this failure remains visible. No assertion/timeout/workload/gate change.

Next experiment: normal failed-job rerun on same exact head/tree. Budget0source,
0test/config edits. Preserve all original failed logs and review every actual
rerun invocation/selection/service result. This can establish repeated versus
nonrepeated healthy fixture timeout; it does not claim a repaired fixture or
explain the environment. Recurrence requires focused fixture/SQLx diagnosis,
never relaxed100ms injection deadline/200ms hold/500ms wake or skipped test.
