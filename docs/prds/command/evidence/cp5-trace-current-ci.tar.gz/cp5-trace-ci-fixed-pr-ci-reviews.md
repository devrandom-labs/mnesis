# Tracing original final-head PR CI reviews

Run39692645748 attempt1 FAILED; virtual779e5877f0acf3d40b31d7c7a97befeb5c1a5cd1, headc13ef43f/treef2036076.77harness outcomes,6zero-case compilation-only;71nonzero invocations.3compiler,30unit,2command,3replay,1workspace,38native. Plain echoed PG264summary and nested failing libtest diagnostics are not extra invocations. Snapshot invocation fails after76/174cases;98snapshot and following tracing native smoke/full cases are unexecuted. Whole gate remains FAILED despite other successful jobs. Raw cp5-trace-ci-fixed-pr-ci.log/failure review preserved. Same-source failed-job rerun only is separate attempt2; no altered assertions/workload/timeout/selector/gate.

## Outcome 1

Compile-fail tests	Kernel compile-fail tests	2026-10-21T23:25:07.1369651Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 130.20s

1. Contract/counterexamples: Actual intended kernel/macro/store misuse diagnostics and valid fixture behavior.
2. Actual execution/selection/services: Actual2PASS compiler-fixture harness, no failure/ignore/filter/service.
3. Assertions/source/false positives: Exact repository toolchain/tree and unchanged stderr snapshots; no compiler/setup failure substituted for expected diagnostics.

## Outcome 2

Compile-fail tests	Macro compile-fail tests	2026-10-21T23:25:43.2232081Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 16.39s

1. Contract/counterexamples: Actual intended kernel/macro/store misuse diagnostics and valid fixture behavior.
2. Actual execution/selection/services: Actual1PASS compiler-fixture harness, no failure/ignore/filter/service.
3. Assertions/source/false positives: Exact repository toolchain/tree and unchanged stderr snapshots; no compiler/setup failure substituted for expected diagnostics.

## Outcome 3

Compile-fail tests	Store compile-fail tests	2026-10-21T23:26:11.4639278Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 19.88s

1. Contract/counterexamples: Actual intended kernel/macro/store misuse diagnostics and valid fixture behavior.
2. Actual execution/selection/services: Actual1PASS compiler-fixture harness, no failure/ignore/filter/service.
3. Assertions/source/false positives: Exact repository toolchain/tree and unchanged stderr snapshots; no compiler/setup failure substituted for expected diagnostics.

## Outcome 4

Postgres Integration	Postgres integration	2026-10-21T23:28:30.9268689Z mnesis-postgres-integration>      Summary [   0.087s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 5

Postgres Integration	Postgres integration	2026-10-21T23:28:35.7017943Z mnesis-postgres-integration>      Summary [   0.712s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 6

Postgres Integration	Postgres integration	2026-10-21T23:28:41.9896461Z mnesis-postgres-integration>      Summary [   2.226s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 7

Postgres Integration	Postgres integration	2026-10-21T23:28:46.6716789Z mnesis-postgres-integration>      Summary [   0.652s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 8

Postgres Integration	Postgres integration	2026-10-21T23:28:52.8723081Z mnesis-postgres-integration>      Summary [   2.076s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 9

Postgres Integration	Postgres integration	2026-10-21T23:28:58.5999295Z mnesis-postgres-integration>      Summary [   1.698s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 10

Postgres Integration	Postgres integration	2026-10-21T23:29:02.7087654Z mnesis-postgres-integration>      Summary [   0.045s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 11

Postgres Integration	Postgres integration	2026-10-21T23:30:12.1798256Z mnesis-postgres-integration>      Summary [  65.293s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual264PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 12

Postgres Integration	Postgres integration	2026-10-21T23:30:14.9807957Z mnesis-postgres-integration>      Summary [   0.057s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 13

Postgres Integration	Postgres integration	2026-10-21T23:30:57.0977661Z mnesis-postgres-integration>      Summary [  39.388s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual149PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 14

Postgres Integration	Postgres integration	2026-10-21T23:31:00.1643141Z mnesis-postgres-integration>      Summary [   0.192s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 15

Postgres Integration	Postgres integration	2026-10-21T23:31:47.1810065Z mnesis-postgres-integration>      Summary [  44.040s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual168PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 16

Postgres Integration	Postgres integration	2026-10-21T23:31:49.9958633Z mnesis-postgres-integration>      Summary [   0.069s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 17

Postgres Integration	Postgres integration	2026-10-21T23:32:38.6662094Z mnesis-postgres-integration>      Summary [  45.833s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual176PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 18

Postgres Integration	Postgres integration	2026-10-21T23:32:42.2412477Z mnesis-postgres-integration>      Summary [   0.636s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 19

Postgres Integration	Postgres integration	2026-10-21T23:33:26.4616848Z mnesis-postgres-integration>      Summary [  41.136s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual173PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 20

Postgres Integration	Postgres integration	2026-10-21T23:33:29.3197863Z mnesis-postgres-integration>      Summary [   0.077s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 21

Postgres Integration	Postgres integration	2026-10-21T23:34:13.7369648Z mnesis-postgres-integration>      Summary [  41.533s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual174PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 22

Postgres Integration	Postgres integration	2026-10-21T23:34:17.5976263Z mnesis-postgres-integration>      Summary [   1.061s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 23

Postgres Integration	Postgres integration	2026-10-21T23:34:59.9945659Z mnesis-postgres-integration>      Summary [  39.472s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual150PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 24

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T23:27:17.7205185Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Features (mnesis-command) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual9PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 25

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T23:27:18.6068016Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Features (mnesis-command) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual9PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 26

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T23:27:19.5267285Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Features (mnesis-command) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual9PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 27

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T23:27:29.0847121Z      Summary [   3.598s] 45 tests run: 45 passed, 1 skipped

1. Contract/counterexamples: All45original command laws with tracing disabled; no enabled-stage runtime claim.
2. Actual execution/selection/services: Actual45PASS full required command integration,1original ignored optimized measurement; locked/fail-on-no-tests, controlled in-memory only.
3. Assertions/source/false positives: Exact mode/source and actual original data/typed identity/lifecycle assertions; no weakened selection. Both subprocess parents PASS, separately reviewed.

Readiness child: (1) actual callback stop/exact wake1/Closed/normal empty join; (2) actual parent PASS checks exact-one-child/status/2s; (3) unchanged notification/join rejects missing callback/deadlock.

Timer child: (1) exact timer panic/caller Uncertain ID/zero rows/Closed/empty report; (2) actual parent PASS checks exact-one-child/status/2s; (3) native payload/name/summary rejects wrong cause, zero selection or failed/stuck process. Each child separately3reviewed, not added to outcome count.

## Outcome 28

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T23:27:40.7355710Z      Summary [   4.067s] 49 tests run: 49 passed, 1 skipped

1. Contract/counterexamples: Original45laws plus4independent subscriber parentage/closure/outcome/data laws.
2. Actual execution/selection/services: Actual49PASS full required command integration,1original ignored optimized measurement; locked/fail-on-no-tests, controlled in-memory only.
3. Assertions/source/false positives: Exact mode/source and actual original data/typed identity/lifecycle assertions; no weakened selection. Both subprocess parents PASS, separately reviewed.

Readiness child: (1) actual callback stop/exact wake1/Closed/normal empty join; (2) actual parent PASS checks exact-one-child/status/2s; (3) unchanged notification/join rejects missing callback/deadlock.

Timer child: (1) exact timer panic/caller Uncertain ID/zero rows/Closed/empty report; (2) actual parent PASS checks exact-one-child/status/2s; (3) native payload/name/summary rejects wrong cause, zero selection or failed/stuck process. Each child separately3reviewed, not added to outcome count.

## Outcome 29

Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T23:24:34.8156927Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases selected; compilation-only support.
2. Actual execution/selection/services: Actual zero-case unit harness, zero failures/ignored/filtered, no behavioral or native-service credit.
3. Assertions/source/false positives: Explicit zero selection retained, not advertised as exercised behavior; owning integration/native tests separate.

## Outcome 30

Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T23:24:34.9602813Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases selected; compilation-only support.
2. Actual execution/selection/services: Actual zero-case unit harness, zero failures/ignored/filtered, no behavioral or native-service credit.
3. Assertions/source/false positives: Explicit zero selection retained, not advertised as exercised behavior; owning integration/native tests separate.

## Outcome 31

Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T23:24:35.1007420Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases selected; compilation-only support.
2. Actual execution/selection/services: Actual zero-case unit harness, zero failures/ignored/filtered, no behavioral or native-service credit.
3. Assertions/source/false positives: Explicit zero selection retained, not advertised as exercised behavior; owning integration/native tests separate.

## Outcome 32

Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T23:25:08.3798458Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Features (mnesis-wake) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual17PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 33

Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T23:25:08.6709454Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Features (mnesis-wake) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual17PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 34

Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T23:25:08.9590677Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Features (mnesis-wake) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual17PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 35

Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T23:24:56.2967309Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-macros) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual1PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 36

Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T23:24:56.4317974Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-macros) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual1PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 37

Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T23:24:56.5709305Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-macros) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual1PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 38

Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T23:28:16.5300707Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-postgres) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual11PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 39

Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T23:28:16.6780953Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-postgres) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual11PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 40

Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T23:28:19.3155399Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-postgres) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual11PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 41

Nix Flake Check	Flake Check	2026-10-21T23:28:41.8243865Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Actual existing saved-corpus decoder boundary assertions, not new arbitrary-input fuzz.
2. Actual execution/selection/services: Actual2PASS, no failures/ignored/filtered/database.
3. Assertions/source/false positives: Unchanged decoder/corpus/oracles, nonzero execution; no command-state or native proof.

## Outcome 42

Nix Flake Check	Flake Check	2026-10-21T23:28:42.8264732Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Actual existing saved-corpus decoder boundary assertions, not new arbitrary-input fuzz.
2. Actual execution/selection/services: Actual1PASS, no failures/ignored/filtered/database.
3. Assertions/source/false positives: Unchanged decoder/corpus/oracles, nonzero execution; no command-state or native proof.

## Outcome 43

Nix Flake Check	Flake Check	2026-10-21T23:28:43.8286239Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Actual existing saved-corpus decoder boundary assertions, not new arbitrary-input fuzz.
2. Actual execution/selection/services: Actual1PASS, no failures/ignored/filtered/database.
3. Assertions/source/false positives: Unchanged decoder/corpus/oracles, nonzero execution; no command-state or native proof.

## Outcome 44

Nix Flake Check	Flake Check	2026-10-21T23:41:48.4591506Z mnesis-nextest>      Summary [ 146.559s] 1639 tests run: 1639 passed (4 slow), 5 skipped

1. Contract/counterexamples: Original whole-workspace default invariants including45command laws preserve identity, typed errors, late-commit barrier and native custody; enabled trace laws separate.
2. Actual execution/selection/services: Actual1639PASS/144binaries/5existing exclusions; Summary [ 146.559s] 1639 tests run: 1639 passed (4 slow), 5 skipped. No native Postgres credit without service.
3. Assertions/source/false positives: Exact tree, original assertions/filters/workloads unchanged; both command subprocess parents PASS, reviewed separately below. This successful workspace is not the whole failed gate.

Readiness child: (1) actual callback stop/exact wake1/Closed/normal empty join; (2) actual parent PASS checks exact-one-child/status/2s; (3) unchanged notification/join rejects missing callback/deadlock.

Timer child: (1) exact timer panic/caller Uncertain ID/zero rows/Closed/empty report; (2) actual parent PASS checks exact-one-child/status/2s; (3) native payload/name/summary rejects wrong cause, zero selection or failed/stuck process. Each child separately3reviewed, not added to outcome count.

## Outcome 45

Nix Flake Check	Flake Check	2026-10-21T23:50:28.4356986Z mnesis-postgres-integration>      Summary [   0.356s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 46

Nix Flake Check	Flake Check	2026-10-21T23:50:32.7936409Z mnesis-postgres-integration>      Summary [   0.075s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 47

Nix Flake Check	Flake Check	2026-10-21T23:50:37.2013266Z mnesis-postgres-integration>      Summary [   0.125s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 48

Nix Flake Check	Flake Check	2026-10-21T23:50:42.2183027Z mnesis-postgres-integration>      Summary [   0.754s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 49

Nix Flake Check	Flake Check	2026-10-21T23:50:48.4170880Z mnesis-postgres-integration>      Summary [   1.921s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 50

Nix Flake Check	Flake Check	2026-10-21T23:50:54.4039452Z mnesis-postgres-integration>      Summary [   1.739s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 51

Nix Flake Check	Flake Check	2026-10-21T23:50:58.7399122Z mnesis-postgres-integration>      Summary [   0.049s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 52

Nix Flake Check	Flake Check	2026-10-21T23:52:11.0136569Z mnesis-postgres-integration>      Summary [  67.416s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual264PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 53

Nix Flake Check	Flake Check	2026-10-21T23:52:13.9718719Z mnesis-postgres-integration>      Summary [   0.057s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 54

Nix Flake Check	Flake Check	2026-10-21T23:52:56.8654778Z mnesis-postgres-integration>      Summary [  40.041s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual149PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 55

Nix Flake Check	Flake Check	2026-10-21T23:53:00.1506893Z mnesis-postgres-integration>      Summary [   0.252s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 56

Nix Flake Check	Flake Check	2026-10-21T23:53:47.6352699Z mnesis-postgres-integration>      Summary [  44.354s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual168PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 57

Nix Flake Check	Flake Check	2026-10-21T23:53:50.5905258Z mnesis-postgres-integration>      Summary [   0.067s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 58

Nix Flake Check	Flake Check	2026-10-21T23:54:38.2304764Z mnesis-postgres-integration>      Summary [  44.679s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual176PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 59

Nix Flake Check	Flake Check	2026-10-21T23:54:41.6387010Z mnesis-postgres-integration>      Summary [   0.314s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 60

Nix Flake Check	Flake Check	2026-10-21T23:55:26.3009692Z mnesis-postgres-integration>      Summary [  41.419s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Complete selected native adapter feature profile; original row/transaction/recovery/checkpoint/resource assertions retained.
2. Actual execution/selection/services: Actual173PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Whole completed profile zero skips.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 61

Nix Flake Check	Flake Check	2026-10-21T23:55:29.3316210Z mnesis-postgres-integration>      Summary [   0.075s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required native smoke law; exact owner/name retained in raw preceding PASS.
2. Actual execution/selection/services: Actual1PASS, real disposable Postgres readiness/create/migration and mandatory-law guard in same job. Only selected law credited.
3. Assertions/source/false positives: Exact virtual-merge tree equals signed candidate; no native assertion/workload/deadline change. Does not prove command/backend CP6 composition, or erase later failure.

## Outcome 62

Nix Flake Check	Flake Check	2026-10-21T23:55:44.2706915Z mnesis-postgres-integration>      Summary [  11.917s] 76/174 tests run: 75 passed, 1 failed, 0 skipped

1. Contract/counterexamples: Healthy fixture PgPoolOptions.connect_with exceeds100ms before PostgresStore::from_pool or listener injection; target recovery behavior is not reached. Why initial connection was slow is not proven.
2. Actual execution/selection/services: Actual snapshot76/174cases:75PASS1FAIL0SKIP/11.917s;98notrun. Native server ready/previous cases pass; no absent-service green skip. Nested0PASS1FAIL diagnostics describe this same case.
3. Assertions/source/false positives: Unchanged lifecycle_tests.rs134, exact-source healthy setup failure. Original whole check stays failed; no retry of SUT or reduced injection/wake bound. Detailed separate failure three-review retained.

## Outcome 63

Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T23:27:57.3819158Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.42s

1. Contract/counterexamples: Features (mnesis-store) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual217PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 64

Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T23:27:59.2116236Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.73s

1. Contract/counterexamples: Features (mnesis-store) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual217PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 65

Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T23:28:04.0697006Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.51s

1. Contract/counterexamples: Features (mnesis-store) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual217PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 66

Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T23:27:25.9403133Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual15PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 67

Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T23:27:26.0575261Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual15PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 68

Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T23:27:26.4886113Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual15PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 69

Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T23:28:42.0285544Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.52s

1. Contract/counterexamples: Features (mnesis-fjall) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual131PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 70

Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T23:28:44.7014737Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.51s

1. Contract/counterexamples: Features (mnesis-fjall) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual131PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 71

Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T23:28:47.3382934Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.48s

1. Contract/counterexamples: Features (mnesis-fjall) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual131PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 72

Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T23:27:30.6063960Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Features (mnesis-inmemory) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual25PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 73

Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T23:27:30.7377621Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Features (mnesis-inmemory) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual25PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 74

Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T23:27:32.5809162Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Features (mnesis-inmemory) isolated owner unit contracts in the preceding exact default/none/all command.
2. Actual execution/selection/services: Actual30PASS, zero failed/ignored/filtered, no native database credit.
3. Assertions/source/false positives: Original source/assertions unchanged, nonzero execution; unit/compile results do not override later failed native acceptance.

## Outcome 75

Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T23:27:39.6872179Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases selected; compilation-only support.
2. Actual execution/selection/services: Actual zero-case unit harness, zero failures/ignored/filtered, no behavioral or native-service credit.
3. Assertions/source/false positives: Explicit zero selection retained, not advertised as exercised behavior; owning integration/native tests separate.

## Outcome 76

Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T23:27:39.7756210Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases selected; compilation-only support.
2. Actual execution/selection/services: Actual zero-case unit harness, zero failures/ignored/filtered, no behavioral or native-service credit.
3. Assertions/source/false positives: Explicit zero selection retained, not advertised as exercised behavior; owning integration/native tests separate.

## Outcome 77

Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T23:27:39.8623333Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases selected; compilation-only support.
2. Actual execution/selection/services: Actual zero-case unit harness, zero failures/ignored/filtered, no behavioral or native-service credit.
3. Assertions/source/false positives: Explicit zero selection retained, not advertised as exercised behavior; owning integration/native tests separate.


