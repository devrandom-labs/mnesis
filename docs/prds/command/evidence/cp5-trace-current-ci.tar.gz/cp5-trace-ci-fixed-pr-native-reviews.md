# PR418 current pr native job reviews

Signed headc13ef43fe4e60cdfacb3f747b5f00d867b412aee.20actual invocations. Disposable server reports ready and CREATE DATABASE; mandatory smoke guards precede full feature suites. The plain264-case text after package completion repeats the original65second run log and is not an additional execution. Raw cp5-trace-ci-fixed-pr-native.log preserves every result. Unchanged adapter owners; no command-level native CP6credit.

## Native invocation 1

1. Contract/counterexample: Actual required selected law: mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all
2. Actual execution/services: Starting 1 test across 1 binary (14 tests and 22 binaries skipped); Summary [   0.087s] 1 test run: 1 passed, 14 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 2

1. Contract/counterexample: Actual required selected law: mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found
2. Actual execution/services: Starting 1 test across 1 binary (15 tests and 22 binaries skipped); Summary [   0.712s] 1 test run: 1 passed, 15 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 3

1. Contract/counterexample: Actual required selected law: mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position
2. Actual execution/services: Starting 1 test across 1 binary (2 tests and 22 binaries skipped); Summary [   2.226s] 1 test run: 1 passed, 2 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 4

1. Contract/counterexample: Actual required selected law: mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen
2. Actual execution/services: Starting 1 test across 1 binary (7 tests and 22 binaries skipped); Summary [   0.652s] 1 test run: 1 passed, 7 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 5

1. Contract/counterexample: Actual required selected law: mnesis-postgres::session_tests explicit_close_and_drop_release_native_views_and_allow_reopen
2. Actual execution/services: Starting 1 test across 1 binary (10 tests and 22 binaries skipped); Summary [   2.076s] 1 test run: 1 passed, 10 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 6

1. Contract/counterexample: Actual required selected law: mnesis-postgres::security_tests verified_tls_runtime_can_open_append_read_close_and_reopen
2. Actual execution/services: Starting 1 test across 1 binary (4 tests and 22 binaries skipped); Summary [   1.698s] 1 test run: 1 passed, 4 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 7

1. Contract/counterexample: Actual required selected law: mnesis-postgres::durability_tests asynchronous_connection_settings_reject_before_runtime_open
2. Actual execution/services: Starting 1 test across 1 binary (9 tests and 22 binaries skipped); Summary [   0.045s] 1 test run: 1 passed, 9 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 8

1. Contract/counterexample: Complete native adapter all feature profile; raw log retains every owning boundary/lifecycle/atomicity/recovery assertion and mandatory-law selection.
2. Actual execution/services: Starting 264 tests across 23 binaries; Summary [  65.293s] 264 tests run: 264 passed, 0 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. Whole-profile zero skips, exact record/transaction/resource assertions retained; no reduced workload. No new processor-native, performance or publication claim.

## Native invocation 9

1. Contract/counterexample: Actual required selected law: mnesis-postgres::conformance_tests conformance_sequence::check_append_then_read_round_trips
2. Actual execution/services: Starting 1 test across 1 binary (39 tests and 22 binaries skipped); Summary [   0.057s] 1 test run: 1 passed, 39 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 10

1. Contract/counterexample: Complete native adapter default feature profile; raw log retains every owning boundary/lifecycle/atomicity/recovery assertion and mandatory-law selection.
2. Actual execution/services: Starting 149 tests across 23 binaries; Summary [  39.388s] 149 tests run: 149 passed, 0 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. Whole-profile zero skips, exact record/transaction/resource assertions retained; no reduced workload. No new processor-native, performance or publication claim.

## Native invocation 11

1. Contract/counterexample: Actual required selected law: mnesis-postgres::listing_tests binary_ids_list_once_across_pages_and_reopen
2. Actual execution/services: Starting 1 test across 1 binary (7 tests and 22 binaries skipped); Summary [   0.192s] 1 test run: 1 passed, 7 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 12

1. Contract/counterexample: Complete native adapter export feature profile; raw log retains every owning boundary/lifecycle/atomicity/recovery assertion and mandatory-law selection.
2. Actual execution/services: Starting 168 tests across 23 binaries; Summary [  44.040s] 168 tests run: 168 passed, 0 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. Whole-profile zero skips, exact record/transaction/resource assertions retained; no reduced workload. No new processor-native, performance or publication claim.

## Native invocation 13

1. Contract/counterexample: Actual required selected law: mnesis-postgres::atomic_tests conformance_atomic::check_atomic_multi_stream_commits_all
2. Actual execution/services: Starting 1 test across 1 binary (14 tests and 22 binaries skipped); Summary [   0.069s] 1 test run: 1 passed, 14 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 14

1. Contract/counterexample: Complete native adapter import feature profile; raw log retains every owning boundary/lifecycle/atomicity/recovery assertion and mandatory-law selection.
2. Actual execution/services: Starting 176 tests across 23 binaries; Summary [  45.833s] 176 tests run: 176 passed, 0 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. Whole-profile zero skips, exact record/transaction/resource assertions retained; no reduced workload. No new processor-native, performance or publication claim.

## Native invocation 15

1. Contract/counterexample: Actual required selected law: mnesis-postgres::projection_tests real_projection_reloads_the_exact_pair_and_resumes_after_its_native_position
2. Actual execution/services: Starting 1 test across 1 binary (2 tests and 22 binaries skipped); Summary [   0.636s] 1 test run: 1 passed, 2 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 16

1. Contract/counterexample: Complete native adapter projection feature profile; raw log retains every owning boundary/lifecycle/atomicity/recovery assertion and mandatory-law selection.
2. Actual execution/services: Starting 173 tests across 23 binaries; Summary [  41.136s] 173 tests run: 173 passed, 0 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. Whole-profile zero skips, exact record/transaction/resource assertions retained; no reduced workload. No new processor-native, performance or publication claim.

## Native invocation 17

1. Contract/counterexample: Actual required selected law: mnesis-postgres::snapshot_tests conformance_snapshot::check_snapshot_absent_then_commit_then_found
2. Actual execution/services: Starting 1 test across 1 binary (15 tests and 22 binaries skipped); Summary [   0.077s] 1 test run: 1 passed, 15 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 18

1. Contract/counterexample: Complete native adapter snapshot feature profile; raw log retains every owning boundary/lifecycle/atomicity/recovery assertion and mandatory-law selection.
2. Actual execution/services: Starting 174 tests across 23 binaries; Summary [  41.533s] 174 tests run: 174 passed, 0 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. Whole-profile zero skips, exact record/transaction/resource assertions retained; no reduced workload. No new processor-native, performance or publication claim.

## Native invocation 19

1. Contract/counterexample: Actual required selected law: mnesis-postgres::diagnostics_tests actual_listener_scan_and_commit_work_emit_bounded_operational_fields
2. Actual execution/services: Starting 1 test across 1 binary (22 binaries skipped); Summary [   1.061s] 1 test run: 1 passed, 0 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. One selected exact law passes; other intentionally unselected smoke cases get no credit. No new processor-native, performance or publication claim.

## Native invocation 20

1. Contract/counterexample: Complete native adapter tracing feature profile; raw log retains every owning boundary/lifecycle/atomicity/recovery assertion and mandatory-law selection.
2. Actual execution/services: Starting 150 tests across 23 binaries; Summary [  39.472s] 150 tests run: 150 passed, 0 skipped. Actual disposable Postgres readiness/create/migration plus mandatory smoke establish service availability; no no-service skip credited.
3. Assertions/source/false positives: exact-head compiled native adapter and unchanged owning tests. Whole-profile zero skips, exact record/transaction/resource assertions retained; no reduced workload. No new processor-native, performance or publication claim.


