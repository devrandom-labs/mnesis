# Tracing current push CI reviews

Run39692638604 SUCCESS at signed c13ef43fe4e60cdfacb3f747b5f00d867b412aee.79actual Rust harness outcomes, of which6have zero cases and provide compilation-only credit (73nonzero runs).3compile-fail,30unit harnesses,2command integration,3corpus replay,1workspace,40fresh native adapter runs. Plain echoed264summary excluded. Raw cp5-trace-ci-fixed-push-ci.log. Every outcome reviewed; no metrics/command-native CP6/performance/publication claim.

## Outcome 1

Compile-fail tests	Kernel compile-fail tests	2026-10-21T23:22:31.0558965Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 129.44s

1. Contract/counterexamples: Actual intended compiler diagnostics at kernel/macro/store misuse boundaries retain expected stderr and valid fixture behavior.
2. Execution/selection/services: Actual2PASS compiler-fixture harness, no ignored/filtered/failures; no database.
3. Assertions/source/false positives: Exact selected repository toolchain/head and unchanged golden diagnostics; no wrong compiler/setup failure accepted.

## Outcome 2

Compile-fail tests	Macro compile-fail tests	2026-10-21T23:23:07.5352508Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 16.97s

1. Contract/counterexamples: Actual intended compiler diagnostics at kernel/macro/store misuse boundaries retain expected stderr and valid fixture behavior.
2. Execution/selection/services: Actual1PASS compiler-fixture harness, no ignored/filtered/failures; no database.
3. Assertions/source/false positives: Exact selected repository toolchain/head and unchanged golden diagnostics; no wrong compiler/setup failure accepted.

## Outcome 3

Compile-fail tests	Store compile-fail tests	2026-10-21T23:23:36.0619333Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 20.13s

1. Contract/counterexamples: Actual intended compiler diagnostics at kernel/macro/store misuse boundaries retain expected stderr and valid fixture behavior.
2. Execution/selection/services: Actual1PASS compiler-fixture harness, no ignored/filtered/failures; no database.
3. Assertions/source/false positives: Exact selected repository toolchain/head and unchanged golden diagnostics; no wrong compiler/setup failure accepted.

## Outcome 4

Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T23:21:58.8564241Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Features (mnesis-wake) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual17PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 5

Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T23:21:59.1406064Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Features (mnesis-wake) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual17PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 6

Features (mnesis-wake)	Check isolated libraries and unit harnesses	2026-10-21T23:21:59.4230129Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Features (mnesis-wake) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual17PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 7

Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T23:22:12.9988526Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.61s

1. Contract/counterexamples: Features (mnesis-store) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual217PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 8

Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T23:22:14.8963715Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.67s

1. Contract/counterexamples: Features (mnesis-store) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual217PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 9

Features (mnesis-store)	Check isolated libraries and unit harnesses	2026-10-21T23:22:20.2565218Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.63s

1. Contract/counterexamples: Features (mnesis-store) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual217PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 10

Nix Flake Check	Flake Check	2026-10-21T23:22:09.3100764Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Existing saved-corpus decoder boundary assertions, not a new arbitrary-input campaign.
2. Execution/selection/services: Actual 2PASS native corpus harness, no failures/ignored/filtered or database.
3. Assertions/source/false positives: Unchanged corpus/decoder oracles; nonzero execution, not build-only or command-fuzz evidence.

## Outcome 11

Nix Flake Check	Flake Check	2026-10-21T23:22:10.3119424Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Existing saved-corpus decoder boundary assertions, not a new arbitrary-input campaign.
2. Execution/selection/services: Actual 1PASS native corpus harness, no failures/ignored/filtered or database.
3. Assertions/source/false positives: Unchanged corpus/decoder oracles; nonzero execution, not build-only or command-fuzz evidence.

## Outcome 12

Nix Flake Check	Flake Check	2026-10-21T23:22:11.3141410Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Existing saved-corpus decoder boundary assertions, not a new arbitrary-input campaign.
2. Execution/selection/services: Actual 1PASS native corpus harness, no failures/ignored/filtered or database.
3. Assertions/source/false positives: Unchanged corpus/decoder oracles; nonzero execution, not build-only or command-fuzz evidence.

## Outcome 13

Nix Flake Check	Flake Check	2026-10-21T23:35:12.2015452Z mnesis-nextest>      Summary [ 142.678s] 1639 tests run: 1639 passed (4 slow), 5 skipped

1. Contract/counterexamples: Original default whole-workspace contracts, including45actual command laws and unchanged original identity, late commit, typed causes and native custody. Enabled subscriber laws verified separately.
2. Execution/selection/services: Actual1639PASS/144binaries/5existing exclusions/4slow/142.678s. No real-database credit for default cases without service; native jobs are separate.
3. Assertions/source/false positives: Exact head and unchanged tests; no reduction in workloads/assertions/selectors. Both actual command subprocess parents PASS, separately reviewed below.

Readiness child: (1) actual native callback stop/exact wake1/Closed/normal empty pending join; (2) actual parent PASS checks exact-one-child/status/2s; (3) unchanged notification/join assertions reject skipped callback/deadlock.

Timer child: (1) exact native timer panic/caller Uncertain ID/zero rows/Closed/empty report; (2) actual parent PASS checks exact-one-child/status/2s; (3) unchanged exact native payload/name/summary rejects wrong cause, empty selection or process failure. Children separately3reviewed; not added to top-level count.

## Outcome 14

Nix Flake Check	Flake Check	2026-10-21T23:43:47.7831833Z mnesis-postgres-integration>      Summary [   0.095s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 15

Nix Flake Check	Flake Check	2026-10-21T23:43:52.5262703Z mnesis-postgres-integration>      Summary [   0.475s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 16

Nix Flake Check	Flake Check	2026-10-21T23:43:58.9288950Z mnesis-postgres-integration>      Summary [   2.146s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 17

Nix Flake Check	Flake Check	2026-10-21T23:44:03.3328426Z mnesis-postgres-integration>      Summary [   0.160s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 18

Nix Flake Check	Flake Check	2026-10-21T23:44:09.4215343Z mnesis-postgres-integration>      Summary [   1.820s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 19

Nix Flake Check	Flake Check	2026-10-21T23:44:15.5152891Z mnesis-postgres-integration>      Summary [   1.832s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 20

Nix Flake Check	Flake Check	2026-10-21T23:44:19.8626537Z mnesis-postgres-integration>      Summary [   0.049s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 21

Nix Flake Check	Flake Check	2026-10-21T23:45:33.5626753Z mnesis-postgres-integration>      Summary [  69.314s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 264PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 22

Nix Flake Check	Flake Check	2026-10-21T23:45:36.5278137Z mnesis-postgres-integration>      Summary [   0.062s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 23

Nix Flake Check	Flake Check	2026-10-21T23:46:20.4019721Z mnesis-postgres-integration>      Summary [  40.956s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 149PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 24

Nix Flake Check	Flake Check	2026-10-21T23:46:23.7691564Z mnesis-postgres-integration>      Summary [   0.317s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 25

Nix Flake Check	Flake Check	2026-10-21T23:47:13.0737595Z mnesis-postgres-integration>      Summary [  46.141s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 168PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 26

Nix Flake Check	Flake Check	2026-10-21T23:47:16.0611765Z mnesis-postgres-integration>      Summary [   0.074s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 27

Nix Flake Check	Flake Check	2026-10-21T23:48:04.7247067Z mnesis-postgres-integration>      Summary [  45.681s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 176PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 28

Nix Flake Check	Flake Check	2026-10-21T23:48:07.9959711Z mnesis-postgres-integration>      Summary [   0.167s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 29

Nix Flake Check	Flake Check	2026-10-21T23:48:55.1019477Z mnesis-postgres-integration>      Summary [  43.889s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 173PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 30

Nix Flake Check	Flake Check	2026-10-21T23:48:58.1085755Z mnesis-postgres-integration>      Summary [   0.081s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 31

Nix Flake Check	Flake Check	2026-10-21T23:49:44.1237471Z mnesis-postgres-integration>      Summary [  42.981s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 174PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 32

Nix Flake Check	Flake Check	2026-10-21T23:49:48.1746785Z mnesis-postgres-integration>      Summary [   1.070s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 33

Nix Flake Check	Flake Check	2026-10-21T23:50:33.0094310Z mnesis-postgres-integration>      Summary [  41.714s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 150PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 34

Postgres Integration	Postgres integration	2026-10-21T23:26:36.6570619Z mnesis-postgres-integration>      Summary [   1.184s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 35

Postgres Integration	Postgres integration	2026-10-21T23:26:41.3718837Z mnesis-postgres-integration>      Summary [   0.751s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 36

Postgres Integration	Postgres integration	2026-10-21T23:26:46.6926354Z mnesis-postgres-integration>      Summary [   1.127s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 37

Postgres Integration	Postgres integration	2026-10-21T23:26:51.4352106Z mnesis-postgres-integration>      Summary [   1.042s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 38

Postgres Integration	Postgres integration	2026-10-21T23:26:56.4868621Z mnesis-postgres-integration>      Summary [   0.841s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 39

Postgres Integration	Postgres integration	2026-10-21T23:27:04.2059361Z mnesis-postgres-integration>      Summary [   3.530s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 40

Postgres Integration	Postgres integration	2026-10-21T23:27:07.6201158Z mnesis-postgres-integration>      Summary [   0.037s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 41

Postgres Integration	Postgres integration	2026-10-21T23:28:16.8858165Z mnesis-postgres-integration>      Summary [  65.648s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 264PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 42

Postgres Integration	Postgres integration	2026-10-21T23:28:19.2288504Z mnesis-postgres-integration>      Summary [   0.045s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 43

Postgres Integration	Postgres integration	2026-10-21T23:29:06.2274859Z mnesis-postgres-integration>      Summary [  44.736s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 149PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 44

Postgres Integration	Postgres integration	2026-10-21T23:29:08.9211703Z mnesis-postgres-integration>      Summary [   0.290s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 45

Postgres Integration	Postgres integration	2026-10-21T23:29:56.8225917Z mnesis-postgres-integration>      Summary [  45.412s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 168PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 46

Postgres Integration	Postgres integration	2026-10-21T23:29:59.1856107Z mnesis-postgres-integration>      Summary [   0.056s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 47

Postgres Integration	Postgres integration	2026-10-21T23:30:44.7544982Z mnesis-postgres-integration>      Summary [  43.210s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 176PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 48

Postgres Integration	Postgres integration	2026-10-21T23:30:47.4190757Z mnesis-postgres-integration>      Summary [   0.218s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 49

Postgres Integration	Postgres integration	2026-10-21T23:31:29.9001961Z mnesis-postgres-integration>      Summary [  39.944s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 173PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 50

Postgres Integration	Postgres integration	2026-10-21T23:31:32.2919186Z mnesis-postgres-integration>      Summary [   0.058s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 51

Postgres Integration	Postgres integration	2026-10-21T23:32:12.5460858Z mnesis-postgres-integration>      Summary [  37.866s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 174PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 52

Postgres Integration	Postgres integration	2026-10-21T23:32:15.9580010Z mnesis-postgres-integration>      Summary [   1.053s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Actual required native smoke law; the raw preceding PASS identifies its exact owner/name.
2. Execution/selection/services: Actual native 1PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Other smoke-filtered cases get no credit.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 53

Postgres Integration	Postgres integration	2026-10-21T23:32:57.4335854Z mnesis-postgres-integration>      Summary [  39.054s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Complete native adapter feature profile; every original row/transaction/recovery/checkpoint/resource law retains its assertions.
2. Execution/selection/services: Actual native 150PASS outcome; disposable server readiness/create/migrations and mandatory-law selection are in this same job log. Full profile zero skips.
3. Assertions/source/false positives: Exact signed source; original native assertions/limits unchanged and service-backed failures cannot be substituted by an unavailable-service green skip. No processor/backend composition inferred.

## Outcome 54

Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T23:22:00.8923794Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual15PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 55

Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T23:22:01.0375760Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual15PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 56

Features (mnesis)	Check isolated libraries and unit harnesses	2026-10-21T23:22:01.5744636Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual15PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 57

Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T23:22:20.0609347Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.46s

1. Contract/counterexamples: Features (mnesis-fjall) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual131PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 58

Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T23:22:22.6838475Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.47s

1. Contract/counterexamples: Features (mnesis-fjall) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual131PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 59

Features (mnesis-fjall)	Check isolated libraries and unit harnesses	2026-10-21T23:22:25.3305266Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.50s

1. Contract/counterexamples: Features (mnesis-fjall) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual131PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 60

Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T23:21:47.1167665Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Features (mnesis-inmemory) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual25PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 61

Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T23:21:47.2401918Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Features (mnesis-inmemory) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual25PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 62

Features (mnesis-inmemory)	Check isolated libraries and unit harnesses	2026-10-21T23:21:49.0652599Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Features (mnesis-inmemory) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual30PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 63

Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T23:21:39.6373309Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this isolated unit harness; this supports compilation only.
2. Execution/selection/services: Actual zero-case native harness, zero failures/ignored/filtered, no behavioral or service credit.
3. Assertions/source/false positives: Explicitly retained as zero selection rather than advertised as tested behavior; owning integration/native conformance are separate.

## Outcome 64

Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T23:21:39.7234062Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this isolated unit harness; this supports compilation only.
2. Execution/selection/services: Actual zero-case native harness, zero failures/ignored/filtered, no behavioral or service credit.
3. Assertions/source/false positives: Explicitly retained as zero selection rather than advertised as tested behavior; owning integration/native conformance are separate.

## Outcome 65

Features (mnesis-store-testing)	Check isolated libraries and unit harnesses	2026-10-21T23:21:39.8074829Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this isolated unit harness; this supports compilation only.
2. Execution/selection/services: Actual zero-case native harness, zero failures/ignored/filtered, no behavioral or service credit.
3. Assertions/source/false positives: Explicitly retained as zero selection rather than advertised as tested behavior; owning integration/native conformance are separate.

## Outcome 66

Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T23:22:31.4182842Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-postgres) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual11PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 67

Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T23:22:31.5681231Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-postgres) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual11PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 68

Features (mnesis-postgres)	Check isolated libraries and unit harnesses	2026-10-21T23:22:34.1426184Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-postgres) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual11PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 69

Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T23:21:49.4305718Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this isolated unit harness; this supports compilation only.
2. Execution/selection/services: Actual zero-case native harness, zero failures/ignored/filtered, no behavioral or service credit.
3. Assertions/source/false positives: Explicitly retained as zero selection rather than advertised as tested behavior; owning integration/native conformance are separate.

## Outcome 70

Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T23:21:49.5586631Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this isolated unit harness; this supports compilation only.
2. Execution/selection/services: Actual zero-case native harness, zero failures/ignored/filtered, no behavioral or service credit.
3. Assertions/source/false positives: Explicitly retained as zero selection rather than advertised as tested behavior; owning integration/native conformance are separate.

## Outcome 71

Features (mnesis-wake-nostd)	Check isolated libraries and unit harnesses	2026-10-21T23:21:49.6870615Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No runtime cases in this isolated unit harness; this supports compilation only.
2. Execution/selection/services: Actual zero-case native harness, zero failures/ignored/filtered, no behavioral or service credit.
3. Assertions/source/false positives: Explicitly retained as zero selection rather than advertised as tested behavior; owning integration/native conformance are separate.

## Outcome 72

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T23:22:05.1720898Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Features (mnesis-command) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual9PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 73

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T23:22:06.1229564Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Features (mnesis-command) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual9PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 74

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T23:22:07.1024313Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Features (mnesis-command) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual9PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 75

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T23:22:17.0275462Z      Summary [   3.625s] 45 tests run: 45 passed, 1 skipped

1. Contract/counterexamples: All45original command laws with tracing disabled; no enabled-span proof inferred.
2. Execution/selection/services: Actual45PASS full integration through required existing Nix feature job,1original ignored measurement, locked/fail-on-no-tests. In-memory controlled backend only.
3. Assertions/source/false positives: Exact mode/source; original typed receipt/data/identity and native lifetime assertions unchanged. Both bounded subprocess parents actually PASS, separately reviewed below.

Readiness child: (1) actual native callback stop/exact wake1/Closed/normal empty pending join; (2) actual parent PASS checks exact-one-child/status/2s; (3) unchanged notification/join assertions reject skipped callback/deadlock.

Timer child: (1) exact native timer panic/caller Uncertain ID/zero rows/Closed/empty report; (2) actual parent PASS checks exact-one-child/status/2s; (3) unchanged exact native payload/name/summary rejects wrong cause, empty selection or process failure. Children separately3reviewed; not added to top-level count.

## Outcome 76

Features (mnesis-command)	Check isolated libraries and unit harnesses	2026-10-21T23:22:29.0556123Z      Summary [   3.974s] 49 tests run: 49 passed, 1 skipped

1. Contract/counterexamples: All45original command laws plus4independent subscriber context/cleanup/outcome/data laws.
2. Execution/selection/services: Actual49PASS full integration through required existing Nix feature job,1original ignored measurement, locked/fail-on-no-tests. In-memory controlled backend only.
3. Assertions/source/false positives: Exact mode/source; original typed receipt/data/identity and native lifetime assertions unchanged. Both bounded subprocess parents actually PASS, separately reviewed below.

Readiness child: (1) actual native callback stop/exact wake1/Closed/normal empty pending join; (2) actual parent PASS checks exact-one-child/status/2s; (3) unchanged notification/join assertions reject skipped callback/deadlock.

Timer child: (1) exact native timer panic/caller Uncertain ID/zero rows/Closed/empty report; (2) actual parent PASS checks exact-one-child/status/2s; (3) unchanged exact native payload/name/summary rejects wrong cause, empty selection or process failure. Children separately3reviewed; not added to top-level count.

## Outcome 77

Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T23:21:42.9520037Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-macros) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual1PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 78

Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T23:21:43.0782675Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-macros) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual1PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.

## Outcome 79

Features (mnesis-macros)	Check isolated libraries and unit harnesses	2026-10-21T23:21:43.2064936Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Features (mnesis-macros) owning isolated unit contracts under the default/none/all mode reported in preceding command.
2. Execution/selection/services: Actual1PASS native unit harness, zero failures/ignored/filtered; no native database claim.
3. Assertions/source/false positives: Original owning assertions/source unchanged; nonzero selection. Feature compile/unit success does not replace command integration or native composition.


