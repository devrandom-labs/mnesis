# Tracing PR418 unchanged failed-job rerun reviews

Run39692645748 attempt2, only Nixjob119556953600 was rerun. Exact virtual779e5877f0acf3d40b31d7c7a97befeb5c1a5cd1/headc13ef43f/treef2036076 unchanged.24new actual invocations:3corpus,1workspace,20native adapter;2command bounded children. GitHub combined-attempt log also repeats other jobs as UNKNOWN STEP with old timestamps; they are not reruns or new credit. Native service ready/create/migrate confirmed. All24pass. Original attempt1 healthy fixture setup timeout remains preserved; this unchanged success does not establish a root-cause repair.

## Invocation 1

Nix Flake Check	Flake Check	2026-10-22T00:04:05.5125957Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: existing saved decoder corpus boundaries/oracles, not arbitrary-input command fuzz.
2. Actual execution: distinct2PASS/0FAIL/ignored/filtered/1.00s native harness; no database required.
3. Assertions/source: exact unchanged corpus/decoder and nonzero cases, not build-only/command/durability proof.

## Invocation 2

Nix Flake Check	Flake Check	2026-10-22T00:04:06.5147971Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: existing saved decoder corpus boundaries/oracles, not arbitrary-input command fuzz.
2. Actual execution: distinct1PASS/0FAIL/ignored/filtered/1.00s native harness; no database required.
3. Assertions/source: exact unchanged corpus/decoder and nonzero cases, not build-only/command/durability proof.

## Invocation 3

Nix Flake Check	Flake Check	2026-10-22T00:04:07.5168899Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: existing saved decoder corpus boundaries/oracles, not arbitrary-input command fuzz.
2. Actual execution: distinct1PASS/0FAIL/ignored/filtered/1.00s native harness; no database required.
3. Assertions/source: exact unchanged corpus/decoder and nonzero cases, not build-only/command/durability proof.

## Invocation 4

Nix Flake Check	Flake Check	2026-10-22T00:16:55.5101449Z mnesis-nextest>      Summary [ 140.644s] 1639 tests run: 1639 passed (4 slow), 5 skipped

1. Contract/counterexamples: default original workspace includes45command identity/typed retry/late-commit/native custody/resource laws. Enabled tracing laws have separate actual49-case evidence.
2. Actual execution:1639PASS/144binaries/5original exclusions/4slow/140.644s; actual default gate, no absent-service native Postgres credit.
3. Assertions/source: original tests/workload/filter/deadlines unchanged, exact virtual tree; no new metrics/command-native/performance proof. Both command child parents pass, separately reviewed below.

Readiness child: (1) actual callback stop/exact wake1/Closed/native normal empty join; (2) actual PASS after exact-one-child/status/2s; (3) unchanged notification/join rejects skipped wake/deadlock. Timer child: (1) exact native timer panic/Uncertain ID/zero rows/Closed/empty report; (2) actual PASS exact-one-child/status/2s; (3) unchanged native payload/name/summary rejects wrong cause, zero selection or process failure. Each separately three-reviewed, not counted as another1639-suite.

## Invocation 5

Nix Flake Check	Flake Check	2026-10-22T00:25:05.9577452Z mnesis-postgres-integration>      Summary [   0.652s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 6

Nix Flake Check	Flake Check	2026-10-22T00:25:11.8333043Z mnesis-postgres-integration>      Summary [   0.835s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 7

Nix Flake Check	Flake Check	2026-10-22T00:25:16.8597143Z mnesis-postgres-integration>      Summary [   1.059s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 8

Nix Flake Check	Flake Check	2026-10-22T00:25:22.5714184Z mnesis-postgres-integration>      Summary [   1.010s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 9

Nix Flake Check	Flake Check	2026-10-22T00:25:27.2902272Z mnesis-postgres-integration>      Summary [   0.853s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 10

Nix Flake Check	Flake Check	2026-10-22T00:25:36.3798111Z mnesis-postgres-integration>      Summary [   4.143s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 11

Nix Flake Check	Flake Check	2026-10-22T00:25:40.0447814Z mnesis-postgres-integration>      Summary [   0.045s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 12

Nix Flake Check	Flake Check	2026-10-22T00:26:53.8582882Z mnesis-postgres-integration>      Summary [  69.315s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Complete native all profile retains original atomicity/rows/recovery/checkpoint/resource assertions.
2. Actual execution/services: actual264PASS; disposable server readiness/create/migration and mandatory-law selection proved. Whole selected suite zero skips.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 13

Nix Flake Check	Flake Check	2026-10-22T00:26:56.3247944Z mnesis-postgres-integration>      Summary [   0.051s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 14

Nix Flake Check	Flake Check	2026-10-22T00:27:38.6248225Z mnesis-postgres-integration>      Summary [  39.928s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Complete native default profile retains original atomicity/rows/recovery/checkpoint/resource assertions.
2. Actual execution/services: actual149PASS; disposable server readiness/create/migration and mandatory-law selection proved. Whole selected suite zero skips.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 15

Nix Flake Check	Flake Check	2026-10-22T00:27:41.4778673Z mnesis-postgres-integration>      Summary [   0.291s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 16

Nix Flake Check	Flake Check	2026-10-22T00:28:30.0664952Z mnesis-postgres-integration>      Summary [  45.961s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Complete native export profile retains original atomicity/rows/recovery/checkpoint/resource assertions.
2. Actual execution/services: actual168PASS; disposable server readiness/create/migration and mandatory-law selection proved. Whole selected suite zero skips.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 17

Nix Flake Check	Flake Check	2026-10-22T00:28:32.5778482Z mnesis-postgres-integration>      Summary [   0.065s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 18

Nix Flake Check	Flake Check	2026-10-22T00:29:17.3115124Z mnesis-postgres-integration>      Summary [  42.251s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Complete native import profile retains original atomicity/rows/recovery/checkpoint/resource assertions.
2. Actual execution/services: actual176PASS; disposable server readiness/create/migration and mandatory-law selection proved. Whole selected suite zero skips.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 19

Nix Flake Check	Flake Check	2026-10-22T00:29:20.3321452Z mnesis-postgres-integration>      Summary [   0.417s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 20

Nix Flake Check	Flake Check	2026-10-22T00:30:05.6325487Z mnesis-postgres-integration>      Summary [  42.636s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Complete native projection profile retains original atomicity/rows/recovery/checkpoint/resource assertions.
2. Actual execution/services: actual173PASS; disposable server readiness/create/migration and mandatory-law selection proved. Whole selected suite zero skips.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 21

Nix Flake Check	Flake Check	2026-10-22T00:30:08.1936657Z mnesis-postgres-integration>      Summary [   0.073s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 22

Nix Flake Check	Flake Check	2026-10-22T00:30:48.5717604Z mnesis-postgres-integration>      Summary [  37.855s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Complete native snapshot profile retains original atomicity/rows/recovery/checkpoint/resource assertions.
2. Actual execution/services: actual174PASS; disposable server readiness/create/migration and mandatory-law selection proved. Whole selected suite zero skips.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 23

Nix Flake Check	Flake Check	2026-10-22T00:30:52.1096583Z mnesis-postgres-integration>      Summary [   1.061s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Actual required exact-name native smoke law (raw preceding PASS retained), with its supported feature.
2. Actual execution/services: actual1PASS; disposable server readiness/create/migration and mandatory-law selection proved. Other filtered smoke cases receive no credit.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

## Invocation 24

Nix Flake Check	Flake Check	2026-10-22T00:31:33.5418523Z mnesis-postgres-integration>      Summary [  38.891s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Complete native tracing profile retains original atomicity/rows/recovery/checkpoint/resource assertions.
2. Actual execution/services: actual150PASS; disposable server readiness/create/migration and mandatory-law selection proved. Whole selected suite zero skips.
3. Assertions/source: unchanged signed/virtual source, selectors/workloads/timeouts and native SQL oracles. No test skipped to avoid old failure; no command adapter CP6 composition inferred.

The previously failing law actually PASSES in all required full profiles including snapshot174; its original100ms healthy setup/injected fault deadlines remain intact. Source cause of original setup delay remains unproven.

Nix Flake Check	Flake Check	2026-10-22T00:14:35.5611141Z mnesis-nextest>         PASS [   0.015s] ( 237/1639) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
Nix Flake Check	Flake Check	2026-10-22T00:14:35.5920700Z mnesis-nextest>         PASS [   0.016s] ( 250/1639) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
Nix Flake Check	Flake Check	2026-10-22T00:16:24.2666245Z mnesis-nextest>         PASS [   0.004s] ( 782/1639) mnesis-postgres::lifecycle_tests initial_listener_acquisition_failure_recovers_after_service_returns
Nix Flake Check	Flake Check	2026-10-22T00:26:08.9818075Z mnesis-postgres-integration>         PASS [   1.161s] (121/264) mnesis-postgres::lifecycle_tests initial_listener_acquisition_failure_recovers_after_service_returns
Nix Flake Check	Flake Check	2026-10-22T00:27:10.1790200Z mnesis-postgres-integration>         PASS [   1.163s] ( 75/149) mnesis-postgres::lifecycle_tests initial_listener_acquisition_failure_recovers_after_service_returns
Nix Flake Check	Flake Check	2026-10-22T00:27:59.1024152Z mnesis-postgres-integration>         PASS [   1.161s] ( 75/168) mnesis-postgres::lifecycle_tests initial_listener_acquisition_failure_recovers_after_service_returns
Nix Flake Check	Flake Check	2026-10-22T00:28:48.3682377Z mnesis-postgres-integration>         PASS [   1.192s] ( 91/176) mnesis-postgres::lifecycle_tests initial_listener_acquisition_failure_recovers_after_service_returns
Nix Flake Check	Flake Check	2026-10-22T00:29:39.5641417Z mnesis-postgres-integration>         PASS [   1.163s] ( 89/173) mnesis-postgres::lifecycle_tests initial_listener_acquisition_failure_recovers_after_service_returns
Nix Flake Check	Flake Check	2026-10-22T00:30:22.5503969Z mnesis-postgres-integration>         PASS [   1.185s] ( 76/174) mnesis-postgres::lifecycle_tests initial_listener_acquisition_failure_recovers_after_service_returns
Nix Flake Check	Flake Check	2026-10-22T00:31:09.3797524Z mnesis-postgres-integration>         PASS [   1.163s] ( 76/150) mnesis-postgres::lifecycle_tests initial_listener_acquisition_failure_recovers_after_service_returns


The same-name lifecycle PASS also appears in the ordinary no-service workspace;
that one does not receive native credit. Only the seven actual native derivation-
prefixed profile executions establish the service-backed pass described above.
