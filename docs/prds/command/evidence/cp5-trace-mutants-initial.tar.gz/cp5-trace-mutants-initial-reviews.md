# Trace PR418 initial mutation run39685062277 — all outcomes reviewed

Exact head dc9882e82a3b6377d4daf636ed6a20d72e7174f4. Baseline49PASS;69mutants:23caught/5missed/41compiler-only/0timeout. Gate FAILED and remains failed; no equivalence waiver or exclusion. Five missed functions are the tracing-disabled constructor/admission duplicates, compiled out by --all-features. Their49PASS runs exercise the enabled implementation only; they do not prove the mutant was observed. No native command/Postgres credit. Raw artifact12386397339 retained. Every actual invocation and successful bounded child reviewed below; compilation-only outcomes receive zero test credit.

Outcome 0: Baseline — Success
PASS [   0.018s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
     Summary [   3.122s] 49 tests run: 49 passed, 1 skipped
1. Contract/counterexample: Actual49-law baseline retains identity/recovery/format/lifecycle and four recording-subscriber laws.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Nonzero actual baseline and unchanged original assertions/workloads verified.

Child readiness_release_allows_a_reentrant_stop_callback, outcome0:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome0:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 1: crates/command/src/engine.rs:74:9: replace Engine<S, A, C, I, N>::load -> Result<Root<A, C, I, N>, Error<A::Error, I, S::Error>> with Ok(Default::default()) — Unviable
error[E0277]: the trait bound `AggregateRoot<Adapted<A, C, I, N>>: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 2: crates/command/src/engine.rs:88:9: replace Engine<S, A, C, I, N>::settle -> Result<(), Error<A::Error, I, S::Error>> with Ok(()) — CaughtMutant
FAIL [   0.080s] (11/49) mnesis-command::properties generated_histories_preserve_identity_and_reconstruction
     Summary [   0.124s] 11/49 tests run: 10 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.080s] (11/49) mnesis-command::properties generated_histories_preserve_identity_and_reconstruction.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 3: crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::new()) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 4: crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::from_iter([Default::default()])) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 5: crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::new(Default::default())) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 6: crates/command/src/engine.rs:179:9: replace Engine<S, A, C, I, N>::submit -> Result<Receipt<I>, Error<A::Error, I, S::Error>> with Ok(Receipt::from(Default::default())) — Unviable
error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 7: crates/command/src/host.rs:126:9: replace Message<A, C, I, E>::operation -> &'static str with "" — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.211s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome7:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome7:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 8: crates/command/src/host.rs:126:9: replace Message<A, C, I, E>::operation -> &'static str with "xyzzy" — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.189s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome8:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome8:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 9: crates/command/src/host.rs:168:9: replace Call<A, C, I, E>::admission -> Trace with Default::default() — MissedMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
     Summary [   3.164s] 49 tests run: 49 passed, 1 skipped
1. Contract/counterexample: Mutation is in an opposite cfg-disabled duplicate; the selected all-feature source omits that body, so success cannot falsify its behavior. Keep this survivor visible and simplify redundant implementations rather than waive the gate.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. All-feature omission is a source-selection limitation, not a green mutation result; no fabricated test assertion can observe an uncompiled function.

Child readiness_release_allows_a_reentrant_stop_callback, outcome9:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome9:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 10: crates/command/src/host.rs:172:9: replace Call<A, C, I, E>::admission -> Trace with Default::default() — Unviable
error[E0277]: the trait bound `Trace: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 11: crates/command/src/host.rs:176:9: replace Call<A, C, I, E>::finish with () — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans
     Summary [   3.122s] 46/49 tests run: 45 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome11:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome11:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 12: crates/command/src/host.rs:183:9: replace Call<A, C, I, E>::reject with () — CaughtMutant
FAIL [   0.005s] (32/49) mnesis-command::recovery overload_and_shutdown_reject_queued_calls_before_acceptance
     Summary [   2.917s] 32/49 tests run: 31 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (32/49) mnesis-command::recovery overload_and_shutdown_reject_queued_calls_before_acceptance.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 13: crates/command/src/host.rs:192:5: replace respond with () — CaughtMutant
FAIL [   0.004s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy
     Summary [   0.040s] 10/49 tests run: 9 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.004s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 14: crates/command/src/host.rs:211:9: replace Call<A, C, I, E>::execute with () — CaughtMutant
FAIL [   0.004s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy
     Summary [   0.040s] 10/49 tests run: 9 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.004s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 15: crates/command/src/host.rs:253:9: replace <impl Drop for Inbox<A, C, I, E>>::drop with () — CaughtMutant
FAIL [   0.005s] (32/49) mnesis-command::recovery overload_and_shutdown_reject_queued_calls_before_acceptance
     Summary [   3.176s] 32/49 tests run: 31 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (32/49) mnesis-command::recovery overload_and_shutdown_reject_queued_calls_before_acceptance.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 16: crates/command/src/host.rs:350:9: replace CommandProcessor<A, C, I, N, E>::launch -> Started<S, A, C, I, N> with Default::default() — Unviable
error[E0277]: the trait bound `Result<(CommandProcessor<A, C, I, N, E>, Worker<C, I>), _>: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 17: crates/command/src/host.rs:413:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(None) — CaughtMutant
FAIL [   0.095s] (11/49) mnesis-command::properties generated_histories_preserve_identity_and_reconstruction
     Summary [   0.139s] 11/49 tests run: 10 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.095s] (11/49) mnesis-command::properties generated_histories_preserve_identity_and_reconstruction.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 18: crates/command/src/host.rs:413:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::new())) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 19: crates/command/src/host.rs:413:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::from_iter([Default::default()]))) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 20: crates/command/src/host.rs:413:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::new(Default::default()))) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 21: crates/command/src/host.rs:413:9: replace CommandProcessor<A, C, I, N, E>::retry -> Result<Option<Receipt<I>>, Error<A::Error, I, E>> with Ok(Some(Receipt::from(Default::default()))) — Unviable
error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 22: crates/command/src/host.rs:435:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::new()) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 23: crates/command/src/host.rs:435:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::from_iter([Default::default()])) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 24: crates/command/src/host.rs:435:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::new(Default::default())) — Unviable
error[E0599]: no associated function or constant named `new` found for struct `Receipt<I>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 25: crates/command/src/host.rs:435:9: replace CommandProcessor<A, C, I, N, E>::submit -> Result<Receipt<I>, Error<A::Error, I, E>> with Ok(Receipt::from(Default::default())) — Unviable
error[E0277]: the trait bound `Receipt<I>: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 26: crates/command/src/host.rs:453:9: replace CommandProcessor<A, C, I, N, E>::read -> Result<(Option<Version>, A::State), Error<A::Error, I, E>> with Ok((None, Default::default())) — Unviable
error[E0277]: the trait bound `<A as Aggregate>::State: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 27: crates/command/src/host.rs:453:9: replace CommandProcessor<A, C, I, N, E>::read -> Result<(Option<Version>, A::State), Error<A::Error, I, E>> with Ok((Some(Default::default()), Default::default())) — Unviable
error[E0277]: the trait bound `Version: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 28: crates/command/src/host.rs:464:9: replace CommandProcessor<A, C, I, N, E>::original -> Result<Option<Request<C, I>>, Error<A::Error, I, E>> with Ok(None) — CaughtMutant
FAIL [   0.005s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy
     Summary [   0.041s] 10/49 tests run: 9 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 29: crates/command/src/host.rs:464:9: replace CommandProcessor<A, C, I, N, E>::original -> Result<Option<Request<C, I>>, Error<A::Error, I, E>> with Ok(Some(Default::default())) — Unviable
error[E0277]: the trait bound `model::Request<C, I>: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 30: crates/command/src/host.rs:475:9: replace CommandProcessor<A, C, I, N, E>::send -> Result<(), Error<A::Error, I, E>> with Ok(()) — CaughtMutant
FAIL [   0.004s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy
     Summary [   0.041s] 10/49 tests run: 9 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.004s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 31: crates/command/src/host.rs:525:9: replace <impl Service<Request<C, I>> for CommandProcessor<A, C, I, N, E>>::call -> Self::Future with Default::default() — Unviable
error[E0277]: the trait bound `dyn Future<Output = Result<Receipt<I>, _>> + Send: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 32: crates/command/src/host.rs:574:5: replace run with () — CaughtMutant
FAIL [   0.004s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy
     Summary [   0.040s] 10/49 tests run: 9 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.004s] (10/49) mnesis-command::adaptation unrelated_aggregates_use_the_same_controller_without_domain_policy.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 33: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(None) — CaughtMutant
FAIL [   0.007s] ( 4/49) mnesis-command model::tests::full_receipt_history_preserves_old_ids_including_noops
     Summary [   0.019s] 4/49 tests run: 3 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.007s] ( 4/49) mnesis-command model::tests::full_receipt_history_preserves_old_ids_including_noops.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 34: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new())) — Unviable
error[E0061]: this function takes 1 argument but 0 arguments were supplied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 35: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::new()]))) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 36: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::new()))) — Unviable
error[E0599]: no associated function or constant named `new` found for type `_` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 37: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::new()))) — Unviable
error[E0599]: no associated function or constant named `new` found for type `_` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 38: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::from_iter([Default::default()])]))) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 39: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::from_iter([Default::default()])))) — Unviable
error[E0277]: a value of type `model::Record<C, I, <<A as Aggregate>::State as AggregateState>::Event>` cannot be built from an iterator over elements of type `_`
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 40: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::from_iter([Default::default()])))) — Unviable
error[E0283]: type annotations needed
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 41: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::new(Default::default())]))) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 42: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::new(Default::default())))) — Unviable
error[E0599]: no associated function or constant named `new` found for type `_` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 43: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::new(Default::default())))) — Unviable
error[E0599]: no associated function or constant named `new` found for type `_` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 44: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from_iter([EventOf::from(Default::default())]))) — Unviable
error[E0599]: no associated function or constant named `from_iter` found for struct `Events<E, N>` in the current scope
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 45: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::new(EventOf::from(Default::default())))) — Unviable
error[E0277]: the trait bound `model::Record<C, I, <<A as Aggregate>::State as AggregateState>::Event>: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 46: crates/command/src/model.rs:422:9: replace <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle -> Result<Option<Events<EventOf<Self>>>, Self::Error> with Ok(Some(Events::from(EventOf::from(Default::default())))) — Unviable
error[E0283]: type annotations needed
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 47: crates/command/src/model.rs:425:37: replace >= with < in <impl Handle<Decision<C, I>> for Adapted<A, C, I, N>>::handle — CaughtMutant
FAIL [   0.007s] ( 4/49) mnesis-command model::tests::full_receipt_history_preserves_old_ids_including_noops
     Summary [   0.019s] 4/49 tests run: 3 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.007s] ( 4/49) mnesis-command model::tests::full_receipt_history_preserves_old_ids_including_noops.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Outcome 48: crates/command/src/trace.rs:26:9: replace Trace::request -> Self with Default::default() — MissedMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
     Summary [   3.178s] 49 tests run: 49 passed, 1 skipped
1. Contract/counterexample: Mutation is in an opposite cfg-disabled duplicate; the selected all-feature source omits that body, so success cannot falsify its behavior. Keep this survivor visible and simplify redundant implementations rather than waive the gate.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. All-feature omission is a source-selection limitation, not a green mutation result; no fabricated test assertion can observe an uncompiled function.

Child readiness_release_allows_a_reentrant_stop_callback, outcome48:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome48:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 49: crates/command/src/trace.rs:29:9: replace Trace::worker -> Self with Default::default() — MissedMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
     Summary [   3.110s] 49 tests run: 49 passed, 1 skipped
1. Contract/counterexample: Mutation is in an opposite cfg-disabled duplicate; the selected all-feature source omits that body, so success cannot falsify its behavior. Keep this survivor visible and simplify redundant implementations rather than waive the gate.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. All-feature omission is a source-selection limitation, not a green mutation result; no fabricated test assertion can observe an uncompiled function.

Child readiness_release_allows_a_reentrant_stop_callback, outcome49:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome49:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 50: crates/command/src/trace.rs:32:9: replace Trace::stage -> Self with Default::default() — MissedMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
     Summary [   3.164s] 49 tests run: 49 passed, 1 skipped
1. Contract/counterexample: Mutation is in an opposite cfg-disabled duplicate; the selected all-feature source omits that body, so success cannot falsify its behavior. Keep this survivor visible and simplify redundant implementations rather than waive the gate.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. All-feature omission is a source-selection limitation, not a green mutation result; no fabricated test assertion can observe an uncompiled function.

Child readiness_release_allows_a_reentrant_stop_callback, outcome50:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome50:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 51: crates/command/src/trace.rs:35:9: replace Trace::scope -> Scope with Default::default() — MissedMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
     Summary [   3.250s] 49 tests run: 49 passed, 1 skipped
1. Contract/counterexample: Mutation is in an opposite cfg-disabled duplicate; the selected all-feature source omits that body, so success cannot falsify its behavior. Keep this survivor visible and simplify redundant implementations rather than waive the gate.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. All-feature omission is a source-selection limitation, not a green mutation result; no fabricated test assertion can observe an uncompiled function.

Child readiness_release_allows_a_reentrant_stop_callback, outcome51:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome51:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 52: crates/command/src/trace.rs:42:9: replace Trace::request -> Self with Default::default() — Unviable
error[E0277]: the trait bound `Trace: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 53: crates/command/src/trace.rs:55:9: replace Trace::worker -> Self with Default::default() — Unviable
error[E0277]: the trait bound `Trace: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 54: crates/command/src/trace.rs:64:9: replace Trace::stage -> Self with Default::default() — Unviable
error[E0277]: the trait bound `Trace: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 55: crates/command/src/trace.rs:77:9: replace Trace::scope -> Scope with Default::default() — Unviable
error[E0277]: the trait bound `trace::Scope: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 56: crates/command/src/trace.rs:82:9: replace Trace::child -> Self with Default::default() — Unviable
error[E0277]: the trait bound `Trace: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 57: crates/command/src/trace.rs:85:9: replace Trace::finish with () — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans
     Summary [   3.175s] 46/49 tests run: 45 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome57:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome57:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 58: crates/command/src/trace.rs:95:9: replace <impl Drop for Trace>::drop with () — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans
     Summary [   3.040s] 46/49 tests run: 45 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome58:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome58:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 59: crates/command/src/trace.rs:101:9: replace Scope::sync -> T with Default::default() — Unviable
error[E0277]: the trait bound `T: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 60: crates/command/src/trace.rs:112:9: replace Scope::run -> F::Output with Default::default() — Unviable
error[E0277]: the trait bound `<F as Future>::Output: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 61: crates/command/src/trace.rs:128:9: replace <impl Drop for Scope>::drop with () — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans
     Summary [   3.105s] 46/49 tests run: 45 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (46/49) mnesis-command::trace abort_closes_another_subscribers_active_and_queued_spans.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome61:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome61:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 62: crates/command/src/trace.rs:139:5: replace step -> Result<T, Error<D, I, E>> with Ok(Default::default()) — Unviable
error[E0277]: the trait bound `T: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 63: crates/command/src/trace.rs:150:5: replace sync -> Result<T, E> with Ok(Default::default()) — Unviable
error[E0277]: the trait bound `T: Default` is not satisfied
1. Contract/counterexample: Compiler rejects the generated replacement at the recorded missing trait/function/type boundary; no runtime invariant established.
2. Execution/selection/services: Only Build ran and failed; no test phase ran. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. First compiler diagnostic inspected; cannot count compile failure as a caught behavioral mutant.

Outcome 64: crates/command/src/trace.rs:158:5: replace invalid_request with () — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.004s] (48/49) mnesis-command::trace invalid_requests_are_observed_without_payloads_or_spending_admission
     Summary [   3.057s] 48/49 tests run: 47 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.004s] (48/49) mnesis-command::trace invalid_requests_are_observed_without_payloads_or_spending_admission.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome64:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome64:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 65: crates/command/src/trace.rs:164:5: replace outcome -> &'static str with "" — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.266s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome65:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome65:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 66: crates/command/src/trace.rs:164:5: replace outcome -> &'static str with "xyzzy" — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.083s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome66:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome66:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 67: crates/command/src/trace.rs:185:5: replace accepted with () — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.335s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome67:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome67:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 68: crates/command/src/trace.rs:189:5: replace duplicate with () — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.084s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome68:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome68:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Outcome 69: crates/command/src/trace.rs:193:5: replace reply_dropped with () — CaughtMutant
PASS [   0.014s] (33/49) mnesis-command::recovery readiness_release_allows_a_reentrant_stop_callback
        PASS [   0.014s] (40/49) mnesis-command::recovery timer_disabled_runtime_retains_the_native_failure
        FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop
     Summary [   3.141s] 47/49 tests run: 46 passed, 1 failed, 1 skipped
1. Contract/counterexample: Actual independent law rejects the replacement: FAIL [   0.005s] (47/49) mnesis-command::trace caller_context_survives_the_queue_and_an_unpolled_response_drop.
2. Execution/selection/services: Actual named nextest invocation and final count shown above, original performance ignore retained; runner fail-fast means later unexecuted cases receive no credit. Disposable Postgres exists in this workflow but selected command tests use their in-memory controlled stores; no native composition credit.
3. Source/assertion/false positives: exact PR head/artifact/log match. Concrete named data/trace/lifecycle assertion fails before the selected run completes; not a zero-selected, service-unavailable or compiler failure.

Child readiness_release_allows_a_reentrant_stop_callback, outcome69:
1. Contract: real native readiness wake may reenter stop; observed join must finish without uncertainty.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.

Child timer_disabled_runtime_retains_the_native_failure, outcome69:
1. Contract: exact native timer panic, uncertain identity, zero rows and closed admission.
2. Execution: actual parent PASS; helper requires exact child-name selection, successful child status and exactly one PASS within2seconds.
3. Source/assertion: existing helper/oracle unchanged; zero selection, process failure or deadlock cannot pass. No child credit inferred for earlier fail-fast outcomes.
