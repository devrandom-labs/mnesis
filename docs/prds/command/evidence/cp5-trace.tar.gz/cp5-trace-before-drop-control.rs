use std::future::Future;

#[cfg(feature = "tracing")]
use tracing::instrument::WithSubscriber;
#[cfg(feature = "tracing")]
use tracing::{Dispatch, Instrument, Span, debug_span, dispatcher, info, info_span};

use crate::Error;

#[derive(Clone)]
pub struct Scope {
    #[cfg(feature = "tracing")]
    span: Span,
    #[cfg(feature = "tracing")]
    subscriber: Dispatch,
}
pub struct Trace {
    #[cfg(feature = "tracing")]
    scope: Scope,
    #[cfg(feature = "tracing")]
    outcome: &'static str,
}
impl Trace {
    pub fn request(operation: &'static str) -> Self {
        let _ = operation;
        Self {
            #[cfg(feature = "tracing")]
            scope: Scope {
                #[cfg(feature = "tracing")]
                span: info_span!(
                    "mnesis.command.request",
                    operation,
                    outcome = tracing::field::Empty
                ),
                #[cfg(feature = "tracing")]
                subscriber: dispatcher::get_default(Clone::clone),
            },
            #[cfg(feature = "tracing")]
            outcome: "interrupted",
        }
    }
    fn worker() -> Self {
        Self {
            #[cfg(feature = "tracing")]
            scope: Scope {
                #[cfg(feature = "tracing")]
                span: info_span!(parent: None, "mnesis.command.worker", outcome = tracing::field::Empty),
                #[cfg(feature = "tracing")]
                subscriber: dispatcher::get_default(Clone::clone),
            },
            #[cfg(feature = "tracing")]
            outcome: "interrupted",
        }
    }
    pub fn scope(&self) -> Scope {
        #[cfg(feature = "tracing")]
        {
            self.scope.clone()
        }
        #[cfg(not(feature = "tracing"))]
        {
            let _ = self;
            Scope {}
        }
    }
    pub const fn finish(&mut self, outcome: &'static str) {
        #[cfg(feature = "tracing")]
        {
            self.outcome = outcome;
        }
        #[cfg(not(feature = "tracing"))]
        let _ = (self, outcome);
    }
}
impl Drop for Trace {
    fn drop(&mut self) {
        #[cfg(feature = "tracing")]
        self.scope.span.record("outcome", self.outcome);
    }
}
impl Scope {
    pub async fn run<F: Future>(self, future: F) -> F::Output {
        #[cfg(feature = "tracing")]
        {
            future
                .instrument(self.span.clone())
                .with_subscriber(self.subscriber.clone())
                .await
        }
        #[cfg(not(feature = "tracing"))]
        {
            let _ = self;
            future.await
        }
    }
}
impl Drop for Scope {
    fn drop(&mut self) {
        #[cfg(feature = "tracing")]
        dispatcher::with_default(&self.subscriber, || {
            let span = std::mem::replace(&mut self.span, Span::none());
            drop(span);
        });
    }
}
pub fn worker<F: Future<Output = ()>>(future: F) -> impl Future<Output = ()> {
    let mut trace = Trace::worker();
    trace.scope().run(async move {
        future.await;
        trace.finish("ok");
    })
}
pub async fn step<F, T, D, I, E>(stage: &'static str, future: F) -> Result<T, Error<D, I, E>>
where
    F: Future<Output = Result<T, Error<D, I, E>>>,
{
    let _ = stage;
    #[cfg(feature = "tracing")]
    let scope = Scope {
        span: debug_span!("mnesis.command.stage", stage),
        subscriber: dispatcher::get_default(Clone::clone),
    };
    #[cfg(not(feature = "tracing"))]
    let scope = Scope {};
    scope.run(future).await
}
pub const fn outcome<T, D, I, E>(result: &Result<T, Error<D, I, E>>) -> &'static str {
    match result {
        Ok(_) => "ok",
        Err(error) => match error {
            Error::Failed(_) => "failed",
            Error::Mismatch => "mismatch",
            Error::Conflict => "conflict",
            Error::QueueFull => "queue_full",
            Error::QueueLimit { .. } => "queue_limit",
            Error::DeadlineZero => "deadline_zero",
            Error::Closed => "closed",
            Error::Scope => "scope",
            Error::Runtime(_) => "runtime",
            Error::Uncertain { .. } => "uncertain",
            Error::Request(_) => "request",
            Error::Corrupt => "corrupt",
            Error::Timeout => "timeout",
        },
    }
}
pub fn accepted() {
    #[cfg(feature = "tracing")]
    info!(name: "mnesis.command.accepted", outcome = "ok");
}
pub fn duplicate() {
    #[cfg(feature = "tracing")]
    info!(name: "mnesis.command.duplicate", outcome = "ok");
}
pub fn reply_dropped() {
    #[cfg(feature = "tracing")]
    info!(name: "mnesis.command.reply_dropped", outcome = "cancelled");
}
