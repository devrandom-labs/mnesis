# CP6 Fjall first-head Linux reviews

Run39711312051, signed headfeeab8df610bf449be3da28da809c99a456f7984,14terminalSUCCESS jobs.82actual harness outcomes/6zero-case compiler-only/76nonzero; cached plain264 summary echoed after standalone native build excluded. Nix3corpus+workspace+20native; standalone20native separately. Four modes47/51/48/52 and SDK2. Default workspace1643/149bins/5original exclusions/3slow97.379s. No main-base full workflow/protected delivery or processor Postgres/performance inference.

## 1_Features (mnesis-macros).txt — actual outcome1

2026-10-22T02:28:25.6131874Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 1_Features (mnesis-macros).txt — actual outcome2

2026-10-22T02:28:25.7564389Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 1_Features (mnesis-macros).txt — actual outcome3

2026-10-22T02:28:25.9001064Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 2_Features (mnesis).txt — actual outcome1

2026-10-22T02:28:37.2767482Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 2_Features (mnesis).txt — actual outcome2

2026-10-22T02:28:37.4097662Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 2_Features (mnesis).txt — actual outcome3

2026-10-22T02:28:37.9399036Z test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 3_Features (mnesis-wake).txt — actual outcome1

2026-10-22T02:28:26.7955559Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 3_Features (mnesis-wake).txt — actual outcome2

2026-10-22T02:28:27.0578056Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 3_Features (mnesis-wake).txt — actual outcome3

2026-10-22T02:28:27.3174884Z test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.15s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 4_Features (mnesis-inmemory).txt — actual outcome1

2026-10-22T02:28:23.1746012Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 4_Features (mnesis-inmemory).txt — actual outcome2

2026-10-22T02:28:23.3217623Z test result: ok. 25 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 4_Features (mnesis-inmemory).txt — actual outcome3

2026-10-22T02:28:25.4120203Z test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 5_Features (mnesis-wake-nostd).txt — actual outcome1

2026-10-22T02:28:42.7882903Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No behavior exercised: this is compiler-only isolated library evidence.
2. Execution/selection/services: Actual zero-case outcome shown above; no runtime/service acceptance credit.
3. Assertion strength/source/false positives: No assertion executes. Cannot substitute for native/command/runtime acceptance.

## 5_Features (mnesis-wake-nostd).txt — actual outcome2

2026-10-22T02:28:42.8980461Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No behavior exercised: this is compiler-only isolated library evidence.
2. Execution/selection/services: Actual zero-case outcome shown above; no runtime/service acceptance credit.
3. Assertion strength/source/false positives: No assertion executes. Cannot substitute for native/command/runtime acceptance.

## 5_Features (mnesis-wake-nostd).txt — actual outcome3

2026-10-22T02:28:43.0144584Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No behavior exercised: this is compiler-only isolated library evidence.
2. Execution/selection/services: Actual zero-case outcome shown above; no runtime/service acceptance credit.
3. Assertion strength/source/false positives: No assertion executes. Cannot substitute for native/command/runtime acceptance.

## 6_Features (mnesis-command).txt — actual outcome1

2026-10-22T02:28:07.2996138Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 6_Features (mnesis-command).txt — actual outcome2

2026-10-22T02:28:08.1344571Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 6_Features (mnesis-command).txt — actual outcome3

2026-10-22T02:28:09.4811267Z test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 6_Features (mnesis-command).txt — actual outcome4

2026-10-22T02:28:19.2460410Z      Summary [   2.774s] 47 tests run: 47 passed, 1 skipped

1. Contract/counterexamples: Actual none feature run includes original45 laws, selected instrumentation assertions and2real Fjall lifecycle/crash cases. Native graceful close/reopen/bytes/no-op/corrupt-tail and both SIGKILL boundaries preserve original receipts/order/state.
2. Execution/selection/services: Actual47/51/48/52PASS as selected,1original ignored measurement;4owned children per feature mode,2of them deliberately SIGKILLed/reaped. No database/SDK in core tests.
3. Assertion strength/source/false positives: Same five qualified native source/manifest/lock owners as feeab8df; exact bytes, typed corruption, markers/signals, independent final counts and worker/store cleanup remain. No weaker bound/selector/expectation or kernel-only substitute.

Reentrant child: (1) exact callback wake1/stop/Closed/normal completion; (2) actual same-executable exact-one success with2s deadline; (3) original assertions reject skipped callback/deadlock. Timer child: (1) exact native timer panic, uncertain original ID, zero rows/Closed; (2) actual exact-one bounded successful child; (3) retained native payload/result reject erased/wrong cause. Before-append native child: (1) gate before actual native append, independent rows0; (2) actual exact marker then kill/reap signal9; (3) same-path retry initially absent/state0 then exact original yields1final acceptance/state7. After-commit native child: (1) real SyncAll append/original receipt/fact in1durable row before held reply; (2) exact marker then observed kill/reap9; (3) same-path reopened original receipt/state7 and exactly1final acceptance reject fake boundary/loss/duplicate. Killed children are not successful extra Rust cases.

## 6_Features (mnesis-command).txt — actual outcome5

2026-10-22T02:28:30.7790217Z      Summary [   2.791s] 51 tests run: 51 passed, 1 skipped

1. Contract/counterexamples: Actual tracing feature run includes original45 laws, selected instrumentation assertions and2real Fjall lifecycle/crash cases. Native graceful close/reopen/bytes/no-op/corrupt-tail and both SIGKILL boundaries preserve original receipts/order/state.
2. Execution/selection/services: Actual47/51/48/52PASS as selected,1original ignored measurement;4owned children per feature mode,2of them deliberately SIGKILLed/reaped. No database/SDK in core tests.
3. Assertion strength/source/false positives: Same five qualified native source/manifest/lock owners as feeab8df; exact bytes, typed corruption, markers/signals, independent final counts and worker/store cleanup remain. No weaker bound/selector/expectation or kernel-only substitute.

Reentrant child: (1) exact callback wake1/stop/Closed/normal completion; (2) actual same-executable exact-one success with2s deadline; (3) original assertions reject skipped callback/deadlock. Timer child: (1) exact native timer panic, uncertain original ID, zero rows/Closed; (2) actual exact-one bounded successful child; (3) retained native payload/result reject erased/wrong cause. Before-append native child: (1) gate before actual native append, independent rows0; (2) actual exact marker then kill/reap signal9; (3) same-path retry initially absent/state0 then exact original yields1final acceptance/state7. After-commit native child: (1) real SyncAll append/original receipt/fact in1durable row before held reply; (2) exact marker then observed kill/reap9; (3) same-path reopened original receipt/state7 and exactly1final acceptance reject fake boundary/loss/duplicate. Killed children are not successful extra Rust cases.

## 6_Features (mnesis-command).txt — actual outcome6

2026-10-22T02:28:42.1416376Z      Summary [   2.954s] 48 tests run: 48 passed, 1 skipped

1. Contract/counterexamples: Actual metrics feature run includes original45 laws, selected instrumentation assertions and2real Fjall lifecycle/crash cases. Native graceful close/reopen/bytes/no-op/corrupt-tail and both SIGKILL boundaries preserve original receipts/order/state.
2. Execution/selection/services: Actual47/51/48/52PASS as selected,1original ignored measurement;4owned children per feature mode,2of them deliberately SIGKILLed/reaped. No database/SDK in core tests.
3. Assertion strength/source/false positives: Same five qualified native source/manifest/lock owners as feeab8df; exact bytes, typed corruption, markers/signals, independent final counts and worker/store cleanup remain. No weaker bound/selector/expectation or kernel-only substitute.

Reentrant child: (1) exact callback wake1/stop/Closed/normal completion; (2) actual same-executable exact-one success with2s deadline; (3) original assertions reject skipped callback/deadlock. Timer child: (1) exact native timer panic, uncertain original ID, zero rows/Closed; (2) actual exact-one bounded successful child; (3) retained native payload/result reject erased/wrong cause. Before-append native child: (1) gate before actual native append, independent rows0; (2) actual exact marker then kill/reap signal9; (3) same-path retry initially absent/state0 then exact original yields1final acceptance/state7. After-commit native child: (1) real SyncAll append/original receipt/fact in1durable row before held reply; (2) exact marker then observed kill/reap9; (3) same-path reopened original receipt/state7 and exactly1final acceptance reject fake boundary/loss/duplicate. Killed children are not successful extra Rust cases.

## 6_Features (mnesis-command).txt — actual outcome7

2026-10-22T02:28:54.9633995Z      Summary [   3.094s] 52 tests run: 52 passed, 1 skipped

1. Contract/counterexamples: Actual combined feature run includes original45 laws, selected instrumentation assertions and2real Fjall lifecycle/crash cases. Native graceful close/reopen/bytes/no-op/corrupt-tail and both SIGKILL boundaries preserve original receipts/order/state.
2. Execution/selection/services: Actual47/51/48/52PASS as selected,1original ignored measurement;4owned children per feature mode,2of them deliberately SIGKILLed/reaped. No database/SDK in core tests.
3. Assertion strength/source/false positives: Same five qualified native source/manifest/lock owners as feeab8df; exact bytes, typed corruption, markers/signals, independent final counts and worker/store cleanup remain. No weaker bound/selector/expectation or kernel-only substitute.

Reentrant child: (1) exact callback wake1/stop/Closed/normal completion; (2) actual same-executable exact-one success with2s deadline; (3) original assertions reject skipped callback/deadlock. Timer child: (1) exact native timer panic, uncertain original ID, zero rows/Closed; (2) actual exact-one bounded successful child; (3) retained native payload/result reject erased/wrong cause. Before-append native child: (1) gate before actual native append, independent rows0; (2) actual exact marker then kill/reap signal9; (3) same-path retry initially absent/state0 then exact original yields1final acceptance/state7. After-commit native child: (1) real SyncAll append/original receipt/fact in1durable row before held reply; (2) exact marker then observed kill/reap9; (3) same-path reopened original receipt/state7 and exactly1final acceptance reject fake boundary/loss/duplicate. Killed children are not successful extra Rust cases.

## 6_Features (mnesis-command).txt — actual outcome8

2026-10-22T02:29:05.9719331Z      Summary [   0.017s] 2 tests run: 2 passed, 0 skipped

1. Contract/counterexamples: Actual example validates context-bearing SDK spans/Prometheus metrics, exact native receipts/data/no-op/resume/retry and unavailable export flushes.
2. Execution/selection/services: Actual2PASS0skip native executable/SDK cases, no database; finite typed exporter callback, not generic network timeout.
3. Assertion strength/source/false positives: Exact original/receipt/facts/counts and trace parents reject disabled instrumentation; retained filter-off/empty-main controls fail. Unknown-write failed SDK composition remains CP6.

CLI child: (1) native exported application span plus exact receipt/state flow; (2) actual executable observed success/empty stderr within3s; (3) exact output rejects empty main/skipped telemetry. Not another top-level suite.

## 7_Nix Flake Check.txt — actual outcome1

2026-10-22T02:28:26.6689206Z mnesis-fuzz-replay> test result: ok(B. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Existing canonical wire/CBOR/event-type parser bodies execute real decoding/round-trip/validation laws against retained corpus.
2. Execution/selection/services: Actual fresh nonzero corpus harness with counts/time above; no command-fuzz or service claim.
3. Assertion strength/source/false positives: Unchanged fuzz-common production calls and corpus; bounded parser evidence does not prove command record/history fuzz coverage.

## 7_Nix Flake Check.txt — actual outcome2

2026-10-22T02:28:27.6697045Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Existing canonical wire/CBOR/event-type parser bodies execute real decoding/round-trip/validation laws against retained corpus.
2. Execution/selection/services: Actual fresh nonzero corpus harness with counts/time above; no command-fuzz or service claim.
3. Assertion strength/source/false positives: Unchanged fuzz-common production calls and corpus; bounded parser evidence does not prove command record/history fuzz coverage.

## 7_Nix Flake Check.txt — actual outcome3

2026-10-22T02:28:28.6709611Z mnesis-fuzz-replay> test result: ok(B. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s

1. Contract/counterexamples: Existing canonical wire/CBOR/event-type parser bodies execute real decoding/round-trip/validation laws against retained corpus.
2. Execution/selection/services: Actual fresh nonzero corpus harness with counts/time above; no command-fuzz or service claim.
3. Assertion strength/source/false positives: Unchanged fuzz-common production calls and corpus; bounded parser evidence does not prove command record/history fuzz coverage.

## 7_Nix Flake Check.txt — actual outcome4

2026-10-22T02:36:59.4565414Z mnesis-nextest>      Summary [  97.379s] 1643 tests run: 1643 passed (3 slow), 5 skipped

1. Contract/counterexamples: Whole default workspace includes45canonical command laws+2nativeFjall cases, core/store/adapter owners and actual neutral CLI; original lifecycle/isolation/defensive assertions preserved.
2. Execution/selection/services: Actual1643PASS/149bins/5original exclusions/3slow97.379s. Fivecommand/example children; legacy no-DB fixtures not credited as native. Disabled instrumentation does not certify feature-on APIs.
3. Assertion strength/source/false positives: Exact native source and locked deps; full source/assertions/limits/selectors unchanged. New native cases passed, not merely compiled; source golden/typed-error/observed cleanup assertions reject fake success.

Reentrant child: (1) exact callback wake1/stop/Closed/normal completion; (2) actual same-executable exact-one success with2s deadline; (3) original assertions reject skipped callback/deadlock. Timer child: (1) exact native timer panic, uncertain original ID, zero rows/Closed; (2) actual exact-one bounded successful child; (3) retained native payload/result reject erased/wrong cause. Before-append native child: (1) gate before actual native append, independent rows0; (2) actual exact marker then kill/reap signal9; (3) same-path retry initially absent/state0 then exact original yields1final acceptance/state7. After-commit native child: (1) real SyncAll append/original receipt/fact in1durable row before held reply; (2) exact marker then observed kill/reap9; (3) same-path reopened original receipt/state7 and exactly1final acceptance reject fake boundary/loss/duplicate. Killed children are not successful extra Rust cases. CLI child separately: (1) exact real receipts/state/duplicate/no-op/resume/retry; (2) actual executable bounded3s/status success/empty stderr; (3) exact output rejects empty-success-main. Fivechildren total, not extra suites.

## 7_Nix Flake Check.txt — actual outcome5

2026-10-22T02:42:46.8063900Z mnesis-postgres-integration>      Summary [   0.346s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome6

2026-10-22T02:42:50.3228348Z mnesis-postgres-integration>      Summary [   0.172s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome7

2026-10-22T02:42:54.1129688Z mnesis-postgres-integration>      Summary [   0.844s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome8

2026-10-22T02:42:59.2557648Z mnesis-postgres-integration>      Summary [   1.162s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome9

2026-10-22T02:43:03.7051422Z mnesis-postgres-integration>      Summary [   0.802s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome10

2026-10-22T02:43:11.6817988Z mnesis-postgres-integration>      Summary [   3.885s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome11

2026-10-22T02:43:14.6327520Z mnesis-postgres-integration>      Summary [   0.031s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome12

2026-10-22T02:44:16.0053843Z mnesis-postgres-integration>      Summary [  58.228s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome13

2026-10-22T02:44:18.0842233Z mnesis-postgres-integration>      Summary [   0.038s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome14

2026-10-22T02:44:49.3436214Z mnesis-postgres-integration>      Summary [  29.258s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome15

2026-10-22T02:44:52.1081638Z mnesis-postgres-integration>      Summary [   0.548s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome16

2026-10-22T02:45:33.4085125Z mnesis-postgres-integration>      Summary [  39.031s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome17

2026-10-22T02:45:35.5457187Z mnesis-postgres-integration>      Summary [   0.045s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome18

2026-10-22T02:46:12.7887727Z mnesis-postgres-integration>      Summary [  35.132s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome19

2026-10-22T02:46:15.3007981Z mnesis-postgres-integration>      Summary [   0.360s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome20

2026-10-22T02:46:53.4029020Z mnesis-postgres-integration>      Summary [  35.643s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome21

2026-10-22T02:46:55.2506392Z mnesis-postgres-integration>      Summary [   0.049s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome22

2026-10-22T02:47:28.5229134Z mnesis-postgres-integration>      Summary [  31.165s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome23

2026-10-22T02:47:31.6157852Z mnesis-postgres-integration>      Summary [   1.041s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 7_Nix Flake Check.txt — actual outcome24

2026-10-22T02:48:04.6249072Z mnesis-postgres-integration>      Summary [  30.917s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 8_Features (mnesis-store-testing).txt — actual outcome1

2026-10-22T02:28:30.7753335Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No behavior exercised: this is compiler-only isolated library evidence.
2. Execution/selection/services: Actual zero-case outcome shown above; no runtime/service acceptance credit.
3. Assertion strength/source/false positives: No assertion executes. Cannot substitute for native/command/runtime acceptance.

## 8_Features (mnesis-store-testing).txt — actual outcome2

2026-10-22T02:28:30.9026940Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No behavior exercised: this is compiler-only isolated library evidence.
2. Execution/selection/services: Actual zero-case outcome shown above; no runtime/service acceptance credit.
3. Assertion strength/source/false positives: No assertion executes. Cannot substitute for native/command/runtime acceptance.

## 8_Features (mnesis-store-testing).txt — actual outcome3

2026-10-22T02:28:31.0287407Z test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: No behavior exercised: this is compiler-only isolated library evidence.
2. Execution/selection/services: Actual zero-case outcome shown above; no runtime/service acceptance credit.
3. Assertion strength/source/false positives: No assertion executes. Cannot substitute for native/command/runtime acceptance.

## 9_Features (mnesis-fjall).txt — actual outcome1

2026-10-22T02:28:43.0702721Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.46s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 9_Features (mnesis-fjall).txt — actual outcome2

2026-10-22T02:28:45.6605344Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.46s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 9_Features (mnesis-fjall).txt — actual outcome3

2026-10-22T02:28:49.0541344Z test result: ok. 131 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 3.26s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 10_Features (mnesis-postgres).txt — actual outcome1

2026-10-22T02:28:37.1954082Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 10_Features (mnesis-postgres).txt — actual outcome2

2026-10-22T02:28:37.3048107Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 10_Features (mnesis-postgres).txt — actual outcome3

2026-10-22T02:28:39.4288360Z test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 11_Features (mnesis-store).txt — actual outcome1

2026-10-22T02:29:05.4580398Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 3.06s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 11_Features (mnesis-store).txt — actual outcome2

2026-10-22T02:29:08.5782107Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.99s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 11_Features (mnesis-store).txt — actual outcome3

2026-10-22T02:29:15.6033894Z test result: ok. 217 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.83s

1. Contract/counterexamples: Isolated library owner invariants execute in default/no-default/all-features order. Existing type/parsing/sequence invariants remain at their source owner.
2. Execution/selection/services: Actual nonzero unit harness counts/time above; Postgres11units are not real-database integration.
3. Assertion strength/source/false positives: Exact headfeeab8df/locked source and unchanged unit assertions. No whole runtime or clean registry claim inferred from isolated compilation/unit cases.

## 12_Postgres Integration.txt — actual outcome1

2026-10-22T02:38:45.9080930Z mnesis-postgres-integration>      Summary [   0.090s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome2

2026-10-22T02:38:50.5900484Z mnesis-postgres-integration>      Summary [   0.559s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome3

2026-10-22T02:38:56.7993654Z mnesis-postgres-integration>      Summary [   2.107s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome4

2026-10-22T02:39:01.0973800Z mnesis-postgres-integration>      Summary [   0.201s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome5

2026-10-22T02:39:05.3643614Z mnesis-postgres-integration>      Summary [   0.157s] 1 test run: 1 passed, 10 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome6

2026-10-22T02:39:11.4890327Z mnesis-postgres-integration>      Summary [   2.003s] 1 test run: 1 passed, 4 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome7

2026-10-22T02:39:15.6370432Z mnesis-postgres-integration>      Summary [   0.049s] 1 test run: 1 passed, 9 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome8

2026-10-22T02:40:26.3719053Z mnesis-postgres-integration>      Summary [  66.323s] 264 tests run: 264 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome9

2026-10-22T02:40:29.2114719Z mnesis-postgres-integration>      Summary [   0.056s] 1 test run: 1 passed, 39 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome10

2026-10-22T02:41:11.9477810Z mnesis-postgres-integration>      Summary [  39.961s] 149 tests run: 149 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome11

2026-10-22T02:41:15.1951151Z mnesis-postgres-integration>      Summary [   0.275s] 1 test run: 1 passed, 7 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome12

2026-10-22T02:42:02.1368328Z mnesis-postgres-integration>      Summary [  43.856s] 168 tests run: 168 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome13

2026-10-22T02:42:05.0734351Z mnesis-postgres-integration>      Summary [   0.068s] 1 test run: 1 passed, 14 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome14

2026-10-22T02:42:53.2297512Z mnesis-postgres-integration>      Summary [  45.203s] 176 tests run: 176 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome15

2026-10-22T02:42:56.3754514Z mnesis-postgres-integration>      Summary [   0.149s] 1 test run: 1 passed, 2 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome16

2026-10-22T02:43:41.8555909Z mnesis-postgres-integration>      Summary [  42.373s] 173 tests run: 173 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome17

2026-10-22T02:43:44.8135959Z mnesis-postgres-integration>      Summary [   0.081s] 1 test run: 1 passed, 15 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome18

2026-10-22T02:44:28.8975319Z mnesis-postgres-integration>      Summary [  41.124s] 174 tests run: 174 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome19

2026-10-22T02:44:32.8145655Z mnesis-postgres-integration>      Summary [   1.064s] 1 test run: 1 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 12_Postgres Integration.txt — actual outcome20

2026-10-22T02:45:15.9030970Z mnesis-postgres-integration>      Summary [  40.150s] 150 tests run: 150 passed, 0 skipped

1. Contract/counterexamples: Existing adapter-native transaction/ordering/migration/transport/checkpoint/TLS/durability laws retain independent SQL and precise typed outcome assertions.
2. Execution/selection/services: Actual fresh archive invocation on Nix-initialized Unix Postgres; SELECT1 and startup/shutdown present. Seven feature suites264/149/168/176/173/174/150 and13required single-case smokes; count/selection/time above.
3. Assertion strength/source/false positives: Exact locked source/archive, no-tests=fail and serial selection retained; no missing-service early return credited. Native adapter law is not processor composition, and no after-commit timeout is called safe retry.

## 13_Compile-fail tests.txt — actual outcome1

2026-10-22T02:28:48.8786325Z test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 124.06s

1. Contract/counterexamples: Actual kernel/macro/store diagnostic fixtures check intended failing and passing compiler contracts.
2. Execution/selection/services: Nonzero actual harness counts/time above, not cargo-check-only.
3. Assertion strength/source/false positives: Original expected diagnostics/source unchanged; intended error contract, not arbitrary compiler failure.

## 13_Compile-fail tests.txt — actual outcome2

2026-10-22T02:29:23.5469157Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 16.20s

1. Contract/counterexamples: Actual kernel/macro/store diagnostic fixtures check intended failing and passing compiler contracts.
2. Execution/selection/services: Nonzero actual harness counts/time above, not cargo-check-only.
3. Assertion strength/source/false positives: Original expected diagnostics/source unchanged; intended error contract, not arbitrary compiler failure.

## 13_Compile-fail tests.txt — actual outcome3

2026-10-22T02:29:50.8135131Z test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 19.26s

1. Contract/counterexamples: Actual kernel/macro/store diagnostic fixtures check intended failing and passing compiler contracts.
2. Execution/selection/services: Nonzero actual harness counts/time above, not cargo-check-only.
3. Assertion strength/source/false positives: Original expected diagnostics/source unchanged; intended error contract, not arbitrary compiler failure.
