# Native Fjall full-gate corpus reviews

Three actual fresh Rust harnesses in cp6-fjall-full-flake.log while workspace
6463036f-6521-448a-ab3c-282814c01fe1 still runs. Existing fuzz sources/oracles
unchanged; these do not certify command fuzz, SDK export, native DB or performance.

CBOR: (1) original header/chunk production decoder boundaries and saved-input
oracles execute; (2)2PASS/0FAIL/0ignored/0filtered/1.00s, both named cases actually
run with no external service; (3) unchanged source/corpus/assertions, nonzero
runtime rather than compiler-only/empty selection, no gate or workload change.

Value: (1) actual event-type UTF8/length validation body and original oracles;
(2)1PASS/0FAIL/0ignored/0filtered/1.00s, actual Rust harness without service;
(3) original source/assertions, not proof of command history or a new campaign.

Wire: (1) real wire-frame validation/decoding body and original saved-input
assertions; (2)1PASS/0FAIL/0ignored/0filtered/1.00s, actual nonempty selection;
(3) unchanged production decoder/harness/corpus, not a copied parser, compiler
pass or weakened input/gate. Full workspace and source identity still pending.
