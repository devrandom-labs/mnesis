# Native Fjall full workspace gate reviews

Run6463036f-6521-448a-ab3c-282814c01fe1:1643PASS/149binaries/5original
exclusions/15slow/501.813s. Full Nix process5244 still finishing compile-only
checks at observation. Raw cp6-fjall-full-flake.log; no all12pass claim yet.

1. Contract/counterexamples: original default workspace and47command laws pass,
including new graceful native receipt/byte/no-op/corrupt-tail and two-boundary
SIGKILL recovery. Existing typed uncertainty, conditional writes, serialization,
limits, native causes/custody, cancellation and order remain. Default example
unit and actual CLI pass. Trace/metrics/SDK enabled integration cases are not
selected here and have separate mode evidence.
2. Execution/selection/services:1643actual selected/149binaries; unchanged four
compiler-negative and one measurement exclusions. Five command/example owned
children execute:2original successful bounded processes,2native killed boundary
processes,1actual default example binary. No native Postgres credit from absent-
service default stubs. All15slow cases finish normally; no restart/timeout
relaxation to obtain green. No benchmark claims from resource-shared test times.
3. Assertions/source/false positives:16source/manifest/helper/test owners cmp
exactly with actual /nix/store/wd4msqx8kbygqybnklrzwfvbnmjv19k0-source;16valid
checksum entries verified, not just loop exit. Native source hashes unchanged
after parent integration. Strong exact marker and30s/3s bounds, row/receipt/state/
byte/error checks and original gates retained. Both initial handshake failures
and actual diagnostic bytes preserved; not counted as product mutation catches.

Reentrant child: (1) actual callback stop/wake1/Closed/normal join; (2) parentPASS
0.078s checks exact-one/status/2s; (3) exact callback/result rejects missing/stuck.
Timer child: (1) exact native timer panic/uncertain original/zero rows/Closed/
empty report; (2) parentPASS0.053s exact-one/status/2s; (3) native cause/summary
reject wrong/skipped/stuck child.
Before native child: (1) actual append gate/native rows0, (2) exact marker then
observed SIGKILL9/reap before reopen, (3) absent receipt/state0 then exact original
and exactly-one final acceptance/state7 reject wrong boundary/lost identity.
Committed native child: (1) actual SyncAll completed original row1 before held
reply, (2) exact marker and observed kill/reap9, (3) reopened original receipt/
state7 and exactly-one final record reject fake/partial/duplicate commit.
Example child: (1) exact first/no-op/duplicate/retry/state7→7 summary; (2) parentPASS
0.387s checks success/empty stderr/concurrent pipes/3s; (3) independently expected
receipts reject empty successful main. Default promises no SDK export here.
Each child separately three-reviewed; none inflated into1643harness cases.

