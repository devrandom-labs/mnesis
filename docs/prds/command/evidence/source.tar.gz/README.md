# Controller source archive

Preserved from Labcast before removing the controller from the mobile repository.
The crate is at crates/controller. The root Cargo manifest, lock and Rust settings
retain its workspace configuration. This is a source archive, not a published
package or an upstream Mnesis change.
