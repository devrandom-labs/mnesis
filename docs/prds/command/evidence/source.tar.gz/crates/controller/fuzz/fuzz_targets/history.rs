#![no_main]
#[path = "../../tests/support/history.rs"]
mod history;
use libfuzzer_sys::fuzz_target;

fuzz_target!(|bytes: &[u8]| {
    tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap()
        .block_on(history::run(bytes));
});
