#![no_main]
#[path = "../../tests/support/operation.rs"]
mod operation;
use labcast_controller::Request;
use libfuzzer_sys::fuzz_target;
use uuid::Uuid;

fuzz_target!(|bytes: &[u8]| {
    if let Ok(request) = Request::<operation::Operation, Uuid>::decode(bytes) {
        let encoded = request.encode().unwrap();
        assert_eq!(
            Request::<operation::Operation, Uuid>::decode(&encoded).unwrap(),
            request
        );
    }
    if let Ok(request) = Request::<operation::Operation>::decode(bytes) {
        let encoded = request.encode().unwrap();
        assert_eq!(
            Request::<operation::Operation>::decode(&encoded).unwrap(),
            request
        );
        let mut future: serde_json::Value = serde_json::from_slice(&encoded).unwrap();
        future["future"] = "unsupported".into();
        assert!(
            Request::<operation::Operation>::decode(&serde_json::to_vec(&future).unwrap()).is_err()
        );
    }
});
