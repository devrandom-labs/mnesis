# Disposable Tower/Mnesis compatibility evidence

Run from /Users/joel/orca/workspaces/nexus/command-prd using its existing Nix shell.
Sources engine.rs, model.rs and tests/unit/model.rs are unchanged controller archive
inputs. lib.rs is an experimental worker/neutral-domain test fixture. It is not a
new product package. No assertions from these probes were changed to get green.

Commands used (absolute paths identify the actual execution directory):

nix develop path:. --no-update-lock-file --command cargo test --locked --manifest-path /tmp/mnesis-tower-fit.Pr50LQ/Cargo.toml --lib -- --skip worker_terminal_error_preserves_original_cause
nix develop path:. --no-update-lock-file --command cargo test --locked --manifest-path /tmp/mnesis-tower-fit.Pr50LQ/Cargo.toml --lib worker_terminal_ -- --nocapture
nix develop path:. --no-update-lock-file --command cargo test --locked --release --manifest-path /tmp/mnesis-tower-fit.Pr50LQ/Cargo.toml --lib worker_terminal_ -- --nocapture
nix develop path:. --no-update-lock-file --command cargo test --release --manifest-path /tmp/mnesis-tower-fit.Pr50LQ/destination/Cargo.toml --lib -- --nocapture
nix develop path:. --no-update-lock-file --command cargo tree --locked --manifest-path /tmp/mnesis-tower-fit.Pr50LQ/destination/Cargo.toml -e normal

The compatible run preceded the added shutdown-race test. Final full matrix
contains 13 tests: 11 passing, 2 failing requirements. The release failure run
added stage diagnostics only. Both manifests now have resolved locks; use --locked
when reproducing. Final source reproduces both failures; no #[ignore]/should_panic.
Failure logs and the two initial fixture compile errors are retained.
