// Disposable compatibility experiment. engine.rs and model.rs are unchanged archive copies.
#[allow(dead_code, reason = "unchanged source exposes operations outside this focused probe")]
mod engine;
#[allow(dead_code, reason = "unchanged source includes the original host error variants")]
mod model;
pub use model::{Error, Receipt, Request};

#[cfg(test)]
mod tests {
    use std::future::Future;
    use std::num::NonZeroU64;
    use std::task::{Context, Poll};
    use std::time::Duration;
    use futures::{TryStreamExt, task::noop_waker_ref};
    use mnesis::{Aggregate, AggregateState, DomainEvent, Events, Handle, Message, Version, events};
    use mnesis_inmemory::InMemoryStore;
    use mnesis_store::{RawEventStore, Store, StreamKey};
    use serde::{Deserialize, Serialize};
    use tokio::sync::oneshot;
    use tower::{Service, ServiceExt};
    use tower_actor::{Actor, ActorError};
    use crate::{Error, Receipt, Request, engine::Engine};

    #[derive(Debug, thiserror::Error)]
    #[error("business rejection")]
    struct Rejected;
    #[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
    enum Command { Add(u64), Reject }
    #[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
    struct Added(u64);
    impl Message for Added {}
    impl DomainEvent for Added { fn name(&self) -> &'static str { "added" } }
    #[derive(Clone, Debug, PartialEq, Eq)]
    struct Total(u64);
    impl AggregateState for Total {
        type Event = Added;
        fn initial() -> Self { Self(0) }
        fn apply(self, event: &Added) -> Self { Self(self.0.checked_add(event.0).unwrap()) }
    }
    struct Counter;
    impl Aggregate for Counter { type State = Total; type Error = Rejected; type Id = String; }
    impl Handle<Command> for Counter {
        fn handle(_: &Total, cmd: Command) -> Result<Option<Events<Added>>, Rejected> {
            match cmd { Command::Add(n) => Ok(Some(events![Added(n)])), Command::Reject => Err(Rejected) }
        }
    }
    #[derive(Debug, thiserror::Error)]
    enum Failure {
        #[error(transparent)]
        Engine(#[from] Error<Rejected>),
        #[error(transparent)]
        Actor(#[from] ActorError),
        #[error("worker failed with code {0}")]
        Worker(u32),
    }
    type Processor = Actor<Request<Command>, Receipt, Failure>;
    type Core = Engine<InMemoryStore, Counter, Command, NonZeroU64, 0>;
    fn core(store: &Store<InMemoryStore>) -> Core {
        Engine::new(store, "counter".to_owned(), Duration::from_secs(1), None)
    }
    fn request(id: u64, expected: u64, command: Command) -> Request<Command> {
        Request { id: NonZeroU64::new(id).unwrap(), expected: Version::new(expected), command }
    }
    async fn bounded<F: Future>(future: F) -> F::Output {
        tokio::time::timeout(Duration::from_secs(5), future).await.expect("probe deadline")
    }
    async fn records(store: &Store<InMemoryStore>) -> Vec<serde_json::Value> {
        store.read_stream(&StreamKey::from_slice(b"counter"), Version::INITIAL)
            .await.unwrap().map_ok(|event| serde_json::from_slice(event.payload()).unwrap())
            .try_collect().await.unwrap()
    }

    #[tokio::test]
    async fn cancellation_after_admission_preserves_active_and_queued_commands() {
        let store = Store::new(InMemoryStore::default());
        let mut engine = core(&store);
        let (entered_tx, entered_rx) = oneshot::channel();
        let (release_tx, release_rx) = oneshot::channel();
        let (done_tx, done_rx) = oneshot::channel();
        let mut actor = Processor::new(1, move |mut rx| async move {
            let first = rx.recv().await.unwrap();
            entered_tx.send(()).unwrap();
            release_rx.await.unwrap();
            let _ = first.rsp_sender.send(engine.submit(first.req).await.map_err(Failure::from));
            while let Some(msg) = rx.recv().await {
                let _ = msg.rsp_sender.send(engine.submit(msg.req).await.map_err(Failure::from));
            }
            done_tx.send(engine.read().await.unwrap()).unwrap();
            Ok(())
        });
        let first = bounded(actor.ready()).await.unwrap().call(request(1, 0, Command::Add(3)));
        bounded(entered_rx).await.unwrap();
        let second = bounded(actor.ready()).await.unwrap().call(request(2, 1, Command::Add(7)));
        // Worker is gated while both admitted reply futures are discarded.
        drop(first);
        drop(second);
        assert_eq!(records(&store).await, Vec::<serde_json::Value>::new());
        drop(actor);
        release_tx.send(()).unwrap();
        assert_eq!(bounded(done_rx).await.unwrap(), (Version::new(2), Total(10)));
        let saved = records(&store).await;
        assert_eq!(saved.len(), 2);
        assert_eq!(saved.iter().map(|r| r["request"]["id"].as_u64().unwrap()).collect::<Vec<_>>(), vec![1, 2]);
        let mut restarted = core(&store);
        let receipt = restarted.submit(request(1, 0, Command::Add(3))).await.unwrap();
        assert_eq!(receipt.version, Version::INITIAL);
        assert_eq!(records(&store).await, saved);
    }

    #[tokio::test]
    async fn capacity_one_applies_backpressure_and_clones_share_the_queue() {
        let store = Store::new(InMemoryStore::default());
        let mut engine = core(&store);
        let (release_tx, release_rx) = oneshot::channel();
        let (done_tx, done_rx) = oneshot::channel();
        let mut actor = Processor::new(1, move |mut rx| async move {
            release_rx.await.unwrap();
            while let Some(msg) = rx.recv().await {
                let _ = msg.rsp_sender.send(engine.submit(msg.req).await.map_err(Failure::from));
            }
            done_tx.send(()).unwrap();
            Ok(())
        });
        let mut other = actor.clone();
        let first = bounded(actor.ready()).await.unwrap().call(request(1, 0, Command::Add(1)));
        let mut cx = Context::from_waker(noop_waker_ref());
        assert!(matches!(other.poll_ready(&mut cx), Poll::Pending));
        release_tx.send(()).unwrap();
        assert_eq!(bounded(first).await.unwrap().version, Version::INITIAL);
        let second = bounded(other.ready()).await.unwrap().call(request(2, 1, Command::Add(2)));
        assert_eq!(bounded(second).await.unwrap().version, Version::new(2).unwrap());
        drop(actor);
        drop(other);
        bounded(done_rx).await.unwrap();
        assert_eq!(core(&store).read().await.unwrap(), (Version::new(2), Total(3)));
    }

    #[tokio::test]
    async fn committed_request_survives_worker_loss_before_reply() {
        let store = Store::new(InMemoryStore::default());
        let mut engine = core(&store);
        let (done_tx, done_rx) = oneshot::channel();
        let original = request(1, 0, Command::Add(9));
        let mut actor = Processor::new(1, move |mut rx| async move {
            let msg = rx.recv().await.unwrap();
            let receipt = engine.submit(msg.req).await.unwrap();
            drop(msg.rsp_sender);
            done_tx.send(receipt).unwrap();
            Ok(())
        });
        let response = bounded(actor.ready()).await.unwrap().call(original.clone());
        assert!(matches!(bounded(response).await, Err(Failure::Actor(ActorError::ActorHungUp))));
        let receipt = bounded(done_rx).await.unwrap();
        let before = records(&store).await;
        assert_eq!(before.len(), 1);
        assert_eq!(core(&store).submit(original).await.unwrap(), receipt);
        assert_eq!(records(&store).await, before);
        drop(actor);
    }

    #[tokio::test]
    async fn response_errors_preserve_typed_domain_rejection() {
        let store = Store::new(InMemoryStore::default());
        let mut engine = core(&store);
        let (done_tx, done_rx) = oneshot::channel();
        let mut actor = Processor::new(1, move |mut rx| async move {
            let msg = rx.recv().await.unwrap();
            let _ = msg.rsp_sender.send(engine.submit(msg.req).await.map_err(Failure::from));
            done_tx.send(()).unwrap();
            Ok(())
        });
        let result = bounded(actor.ready()).await.unwrap().call(request(1, 0, Command::Reject));
        assert!(matches!(bounded(result).await, Err(Failure::Engine(Error::Rejected(Rejected)))));
        bounded(done_rx).await.unwrap();
        assert_eq!(records(&store).await.len(), 0);
        drop(actor);
    }

    #[tokio::test]
    async fn explicit_side_channel_can_return_pending_shutdown_request() {
        let store = Store::new(InMemoryStore::default());
        let (report_tx, report_rx) = oneshot::channel();
        let (stop_tx, stop_rx) = oneshot::channel();
        let mut actor = Processor::new(1, move |mut rx| async move {
            stop_rx.await.unwrap();
            rx.close();
            let queued = rx.recv().await.unwrap();
            report_tx.send(queued.req).unwrap();
            let _ = queued.rsp_sender.send(Err(Failure::Engine(Error::Closed)));
            Ok(())
        });
        let original = request(1, 0, Command::Add(1));
        let result = bounded(actor.ready()).await.unwrap().call(original.clone());
        stop_tx.send(()).unwrap();
        assert_eq!(bounded(report_rx).await.unwrap(), original);
        assert!(matches!(bounded(result).await, Err(Failure::Engine(Error::Closed))));
        assert_eq!(records(&store).await.len(), 0);
        // This is a user-owned report channel, not a task JoinHandle or a durable queue.
        drop(actor);
    }

    #[tokio::test]
    async fn worker_terminal_error_preserves_original_cause() {
        let mut actor = Processor::new(1, move |mut rx| async move {
            let _admitted = rx.recv().await.unwrap();
            Err(Failure::Worker(73))
        });
        let response = bounded(actor.ready()).await.unwrap().call(request(1, 0, Command::Add(1)));
        let observed = bounded(response).await;
        // Required contract probe: remains red if the detached worker loses its cause.
        assert!(matches!(observed, Err(Failure::Worker(73))), "lost worker cause: {observed:?}");
    }

    #[tokio::test]
    async fn worker_terminal_shutdown_after_ready_returns_error_without_panicking() {
        let (close_tx, close_rx) = oneshot::channel();
        let (closed_tx, closed_rx) = oneshot::channel();
        let mut actor = Processor::new(1, move |mut rx| async move {
            close_rx.await.unwrap();
            rx.close();
            drop(rx);
            closed_tx.send(()).unwrap();
            Ok(())
        });
        bounded(actor.ready()).await.unwrap();
        eprintln!("shutdown probe: readiness reserved");
        close_tx.send(()).unwrap();
        bounded(closed_rx).await.unwrap();
        eprintln!("shutdown probe: receiver closed and dropped");
        let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            actor.call(request(1, 0, Command::Add(1)))
        }));
        assert!(outcome.is_ok(), "ready/call shutdown race panicked instead of returning an error");
        eprintln!("shutdown probe: call returned a future; awaiting typed failure");
        assert!(matches!(bounded(outcome.unwrap()).await, Err(Failure::Actor(ActorError::ActorHungUp))));
    }
}
